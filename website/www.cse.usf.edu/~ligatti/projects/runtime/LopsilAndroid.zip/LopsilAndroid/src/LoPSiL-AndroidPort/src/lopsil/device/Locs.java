package lopsil.device;

/** This class defines time-based locations for use with the LocBuffer class
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Nalin Saigal
 * 
*/
public class Locs {
	public Location location;
	public long timeStamp;
	
	public Locs(Location loc, long time) {
		location = new Location(loc.getGPSLocation());
		timeStamp = time;
	}
	
	public double distance(Location origin, int units) { return location.distance(origin, units); }
}