package lopsil.device;

/**
 * Signals an error regarding the LocationGranularityAssumption.
 *  
 * @author Billy Rickey
 * @author Jay Ligatti
 * 
 * @see LocationGranularityAssumption
 */
public class LocationGranularityAssumptionException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 *
	 */
	public LocationGranularityAssumptionException() { }

	/**
	 * Constructor with a specific message.
	 * @param message the message to be displayed
	 */
	public LocationGranularityAssumptionException(String message) { super(message); }

	/**
	 * Constructor with a specific cause.
	 * @param cause the cause of the Throw
	 */
	public LocationGranularityAssumptionException(Throwable cause) { super(cause); }

	/**
	 * Constructor with a specific message and cause.
	 * @param message the message to be displayed
	 * @param cause the cause of the Throw
	 */
	public LocationGranularityAssumptionException(String message, Throwable cause) { super(message, cause); }
}  