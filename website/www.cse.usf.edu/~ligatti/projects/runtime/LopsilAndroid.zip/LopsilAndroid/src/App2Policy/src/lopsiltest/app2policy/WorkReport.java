package lopsiltest.app2policy;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

/**
 * The WorkReport application displays the users longitude/latitude coordinates and 
 * the information to the employer's server.
 *
 * @author Joshua Finnis
 */
public class WorkReport extends Activity implements LocationListener, Runnable {
	private static final int MENU_QUIT = Menu.FIRST + 2;
	int count = 0;
	TextView loc, updates;
	public Socket asock = null;
	String u[] = new String[5];				// display last 5 updates
	long starttime;
	
	// wakelock to prevent device from powering itself off
	PowerManager pm;
	PowerManager.WakeLock wl;
	
	// constructs for managing location
	LocationManager locationManager;
	public Location lastPoint = new Location((String) null);
	
	// battery information is received asynchronously, so setup a listener
	boolean exit = false;	
	boolean start = true;
	String battery;
    private BroadcastReceiver mBatteryInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
             String action = intent.getAction();
             if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                  int level = intent.getIntExtra("level", 0);
                  int scale = intent.getIntExtra("scale", 100);
                  battery = String.valueOf(level * 100 / scale) + "%";
                  if (exit == true) {
          			Log.i("-->WRMod","BatteryLevelExit: "+battery);
        	        wl.release();    
        			System.exit(0);
                  }
             }             
        }
   };
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
        registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        loc = (TextView) findViewById(R.id.loc);
		updates = (TextView) findViewById(R.id.text);
        starttime=System.currentTimeMillis();

		// set the initial location 
		lastPoint.setLatitude(28.06);
		lastPoint.setLongitude(-82.4154);
		for (int i=0;i<5;i++)
			u[i] = "";

		// wakelock to prevent device from powering itself off
        pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "My Tag");  
        wl.acquire();

		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 0, this);
		locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 0, this);
		
		Thread r = new Thread(this);
		r.setDaemon(true);
		r.start();
	}
	
	// send updates (via handler function) every second
	public void run() {
		while(true) {     
			try { Thread.sleep(1000); } 			// time between updates
			catch (InterruptedException e) { e.printStackTrace(); }
			if (start) {		
	    		Log.i("-->WRUnmod","BatteryLevelStart: "+battery);
	    		unregisterReceiver(mBatteryInfoReceiver);
	    		start = false;
	    	}		
			if (count >250) {								// for measuring performance and memory
			//if (System.currentTimeMillis() - starttime > 1800000) { // for measuring battery
				exit = true;
				registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
				return;
			}
			else {
				count++;
				Log.i("-->update-begin", count + " " + System.currentTimeMillis());				
				for (int i=4; i > 0; i--)
					u[i] = u[i-1];
				u[0] = "work status update:"+count+"\nlocation: <" + lastPoint.getLatitude() + ", " + lastPoint.getLongitude() + ">";
				handler.sendEmptyMessage(0);
			}
		}
	}
	
	// display update on screen and send update in memory to remote server
	private Handler handler = new Handler() {
	    @Override
	    public void handleMessage(Message msg) {
	    	updates.setText(u[0] + "\n\n\n" + u[1] + "\n\n\n" + u[2] + "\n\n\n" + u[3] + "\n\n\n" + u[4]);
	    	
	        PrintWriter out = null;
	        try {
				asock = new Socket("131.247.3.92", 30133);
	            out = new PrintWriter(asock.getOutputStream(), true);
			} catch (UnknownHostException e) { e.printStackTrace();
			} catch (IOException e) { e.printStackTrace(); }
			out.println(u[0]);
			out.close();
			try { asock.close(); } catch (IOException e) { e.printStackTrace(); }
			Log.i("-->update-end", count + " " + System.currentTimeMillis());
	    }
	};
	
	@Override
	public void onLocationChanged(Location loc) { lastPoint = loc; }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, MENU_QUIT, 0, "Quit").setIcon(android.R.drawable.ic_menu_close_clear_cancel);
		return super.onCreateOptionsMenu(menu);
	}   
	
	public boolean onOptionsItemSelected(MenuItem item) {    
		switch (item.getItemId()) {
	    case MENU_QUIT:
	    	exit = true;
			registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
			return true;
		}
		return false;
	}

	@Override
	public void onProviderDisabled(String provider) { }
	@Override
	public void onProviderEnabled(String provider) { }
	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) { }
}
