package lopsiltest.app3nopolicy;

import java.util.ArrayList;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;

/**
 * The ExpectedPath application displays a map and draws an expected path (hardcoded) onto the map.
 * The actual path traveled will be drawn in a different color.
 *  *
 * @author Joshua Finnis
 */
public class ExpectedPath extends MapActivity implements LocationListener {
	private static final int MENU_QUIT = Menu.FIRST;
	private int count = 0;
	long starttime;
	
	// constructs for managing location and the map
	private MapController mapController;
	private MapView mapView;
	private LocationManager locationManager;
	public static ArrayList<GeoPoint> correctPath = new ArrayList<GeoPoint>();
	private GeoPoint lastPoint;
	
	// wakelock to prevent device from powering itself off
	PowerManager pm;
	PowerManager.WakeLock wl;	

	// battery information is received asynchronously, so setup a listener
	private boolean firstRun = true;
	protected boolean exit = false;	
	private String battery;
    private BroadcastReceiver mBatteryInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
             String action = intent.getAction();
             if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                  int level = intent.getIntExtra("level", 0);
                  int scale = intent.getIntExtra("scale", 100);
                  battery = String.valueOf(level * 100 / scale) + "%";
                  if (exit == true) {
          			Log.i("-->GPSUnmod","BatteryLevelExit: "+battery);
        	        wl.release();    
        			System.exit(0);
                  }
             }             
        }
    };
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
        registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        starttime = System.currentTimeMillis();

        pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "My Tag1");  
        wl.acquire();
    
		mapView = (MapView) findViewById(R.id.map);
		mapController = mapView.getController();
		mapController.setZoom(15);
		mapController.setCenter(new GeoPoint((int)(Double.parseDouble("28.06048")*1E6), (int)(Double.parseDouble("-82.4229")*1E6)));
		
		initPath1();
		
		locationManager = (LocationManager)this.getSystemService(LOCATION_SERVICE);
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
		locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
	}
	
	@Override
	public void onLocationChanged(Location loc) {
		count++;
		if (count > 250) {										// for measuring performance/memory
		//if (System.currentTimeMillis() - starttime > 1800000) {	// for measuring battery
			exit = true;
			registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		}
		else {
			Log.i("-->LocUpdateRec", count + " " + System.currentTimeMillis());
			((TextView) findViewById(R.id.text)).setText(count + " updates");
	    	Double lat = loc.getLatitude()*1E6;
	    	Double lng = loc.getLongitude()*1E6;
	    	GeoPoint point = new GeoPoint(lat.intValue(), lng.intValue());
	    	mapController.setCenter(point);
	    	
	    	// wait until first location update received to poll the battery
	    	if (firstRun) {
	    		Log.i("-->GPSUnmod","BatteryLevelStart: "+battery);
	    		unregisterReceiver(mBatteryInfoReceiver);
	    		firstRun = false;
	    	}
	    	else
	    		mapView.getOverlays().add(new PathOverlay(lastPoint, point, Color.BLUE));
	        lastPoint = point;
			Log.i("-->LocUpdateEnd", count + " "  + System.currentTimeMillis());
		}
	}  
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {   	
		menu.add(0, MENU_QUIT, 0, "Quit").setIcon(android.R.drawable.ic_menu_close_clear_cancel);
		return super.onCreateOptionsMenu(menu);
	}   
	
	public boolean onOptionsItemSelected(MenuItem item) {    
		switch (item.getItemId()) {
	    case MENU_QUIT:
			Log.i("-->GPSUnmod","Exiting at: "+System.currentTimeMillis());
	        System.exit(0);
		}
		return false;
	}
	
	// hard code an expected traveled path from shriners hospital on the usf campus to
	// busch gardens
	private void initPath1() {
		if (!correctPath.isEmpty())
			correctPath.clear();
		correctPath.add(new GeoPoint((int)(28.06048*1E6), (int)(-82.4229*1E6)));
		correctPath.add(new GeoPoint((int)(28.06007*1E6), (int)(-82.42296*1E6)));
		correctPath.add(new GeoPoint((int)(28.0573*1E6), (int)(-82.42298*1E6)));
		correctPath.add(new GeoPoint((int)(28.0571*1E6), (int)(-82.42306000000001*1E6)));
		correctPath.add(new GeoPoint((int)(28.05704*1E6), (int)(-82.42315000000001*1E6)));
		correctPath.add(new GeoPoint((int)(28.05704*1E6), (int)(-82.42315000000001*1E6)));
		correctPath.add(new GeoPoint((int)(28.05703000000001*1E6), (int)(-82.423*1E6)));
		correctPath.add(new GeoPoint((int)(28.05688*1E6), (int)(-82.42277*1E6)));
		correctPath.add(new GeoPoint((int)(28.05678*1E6), (int)(-82.42247999999999*1E6)));
		correctPath.add(new GeoPoint((int)(28.05616*1E6), (int)(-82.42175*1E6)));
		correctPath.add(new GeoPoint((int)(28.05596*1E6), (int)(-82.42134*1E6)));
		correctPath.add(new GeoPoint((int)(28.05592*1E6), (int)(-82.4207*1E6)));
		correctPath.add(new GeoPoint((int)(28.05598*1E6), (int)(-82.42019999999999*1E6)));
		correctPath.add(new GeoPoint((int)(28.05636*1E6), (int)(-82.41925999999999*1E6)));
		correctPath.add(new GeoPoint((int)(28.05628000000001*1E6), (int)(-82.41698*1E6)));
		correctPath.add(new GeoPoint((int)(28.05607*1E6), (int)(-82.41661000000001*1E6)));
		correctPath.add(new GeoPoint((int)(28.05574*1E6), (int)(-82.41636*1E6)));
		correctPath.add(new GeoPoint((int)(28.05531*1E6), (int)(-82.41630000000001*1E6)));
		correctPath.add(new GeoPoint((int)(28.05436*1E6), (int)(-82.41632*1E6)));
		correctPath.add(new GeoPoint((int)(28.05436*1E6), (int)(-82.41632*1E6)));
		correctPath.add(new GeoPoint((int)(28.0436*1E6), (int)(-82.41634999999999*1E6)));
		correctPath.add(new GeoPoint((int)(28.0436*1E6), (int)(-82.41634999999999*1E6)));
		correctPath.add(new GeoPoint((int)(28.04356*1E6), (int)(-82.41974999999999*1E6)));
		correctPath.add(new GeoPoint((int)(28.04356*1E6), (int)(-82.41974999999999*1E6)));
		correctPath.add(new GeoPoint((int)(28.04302*1E6), (int)(-82.41981*1E6)));
		correctPath.add(new GeoPoint((int)(28.04248000000001*1E6), (int)(-82.42012*1E6)));
		correctPath.add(new GeoPoint((int)(28.04137*1E6), (int)(-82.42147*1E6)));
		correctPath.add(new GeoPoint((int)(28.04079*1E6), (int)(-82.42189999999999*1E6)));
		
		for(int i = 1; i < correctPath.size(); i++) 
			mapView.getOverlays().add(new PathOverlay(correctPath.get(i-1),correctPath.get(i), Color.GREEN));
	}

	@Override
	protected boolean isRouteDisplayed() { return false; }
	@Override
	public void onProviderDisabled(String arg0) { }
	@Override
	public void onProviderEnabled(String arg0) { }
	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) { }
}
