package lopsil;

import java.lang.Exception;

/**
 * Signals an error in the LoPSiL package.
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 *
 */
public class LopsilException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 *
	 */
	public LopsilException() { }

	/**
	 * Constructor with a specific message.
	 * @param message the message to be displayed
	 */
	public LopsilException(String message) { super(message); }

	/**
	 * Constructor with a specific cause.
	 * @param cause the cause of the Throw
	 */
	public LopsilException(Throwable cause) { super(cause); }

	/**
	 * Constructor with a specific message and cause.
	 * @param message the message to be displayed
	 * @param cause the cause of the Throw
	 */
	public LopsilException(String message, Throwable cause) { super(message, cause); }
}
