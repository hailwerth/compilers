package lopsil;

import lopsil.device.*;

/**
 * The abstract class Policy is the superclass for a specific Security Policy class.
 * <p>
 * Subclasses must provide a query method to check Actions.  User may also specify a
 * way to handle a LocationGranularityAssumption violation or a TimeOfUpdate violation.
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 *
 * @see Action
 * @see Reaction
 */
public abstract class Policy {
	
	protected static LocationGranularityAssumption lga = new LocationGranularityAssumption(Units.INFINITY, Units.METERS);
	protected static FrequencyOfUpdatesAssumption foua;
	
	/**
	 * Checks an Action to determine and return the appropriate Reaction.
	 * 
	 * @param a the Action to be checked
	 * @return the Reaction from a specified Action
	 */
	public abstract  Reaction react(Action a);
	
	/**
	 * Method to be executed when a Location is updated.
	 */
	public synchronized void onLocationUpdate(){}
	
	/**
	 * Handles a granularity assumption exception
	 * @throws GranularityAssumptionException
	 */
    public void handleGranularityViolation() throws LocationGranularityAssumptionException {
    	throw new LocationGranularityAssumptionException("Granularities do not comply!");
    }
    
    /**
     * Handles a time of update assumption exception
     * @throws FrequencyOfUpdatesAssumptionException
     */
	public void handleTimeOfUpdateViolation() throws FrequencyOfUpdatesAssumptionException {
		throw new FrequencyOfUpdatesAssumptionException("GPS has not been updated in time interval!");
	}
	
}