package lopsiltest.app4policy;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import lopsil.*;
import lopsil.device.*;
import android.app.Activity;
import android.util.Log;
import android.widget.TextView;

/**
 * The InviteFriendsAfterTravel policy monitors location updates and sends 
 * a message every X to a server that holds friends locations, provided that
 * the user has traveled Y distance over a period of 2 hours, and only Z distance
 * in the last 10 minutes (stopped traveling). The server sends back a list of nearby
 * friends, which the policy will display.
 *
 * @author Joshua Finnis
 */
public class InviteFriendsAfterTravel extends Policy {	
	//maintain a buffer of two hours’ worth of location data
	private LocBuffer longBuf = new LocBuffer(30, Units.SECONDS);
	//maintain another buffer of twenty minutes’ worth of location data
	private LocBuffer shortBuf = new LocBuffer(5, Units.SECONDS);
	private Time timeLastInvited = Time.NEVER;	
	ArrayList<String> friends = new ArrayList<String>();
	private Socket asock;	
	TextView tv;
	int count = 0;

	// Activity is the Android application type, it is needed to interact with
	// Android's user interface
	private MapDisplay _act;        				
	public InviteFriendsAfterTravel(Activity act) { 
		_act = (MapDisplay) act; 
		tv = (TextView) _act.findViewById(R.id.text);
	}	
	
	public LocationDevice[] devices = { new AndroidGPS() };		// location device
	public LocationGranularityAssumption lga = new LocationGranularityAssumption(Units.INFINITY, Units.INFINITY);
	public FrequencyOfUpdatesAssumption foua = new FrequencyOfUpdatesAssumption(15000.0);
	public PolicyAssumptions pa = new PolicyAssumptions(this, devices, lga, foua);

	// do nothing in the event of granularity or time of update violations
	public void handleGranularityViolation() { }
	public void handleTimeOfUpdateViolation() { }
	
	// allow any security relevant methods to continue 
	public synchronized Reaction react(Action a) { return new Reaction("ok"); }

	// on location updates, determine if the user has stopped traveling and hasn't sent
	// a message in the past X hours, if so, send a message inviting friends
	public synchronized void onLocationUpdate() {
		count++;
		Log.i("-->InPolicyLocUpdateRec", count  + " " + System.currentTimeMillis());
		Location currentLoc = devices[0].getLocation();
		longBuf.add(currentLoc);
		shortBuf.add(currentLoc);		
		
		// set distances traveled to 0 to speed up testing, invite after 5 seconds
		if (longBuf.earliest().distance(currentLoc, Units.KILOMETERS) >= 0 
				&& shortBuf.earliest().distance(currentLoc, Units.KILOMETERS) <= 10 
				&& timeLastInvited.elapsed(Time.getCurrentTime(), Units.SECONDS) > 5) {	
			Location[] friendLocs = getFriendLocations();
			inviteLocalFriends(friendLocs, currentLoc, 500, Units.FEET);
			timeLastInvited = Time.getCurrentTime();
		}	
		Log.i("-->InPolicyLocUpdateEnd", count  + " " + System.currentTimeMillis());
	}		
	
	private void inviteLocalFriends(lopsil.device.Location[] friendLocs,
			lopsil.device.Location currentLoc, int dist, int kilometers) {
		tv.setText("");
		for (int i = 0; i < friendLocs.length; i++) {
			if (currentLoc.distance(friendLocs[i], kilometers) <= dist)
				tv.setText(tv.getText() + friends.get(i) + ":sent ");
			else
				tv.setText(tv.getText() + friends.get(i) + ":unsent ");
		}		
	}
	private Location[] getFriendLocations() {
		// send invite friends message with location, await response       
		BufferedReader in = null;
		PrintWriter out = null;
		String inLocs = null;
        try {
			asock = new Socket("131.247.3.92", 30130);
            out = new PrintWriter(asock.getOutputStream(), true);            
            in = new BufferedReader(new InputStreamReader(asock.getInputStream()), 8192);
			out.println("friend-location-request");
			inLocs = in.readLine();
			tv.setText(inLocs);
			out.close();
			in.close();
			asock.close();
		} catch (UnknownHostException e) { e.printStackTrace();
		} catch (IOException e) { e.printStackTrace(); }

		// parse string response to return Location array
		if (friends != null) friends.clear();
		lopsil.device.Location[] loc = new lopsil.device.Location[5];
		String[] fr = inLocs.split("=");
		for (int i = 0; i < fr.length; i++) {
			String[] tmp = fr[i].split(":");
			friends.add(tmp[0]);
			loc[i] = new lopsil.device.Location(new Position(new Double(tmp[2]).doubleValue(), 
															  new Double(tmp[1]).doubleValue()));
		}
		return loc;
	}
}