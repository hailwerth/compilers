package lopsil.device;

/** This class defines time-based  utilities used in LoPSiL
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Nalin Saigal
 * 
*/
public class Time {
	private long timeValue;
	public static final lopsil.device.Time NEVER = new lopsil.device.Time(-1);

	/* Constructor */
	public Time() { }	
	public Time(long value) { timeValue = value; }

	/* Returns the value of time */
	public long getTime() { return timeValue; }

	/* Sets the value of time */
	public void setTime(long time) { timeValue = time; }
	
	/* Returns the time elapsed from the specified time in the requisite units 
	 * time > Time of caller object */
	public long elapsed(lopsil.device.Time time, int units) {
		long elapsedTimeMS = time.timeValue - this.timeValue;
		long multiplier = (new Double(Units.getMultiplier(units))).longValue();
		return elapsedTimeMS / multiplier;

	}

	/* Returns the current time */
	public static lopsil.device.Time getCurrentTime() { 
		return (new lopsil.device.Time(System.currentTimeMillis())); 
	}

}