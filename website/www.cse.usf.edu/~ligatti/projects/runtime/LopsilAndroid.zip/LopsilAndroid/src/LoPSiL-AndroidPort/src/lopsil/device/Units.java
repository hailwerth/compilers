package lopsil.device;

/**
 * This file defines all the units of length and time used
 * within LoPSiL
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Nalin Saigal
 * 
 */
public class Units {
	public static final int YARDS = 1;
	public static final int FEET = 2;
	public static final int INCHES = 3;
	public static final int MILES = 4;
	public static final int METERS = 5;
	public static final int CENTIMETERS = 6;
	public static final int KILOMETERS = 7;
	public static final int INFINITY = 8;
	public static final int MILSECONDS = 9;
	public static final int SECONDS = 10;
	public static final int MINUTES = 11;
	public static final int HOURS = 12;

	public static double getMultiplier(int scale) {
		double multiplier = 1.0;
		switch (scale) {
			case Units.INCHES:
				multiplier = 1.0 / (12.0 * 5280.0);
				break;
			case Units.FEET:
				multiplier = 1.0 / 5280.0;
				break;
			case Units.YARDS:
				multiplier = 3.0 / 5280.0;
				break;
			case Units.MILES:
				multiplier = 1.0;
				break;
			case Units.CENTIMETERS:
				multiplier = 1.0 / (2.54 * 12.0 * 5280.0);
				break;
			case Units.METERS:
				multiplier = 100.0 / (2.54 * 12.0 * 5280.0);
				break;
			case Units.KILOMETERS:
				multiplier = (1000.0 * 100.0) / (2.54 * 12.0 * 5280.0);
				break;
			case Units.MILSECONDS:
				multiplier = 1.0;
				break;
			case Units.SECONDS:
				multiplier = 1000.0;
				break;
			case Units.MINUTES:
				multiplier = 60.0 * 1000.0;
				break;
			case Units.HOURS:
				multiplier = 60.0 * 60.0 * 1000.0;
				break;
		}
		return multiplier;
	}
} 