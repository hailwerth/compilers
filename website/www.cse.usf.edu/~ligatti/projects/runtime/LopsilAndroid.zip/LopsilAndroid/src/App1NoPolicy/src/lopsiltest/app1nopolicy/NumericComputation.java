package lopsiltest.app1nopolicy;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

/**
 * The NumericComputation application calls a function a specified number of times to 
 * gather data for measuring overhead.
 *  
 * @author Joshua Finnis
 */
public class NumericComputation extends Activity implements Runnable {
	private static final int MENU_QUIT = Menu.FIRST;
	int count = 0;
	TextView updates;
	int tmp1;
	long starttime;
	
	// wakelock to prevent device from powering itself off
	PowerManager pm;
	PowerManager.WakeLock wl;

	// battery information is received asynchronously, so setup a listener
	boolean exit = false;	
	boolean start = true;
	String battery;
    private BroadcastReceiver mBatteryInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
             String action = intent.getAction();
             if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                  int level = intent.getIntExtra("level", 0);
                  int scale = intent.getIntExtra("scale", 100);
                  battery = String.valueOf(level * 100 / scale) + "%";
                  if (exit == true) {
          			Log.i("-->nc-nopolicy","BatteryLevelExit: "+battery);
        	        wl.release();    
        			System.exit(0);
                  }
             }             
        }
    };
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
        registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		updates = (TextView) findViewById(R.id.text);
		updates.setText("performing computation");
		starttime = System.currentTimeMillis();

		// wakelock to prevent device from powering itself off
		pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "My Tag");  
        wl.acquire();

    	// run computation thread
		Thread r = new Thread(this);
		r.setDaemon(true);
		r.start();
	}

	public void run() {
		if (start) {		
    		Log.i("-->nc-nopolicy","BatteryLevelStart: "+battery);
    		unregisterReceiver(mBatteryInfoReceiver);
    		start = false;
    	}		
		try { Thread.sleep(1000); }
		catch (InterruptedException e) { e.printStackTrace(); }
		
		double gr = (1 + Math.sqrt(5))/2;
		while (true) {     
			if (count >250) { 							// for measuring performance and memory
			//if (System.currentTimeMillis() - starttime > 1800000) { // for measuring battery
				exit = true;
				registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
				return;
			}
			else {						
				count++;
				Log.i("-->function-begin", count + " " + System.currentTimeMillis());
				compute(gr);
				Log.i("-->function-end", count + " " + System.currentTimeMillis());
			}
		}
	}
	
	// performs a fast numeric computation, just a placeholder function 
	// which allows measuring of overhead when monitoring this function
	private void compute(double gr) {
		for (int j = 0; j < 10; j++)
			for (int i = 1; i <= 45; i++) {
				tmp1 = (int) Math.round((Math.pow(gr, i) - Math.pow(1 - gr, i))/Math.sqrt(5));	
			}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, MENU_QUIT, 0, "Quit").setIcon(android.R.drawable.ic_menu_close_clear_cancel);
		return super.onCreateOptionsMenu(menu);
	}   
	
	public boolean onOptionsItemSelected(MenuItem item) {    
		switch (item.getItemId()) {
	    case MENU_QUIT:
	    	exit = true;
			registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
			return true;
		}
		return false;
	}
}
