package lopsiltest.app3policy;
import java.text.DecimalFormat;

import lopsil.Action;
import lopsil.Policy;
import lopsil.PolicyAssumptions;
import lopsil.Reaction;
import lopsil.device.AndroidGPS;
import lopsil.device.FrequencyOfUpdatesAssumption;
import lopsil.device.Location;
import lopsil.device.LocationDevice;
import lopsil.device.LocationGranularityAssumption;
import lopsil.device.Position;
import lopsil.device.Units;
import android.app.Activity;
import android.widget.TextView;

/**
 * The ShowNavigationAid policy monitors location updates and checks for the distance
 * between received location updates and the expected path in ExpectedPath.java. It displays
 * text on screen should the actual path deviate from expected by a certain distance.
 *  
 * @author Joshua Finnis
 */
public class ShowNavigationAid extends Policy {		
	private double _distance = 0;
	
	// Activity is the Android application type, it is needed to interact with
	// Android's user interface
	private ExpectedPath _act;        				
	public ShowNavigationAid(Activity act) { _act = (ExpectedPath) act; }	
	
	public LocationDevice[] devices = { new AndroidGPS() };	
	public LocationGranularityAssumption lga = new LocationGranularityAssumption(15, Units.METERS);
	public FrequencyOfUpdatesAssumption foua = new FrequencyOfUpdatesAssumption(15000.0);
	public PolicyAssumptions pa = new PolicyAssumptions(this, devices, lga, foua);
	
	// do nothing in the event of granularity or time of update violations
	public void handleGranularityViolation() { }
	public void handleTimeOfUpdateViolation() { }
	
	// allow any security relevant methods to continue 
	public synchronized Reaction react(Action a) { return new Reaction("ok"); }
	
	// display aid if needed upon receiving a location update
	public synchronized void onLocationUpdate() {
		if (distanceToExpectedPath(devices[0].getLocation(), Units.MILES) > .5)
			displayNavigationalAid();
		else
			clearNavigationalAid();
	}

	private double distanceToExpectedPath(Location l, int units) {
		double distance = 0, min = 9999;
		for(int i = 0; i < ExpectedPath.correctPath.size(); i++) { 
			distance = devices[0].getLocation().distance(new Location(
					new Position(ExpectedPath.correctPath.get(i).getLatitudeE6()/1E6, 
							ExpectedPath.correctPath.get(i).getLongitudeE6()/1E6)), Units.MILES);
			if (distance < min)
				min = distance;
		}
		_distance = min;
		return min*Units.getMultiplier(units);
	} 
	
	// interacts with the textview initialized in main.xml in order to display text 
	// on the screen
	private void displayNavigationalAid() {
		DecimalFormat miles = new DecimalFormat("0.00 miles");
		((TextView) _act.findViewById(R.id.text)).setText(miles.format(_distance)+" away from path");
	}

	// interacts with the textview initialized in main.xml in order to clear the display
	private void clearNavigationalAid() {
		((TextView) _act.findViewById(R.id.text)).setText("within limit distance");
	}
}