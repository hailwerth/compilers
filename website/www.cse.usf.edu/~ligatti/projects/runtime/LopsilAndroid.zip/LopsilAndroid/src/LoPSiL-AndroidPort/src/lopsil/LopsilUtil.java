package lopsil;
import lopsil.device.*;

/**
 * The LopsilUtil class provides utility methods for the user.
 * <p>
 * These methods include calculating the velocity/acceleration
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 *
 */

public class LopsilUtil {
	/** Use with <code>LocationDevice.isUpdatedWithin</code> */
	public static final int MILLISECONDS = 0;
	/** Use with <code>LocationDevice.isUpdatedWithin</code> */
	public static final int SECONDS = 1;
	/** Use with <code>LocationDevice.isUpdatedWithin</code> */
	public static final int MINUTES = 2;
	/** Use with <code>LocationDevice.isUpdatedWithin</code> */
	public static final int HOURS = 3;
	/** Use with <code>calculateVelocity</code> & <code>calculateAcceleration</code> */
	public static final int METERS_PER_SECOND = 4;
	/** Use with <code>calculateVelocity</code> & <code>calculateAcceleration</code> */
	public static final int KILOMETERS_PER_HOUR = 5;
	/** Use with <code>calculateVelocity</code> & <code>calculateAcceleration</code> */
	public static final int FEET_PER_SECOND = 6;
	/** Use with <code>calculateVelocity</code> & <code>calculateAcceleration</code> */
	public static final int MILES_PER_HOUR = 7;
	/** Use with <code>(Position).isWithin </code> */
	public static final int INCHES = 8;
	/** Use with <code>(Position).isWithin </code> */
	public static final int FEET = 9;
	/** Use with <code>(Position).isWithin </code> */
	public static final int YARDS = 10;
	/** Use with <code>(Position).isWithin </code> */
	public static final int MILES = 11;
	/** Use with <code>(Position).isWithin </code> */
	public static final int CENTIMETERS = 12;
	/** Use with <code>(Position).isWithin </code> */
	public static final int METERS = 13;
	/** Use with <code>(Position).isWithin </code> */
	public static final int KILOMETERS = 14;
		
	/** LopsilUtil representation of NaN */
	public static final double NaN = 1.0 / 0.0;
	
	/**
	 * Calculates the average velocity from the previously stored GPS Positions
	 * @param pos the array of Locations containing GPS Positions
	 * @param measurement the unit of measurement for the returning velocity 
	 * @return the velocity in the specified measurement
	 */
	public static double calculateVelocity(Location[] pos, int measurement) {
		if (pos.length > 1) {
			if (pos[pos.length/2] != null) {
				double timeScale = 1.0, distScale = 1.0;
				switch (measurement) {
					case METERS_PER_SECOND:
						timeScale *= 1000.0;
						distScale *= (5280.0 * 12.0 * 2.54 / 100.0);
						break;
					case KILOMETERS_PER_HOUR:
						timeScale *= 3600000.0;
						distScale *= (5280.0 * 12.0 * 2.54 / (100.0 * 1000.0));
						break;
					case FEET_PER_SECOND:
						timeScale *= 1000.0;
						distScale *= 5280.0;
						break;
					case MILES_PER_HOUR:
						timeScale *= 3600000.0;
						break;
				}
			
				double msecDif = pos[0].getLastTimeOfUpdate() - pos[pos.length/2].getLastTimeOfUpdate();
				double distFrom = 0.0;
				
				int i = 0;
				do {
					distFrom += Math.abs(pos[i].getGPSLocation().getDistanceFrom(pos[i+1].getGPSLocation()));
					i++;
				} while (i < pos.length/2 - 1);

				return timeScale * (distFrom * distScale) / (msecDif);
			} 
			else
				return NaN;
		} 
		else
			return NaN;
	}
	
	/**
	 * Calculates the average acceleration from the previously stored GPS Positions
	 * @param pos the array of Locations containing GPS Positions
	 * @param measurement the unit of measurement for the velocity calculations 
	 * @return the acceleration measured in the units specified
	 */
	public static double calculateAcceleration(Location[] pos, int measurement) {
		if (pos.length > 2) {
			if (pos[pos.length/2] != null && pos[pos.length-1] != null) {
				double timeScale = 1.0, distScale = 1.0;
				switch (measurement) {
					case METERS_PER_SECOND:
						timeScale *= 1000.0;
						distScale *= (5280.0 * 12.0 * 2.54 / 100.0);
						break;
					case KILOMETERS_PER_HOUR:
						timeScale *= 3600000.0;
						distScale *= (5280.0 * 12.0 * 2.54 / (100.0 * 1000.0));
						break;
					case FEET_PER_SECOND:
						timeScale *= 1000.0;
						distScale *= 5280.0;
						break;
					case MILES_PER_HOUR:
						timeScale *= 3600000.0;
						break;
				}
			
				double v1MsecDif = pos[0].getLastTimeOfUpdate() - pos[pos.length/2].getLastTimeOfUpdate();
				double v1DistFrom = 0.0;
				
				int i = 0;
				do {
					v1DistFrom += Math.abs(pos[i].getGPSLocation().getDistanceFrom(pos[i+1].getGPSLocation()));
					i++;
				} while(i < pos.length/2 - 1);
				
				double v1 = timeScale * (v1DistFrom * distScale) / (v1MsecDif);  //1st velocity
			
				double v2MsecDif = pos[pos.length/2].getLastTimeOfUpdate() - pos[pos.length-1].getLastTimeOfUpdate();
				double v2DistFrom = 0.0;
				
				for(i = pos.length/2; i < pos.length-1; i++) 
					v2DistFrom += Math.abs(pos[i].getGPSLocation().getDistanceFrom(pos[i+1].getGPSLocation()));
				double v2 = timeScale * (v2DistFrom * distScale) / (v2MsecDif); //2nd velocity
	
				return timeScale * (v1 - v2) / ((v1MsecDif + v2MsecDif));
			} 
			else
				return NaN;
		} 
		else
			return NaN;		
	}
}
