package lopsil;
import android.util.Log;

/**
 * Reaction is a base class of the LoPSiL package that can allow or prevent any method's excution based 
 * on a Policy's query method.  A Reaction can be set to 'ok', 'replace', 'exception', or 'halt'.
 * 
 * <p>An 'ok' Reaction will allow a method to execute.<br>A 'replace' Reaction will substitute in a new value.
 * <br>
 * An 'exception' Reaction will trigger an exception.<br>A 'halt' Reaction will cause the system to halt.</p>
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * 
 * @see Action
 * @see Policy
 */
public class Reaction {
	
	/* Instance Fields */
	private boolean _valid, _replace, _exception, _halt;
	private Object _repObject = null;
	private Exception _exceptionType;

	/**
	 * Construct a newly allocated Reaction, specifying the type of Reaction.
	 * @param s the type of Reaction ('ok', 'replace', 'exception', 'halt')
	 */
	public Reaction(String s) {
		try {
			constructReaction(s.toLowerCase());
		} catch (LopsilException le) {
			Log.d("LoPSiL_Reaction", le.toString());
			System.exit(1);
		}
	}
	
	/**
	 * Construct a newly allocated Reaction with an Exception or Replace value
	 * @param s the type of Reaction ('ok', 'replace', 'exception', 'halt')
	 * @param obj the object to be used as either the Replace value or Exception
	 */
	public Reaction(String s, Object obj) {
		try {
			constructReaction(s.toLowerCase(), obj);
		} catch (LopsilException le) {
			Log.d("LoPSiL_Reaction", le.toString());
			System.exit(1);
		}
	}
	
	/**
	 * Compares the class of the object intended as the replacement to a specified class.
	 * @param c class to match
	 * @throws LopsilException
	 */
	public void checkReplVal(Class<?> c) throws LopsilException {
		if (_repObject != null) {
			boolean needThrow = true;
			Class<?> tempClass = _repObject.getClass();
			do {
				if (c.equals(tempClass))
					needThrow = false;
				tempClass = tempClass.getSuperclass();
			} while (tempClass != null);
			
			if (needThrow)
				throw new LopsilException("The class of the replace object does not match!");
		}
	}
	
	/**
	 * Forces the user construct one of the four different Reactions
	 * @param s the type of the Reaction
	 * @throws LopsilException
	 */
	private void constructReaction(String s) throws LopsilException {
		if (s.equals("ok"))
			_valid = true;
		else if (s.equals("replace")) {
			_replace = true;
			_repObject = null;
		} 
		else if (s.equals("exception")) {
			_exception = true;
			_exceptionType = new LopsilException("Default Reaction Exception");
		}
		else if (s.equals("halt"))
			_halt = true;
		else
			throw new LopsilException("Reaction type improperly declared!");
	}
	
	/**
	 * Forces the user to construct either a Replace or Exception Reaction
	 * @param s the type of Reaction
	 * @param obj the Replace object or Exception type
	 * @throws LopsilException
	 */
	private void constructReaction(String s, Object obj) throws LopsilException {
		if (s.equals("replace")) {
			_replace = true;
			_repObject = obj;
		} 
		else if (s.equals("exception")) {
			_exception = true;
			_exceptionType = (Exception) obj;
		} 
		else
			throw new LopsilException("Reaction type improperly declared!");
	}
	
	/**
	 * Returns the type of exception specified by the Reaction.
	 * @return the Exception of the Reaction
	 */
	public Exception getException(){return _exceptionType;}
	
	/**
	 * Returns the value that should act as the replace value.
	 * @return the replace object
	 */
	public Object getReplVal(){return _repObject;}
	
	/**
	 * Checks to see if a Reaction triggers an Exception.
	 * @return true if an Exception should be triggered
	 */
	public boolean isException(){return _exception;}
	
	/**
	 * Checks to see if a Reaction causes the system to halt.
	 * @return true if the system should halt
	 */
	public boolean isHalt(){return _halt;}
	
	/**
	 * Checks to see if a Reaction is OK.
	 * @return true if a Reaction is OK
	 */
	public boolean isOK(){return _valid;}
	
	/**
	 * Checks to see if a Reaction should replace a value.
	 * @return true if a value should be replaced
	 */
	public boolean isReplace(){return _replace;}
	
	/**
	 * Sets the Exception for the Reaction to be the generic LopsilException.
	 */
	public void setException() {
		_exception = true;
		_valid = _halt = _replace = false;
		_exceptionType = new LopsilException("Default LoPSiL Exception");
	}
	
	/**
	 * Sets the Exception for the Reaction from a specified Exception.
	 * @param type Exception to be triggered
	 */	
	public void setException(Exception type) {
		_exception = true;
		_valid = _halt = _replace = false;
		_exceptionType = type;
	}
	
	/**
	 * Sets the Reaction to trigger a system halt.
	 */
	public void setHalt() {
		_halt = true;
		_valid = _exception = _replace = false;
	}
	
	/**
	 * Sets the Reaction to be OK.
	 * <p>
	 * The operation can proceed.
	 */
	public void setOK() {
		_valid = true;
		_exception = _halt = _replace = false;
	}
	
	/**
	 * Sets the replace object for a Replace Reaction.
	 * @param obj the object to replace the value
	 */
	public void setReplVal(Object obj) {
		_replace = true;
		_valid = _halt = _exception = false;
		_repObject = obj;
	}
	
	/**
	 * Returns the String representation of the type of Reaction.
	 */
	public String toString() {
		if (_valid)
			return "ok";
		else if (_replace)
			return "replace";
		else if (_halt) 
			return "halt";
		else
			return "exception";
	}
		
}