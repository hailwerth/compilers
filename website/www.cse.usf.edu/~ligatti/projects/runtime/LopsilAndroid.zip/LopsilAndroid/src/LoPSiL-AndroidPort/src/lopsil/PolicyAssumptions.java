package lopsil;

import lopsil.device.*;
import android.util.Log;

/**
 * PolicyAssumptions sets up the devices and assumptions that are to be used for the policy.
 * It checks for at least one valid device so the application can continue.  It also starts the
 * FrequencyOfUpdatesAssumption thread if one is specified.
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Joshua Finnis
 *
 */
public class PolicyAssumptions {

	/**
	 * Constructs a newly allocated PolicyAssumptions which sets up the policy.
	 * If the GPSGranularities do not comply, the Policy's <code>handleGranularityViolation()</code> will
	 * be called.
	 * 
	 * @param p the Policy to apply the assumption to
	 * @param LocationDevice An array of LocationDevices to be used in the Policy
	 * @param t The FrequencyOfUpdatesAssumption to be used in the Policy
	 * @param g The LocationGranularityAssumption to be used in the Policy
	 */
	public PolicyAssumptions(Policy p, LocationDevice[] locationDevice, LocationGranularityAssumption g, FrequencyOfUpdatesAssumption f)
	{
		//If a LocationGranularityAssumption was specified, make sure a GPS LocationDevice is present
		if (g != null)
			if (g.getValue(LocationGranularityAssumption.YARDS) != Units.INFINITY) 
				try {
					checkGPS(locationDevice);		
				} 
				catch (Exception e) {
					try {
						p.handleGranularityViolation();
					}
					catch (Exception geoEx) {
						Log.d("LoPSiL_PolicyAssumptions", "HandleGranularityViolation threw Exception, exiting");
						System.exit(1);
					}
				}
				
		for (int i = 0; i < locationDevice.length; i++) {
			locationDevice[i].setPolicy(p);
			if (locationDevice[i].isGPS()) {			
				if (locationDevice[i].getGranularity().compliesWith(g)) 
					locationDevice[i].setValid();
				else 
					try {
						p.handleGranularityViolation();
					} 
					catch (Exception geoEx) {
						Log.d("LoPSiL_PolicyAssumptions", "HandleGranularityViolation threw Exception, exiting");
						System.exit(1);
					}
			} 
			else locationDevice[i].setValid();
		}
		
		try {
			checkValidity(locationDevice);		
			if (f != null) {
				Thread timeThread = new Thread(new FrequencyOfUpdatesAssumption(f, locationDevice, p));
				timeThread.setDaemon(true);
				timeThread.start();
			}
		} 
		catch(Exception e) {
			Log.d("LoPSiL_PolicyAssumptions", "Invalid LocationDevice");
			System.exit(1);
		}
	}
	
	/**
	 * Checks to make sure that a GPS device was specified if a LocationGranularityAssumption was specified.
	 * 
	 * @param locationDevice The array of LocationDevices
	 * @throws LopsilException
	 */
	private void checkGPS(LocationDevice[] locationDevice) throws LopsilException {
		boolean exception = true;
		for (int i = 0; i < locationDevice.length; i++)
			if(locationDevice[i].isGPS())
				exception = false;
		if (exception)
			throw new LopsilException("You specified a LocationGranularityAssumption without specifying a GPS device!");
	}
	
	/**
	 * Checks to make sure that at least one valid device is available.
	 * 
	 * @param locationDevice The array of LocationDevices
	 * @throws LopsilException
	 */
	private void checkValidity(LocationDevice[] locationDevice) throws LopsilException {
		boolean exception = true;
		for (int i = 0; i < locationDevice.length; i++)
			if(locationDevice[i].isValid())
				exception = false;
		if (exception)
			throw new LopsilException("No valid LocationDevice detected in system!");
	}
	
}
