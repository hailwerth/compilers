package lopsil.device;

import lopsil.LopsilException;
import lopsil.LopsilUtil;
import android.util.Log;

/**
 * The Location class encapsulates the Locations a LocationDevice can have.
 * GPS devices use Positions as Locations.
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Nalin Saigal
 * @author Joshua Finnis
 * 
 */
public class Location {
	private Position _gpsLocation;
	private boolean _isGPS; 
	private volatile long _updateTime;;
	//private static Policy _securityPolicy;
	
	public Location() {	}
	
	/**
	 * Construct a newly allocated Location with a specified Position.
	 * @param p the Position representing the Location of a GPS LocationDevice
	 */
	public Location(Position p) {
		_gpsLocation = p;
		_updateTime = System.currentTimeMillis();
		_isGPS = true;
	}

	/**
	 * Returns the specific geographic location of a GPS device.
	 * @return the specific location of a GPS device
	 */
	public synchronized Position getGPSLocation() {
		if (_gpsLocation != null) {
			try {
				checkLocation("gps");
			} catch (LopsilException e) {
				Log.d("LoPSiL_Location", "Exception during checklocation, exiting");
				System.exit(1);
			}
		}
		return _gpsLocation;
	}

	/**
	 * Sets the specific geographic location of a GPS device.
	 * @param gpsLoc the specific location of a GPS device
	 */
	public synchronized void setGPSLocation(Position gpsLoc) {
		_gpsLocation = gpsLoc;
		_updateTime = System.currentTimeMillis();
		_isGPS = true;
		//if (_securityPolicy != null)
		//	_securityPolicy.onLocationUpdate();
	}
		
	/**
	 * Returns the time of the most recent update.
	 * @return the time of the most recent update
	 */
	public long getLastTimeOfUpdate(){return this._updateTime;}
	
	/**
	 * Checks to see if a Location has been updated within a specific time interval
	 * 
	 * @param time
	 * @param measurement
	 * @return true if the Location has been updated within the time interval, and false otherwise
	 */
	public boolean isUpdatedWithin(double time, int measurement) {
		switch (measurement) {
			case LopsilUtil.SECONDS:
				time *= 1000.0;
				break;
			case LopsilUtil.MINUTES:
				time *= 60000.0;
				break;
			case LopsilUtil.HOURS:
				time *= 3600000.0;
				break;
		}		
		return System.currentTimeMillis() - _updateTime < time;
	}
	
	/**
	 * Returns the string representation of the Location.
	 */
	public String toString(){
		if (_isGPS)
			return _gpsLocation.toString();
		else
			return "";
	}
	
	/**
	 *  Returns the distance of the location from a location l,
	 *  in the units specified by the user
	 */
	public double distance(Location l, int units)
	{
		double multiplier = Units.getMultiplier(units);
		double distance = this._gpsLocation.getDistanceFrom(l._gpsLocation);
		return (distance / multiplier);
	}

	/**
	 * Returns true or false based on whether the current location 
	 * is within the region defined by regionLocs.
	 */
	public boolean inRegion(Location[] regionLocs)
	{
		Double minLat = regionLocs[0]._gpsLocation.getLatitude();
		Double minLon = regionLocs[0]._gpsLocation.getLongitude();
		Double maxLat = regionLocs[0]._gpsLocation.getLatitude();
		Double maxLon = regionLocs[0]._gpsLocation.getLongitude();
		Double compareWith;
		/* Get minimum Latitude */
		for (int i = 0; i < regionLocs.length; i++)
		{
			compareWith = regionLocs[i]._gpsLocation.getLatitude();
			if (compareWith < minLat)
				minLat = compareWith;
		}
		/* Get minimum Longitude */
		for (int i = 0; i < regionLocs.length; i++)
		{
			compareWith = regionLocs[i]._gpsLocation.getLongitude();
			if (compareWith < minLon)
				minLon = compareWith;
		}
		/* Get maximum Latitude */
		for (int i = 0; i < regionLocs.length; i++)
		{
			compareWith = regionLocs[i]._gpsLocation.getLatitude();
			if (compareWith > maxLat)
				maxLat = compareWith;
		}
		/* Get maximum Longitude */
		for (int i = 0; i < regionLocs.length; i++)
		{
			compareWith = regionLocs[i]._gpsLocation.getLongitude();
			if (compareWith > maxLon)
				maxLon = compareWith;
		}
		Double thisLat = this._gpsLocation.getLatitude();
		Double thisLon = this._gpsLocation.getLongitude();
		if ((thisLat < maxLat || thisLat.equals(maxLat)) &&
			(thisLat > minLat || thisLat.equals(minLat)) &&
			(thisLon < maxLon || thisLon.equals(maxLon)) &&
			(thisLon > minLon || thisLon.equals(minLon)))
			return true;
		else
			return false;
	}
	
	/**
	 * Checks to make sure that the Location being asked for is the correct type.
	 * @param loc a String representation of the type of Location
	 * @throws LopsilException
	 */
	private void checkLocation(String loc) throws LopsilException
	{
		if (loc.equals("gps") && !_isGPS)
			throw new LopsilException("Location not set or incorrect usage!");
	}
}