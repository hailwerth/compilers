package lopsiltest.app4policy;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;

/**
 * The MapDisplay application displays a map showing the user's current 
 * location to the user.
 *
 * @author Joshua Finnis
 */
public class MapDisplay extends MapActivity implements LocationListener {
	private static final int MENU_QUIT = Menu.FIRST;
	private int count = 0;
	long starttime; 
	
	// constructs for managing location and the map	
	private MapController mapController;
	private MapView mapView;
	public LocationManager locationManager;	
	
	// wakelock to prevent device from powering itself off
	PowerManager pm;
	PowerManager.WakeLock wl;
	
	// battery information is received asynchronously, so setup a listener
	protected boolean exit = false;	
	private boolean firstRun = true;
	private String battery;
    private BroadcastReceiver mBatteryInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
             String action = intent.getAction();
             if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                  int level = intent.getIntExtra("level", 0);
                  int scale = intent.getIntExtra("scale", 100);
                  battery = String.valueOf(level * 100 / scale) + "%";
                  if (exit == true) {
          			Log.i("-->IFMod","BatteryLevelExit: "+battery);
        	        wl.release();    
        			System.exit(0);
                  }
             }             
        }
   };
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
        registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

		// wakelock to prevent device from powering itself off
        pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "My Tag");  
        wl.acquire();
    
		mapView = (MapView) findViewById(R.id.map);
		mapController = mapView.getController();
		mapController.setZoom(15);
		mapController.setCenter(new GeoPoint((int)(Double.parseDouble("28.06048")*1E6), (int)(Double.parseDouble("-82.4229")*1E6)));
		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
		locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
	}
	@Override
	public void onLocationChanged(Location loc) {
		count++;   	
		if (firstRun) {
    		Log.i("-->IFMod","BatteryLevelStart: "+battery);
    		unregisterReceiver(mBatteryInfoReceiver);
    		firstRun = false;
    	}
		if (count > 250) {									// for measuring performance/memory
			//if (System.currentTimeMillis() - starttime > 1800000) { 	// for measuring battery
			exit = true;
			registerReceiver(mBatteryInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		}
		else if (count <= 250)	{
			Log.i("-->LocUpdateRec", count + " " + System.currentTimeMillis());
			((TextView) findViewById(R.id.updates)).setText(count + " updates");
	    	Double lat = loc.getLatitude()*1E6;
	    	Double lng = loc.getLongitude()*1E6;
	    	GeoPoint point = new GeoPoint(lat.intValue(), lng.intValue());
	    	mapController.setCenter(point);
			Log.i("-->LocUpdateEnd", count + " "  + System.currentTimeMillis());
		}
	}   
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {   	
		menu.add(0, MENU_QUIT, 0, "Quit").setIcon(android.R.drawable.ic_menu_close_clear_cancel);
		return super.onCreateOptionsMenu(menu);
	}   
	
	public boolean onOptionsItemSelected(MenuItem item) {    
		switch (item.getItemId()) {
	    case MENU_QUIT:
			Log.i("-->IFMod","Exiting at: "+System.currentTimeMillis());
	        System.exit(0);
		}
		return false;
	}
	
	@Override
	protected boolean isRouteDisplayed() { return false; }
	@Override
	public void onProviderDisabled(String arg0) { }
	@Override
	public void onProviderEnabled(String arg0) { }
	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) { }
}
