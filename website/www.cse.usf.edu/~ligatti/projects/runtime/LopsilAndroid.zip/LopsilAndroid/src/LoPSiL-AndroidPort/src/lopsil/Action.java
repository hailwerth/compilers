package lopsil;
//Allow for class Signature & Join Points
import org.aspectj.lang.*;

/**
 * Action is a the base class of the LoPSiL package that encapsulates everything
 * needed to check the legitimacy of a method.  An Action can be any method
 * occurring in an application.
 * <p>
 * The Class, Signature and Parameters of a particular Action can be accessed
 * through methods of this class.  This is used in junction with the Reaction
 * class to enforce Location-Based security policies
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Nalin Saigal
 * @see Reaction
 * @see Policy
 */
public class Action {	
	/* Instance Fields */
	private Signature _signature;
	private String _returnType, _method, _fileName;
	private Object _caller;
	private Object[] _arguments;
	private String[] _formalWrappedArguments;
	private String[] _formalUnwrappedArguments;
	private Class<?> _className, _withinType;
	private int _lineNumber;
	private Reaction _reaction;
	private Object _executionResult;
	private boolean _hasReaction, _hasResult;	

	/**
	 * Constructs a newly allocated Action from a specific join point.
	 * 
	 * @param joinPoint the join point from which the Action should be created
	 */
	public Action(JoinPoint joinPoint){
		setSignature(joinPoint.getSignature());
		setWithinType(joinPoint.getSourceLocation().getWithinType());
		setFileName(joinPoint.getSourceLocation().getFileName());
		setLineNumber(joinPoint.getSourceLocation().getLine());
		setActionClass(joinPoint.getSignature().getDeclaringType());
		setArguments(joinPoint.getArgs());
		setCaller(joinPoint.getTarget());
	}
	
	/**
	 * Constructs a newly allocated Action.
	 * 
	 * @param sign
	 * @param className
	 * @param args
	 * @param fileName
	 * @param lineNumber
	 */
	public Action(Signature sign, Class<?> className, Object[] args, String fileName, int lineNumber) {
		this._signature = sign;
		this._fileName = fileName;
		this._lineNumber = lineNumber;
		this._className = className;
		this._arguments = args;
		this._formalWrappedArguments = new String[args.length];
		for(int i = 0; i < args.length; i++) 
			this._formalWrappedArguments[i] = args[i].getClass().getSimpleName();
		this._formalUnwrappedArguments = this._formalWrappedArguments;
		
	}

	/**
	 * Returns the Caller of the Action.
	 * @return the Caller of the Action
	 */
	public Object getCaller() { return _caller; }

	/**
	 * Returns the Class of the Action.
	 * @return the Class of the Action
	 */
	public Class<?> getActionClass(){return _className;}
	
	/**
	 * Returns an array consisting of the arguments of the Action.
	 * @return the arguments of the Action
	 */
	public Object[] getArgs() {return _arguments;}
	
	/**
	 * Returns the Class in which the Action occurs lexically
	 * @return the Class in which the Action occurs lexically
	 */
	public Class<?> getWithinType(){return _withinType;}
	
	/**
	 * Returns the name of the file where the Action occurs.
	 * @return the name of the file where the Action occurs
	 */
	public String getFileName(){return _fileName;}
	
	/**
	 * Returns an array consisting of the "wrapped" representations of the types of the Action's arguments.
	 * @return the "wrapped" types of the Action's arguments
	 */
	public String[] getFormalWrappedArguments(){return _formalWrappedArguments;}
	
	/**
	 * Returns the line number at which the Action occurs.
	 * @return the line number at which the Action occurs
	 */
	public int getLineNumber(){return _lineNumber;}
	
	/**
	 * Returns the String representation of the method of the Action.
	 * @return the method of the Action
	 */
	public String getMethod(){return _method;}
	
	/**
	 * Returns the Reaction from the initial survey of an Action.
	 * @return the Reaction from the initial survey of an Action
	 * @see Reaction
	 */
	public Reaction getReaction(){return _reaction;}
	
	/**
	 * Returns the object obtained from executing the Action (after the initial survey).
	 * @return the Action's result
	 */
	public Object getResult(){return _executionResult;}
	
	/**
	 * Returns the String representation of the return type of the Action. 
	 * @return the return type of the Action
	 */
	public String getReturnType(){return _returnType;}
	
	/**
	 * Returns the Signature object of the Action.
	 * @return the Signature of the Action
	 */
	public Signature getSignature(){return _signature;}
	
	/**
	 * Checks to see if an Action has a Reaction (from the initial survey).
	 * @return true if Action has a Reaction and false otherwise
	 */
	public boolean hasReaction(){return _hasReaction;}
	
	/**
	 * Checks to see if an Action has an execution result.
	 * @return true if the Action has a result and false otherwise
	 */
	public boolean hasResult(){return  _hasResult;}
	
	/**
	 * Compares a given string to an Action's Signature to determine if the two match.
	 * It returns true if it matches and false if there is no match.
	 * 
	 * <br>This input string can make use of the .. and * wildcards that AspectJ uses.
	 * 
	 *<p>Method-Call Examples:</p>
	 * 
	 *<p><code><b>void java.io.PrintStream.println(String)</b></code> matches the <code>println</code> method from the <code>java.io.PrintStream</code>
	 *class that passes a <code>String</code> as its only argument.</p>
	 *
	 *<p><code><b>* java.lang.String*.*(*, *)</b></code> matches any method from the the <code>java.io.String</code>, <code>java.io.StringBuffer</code>,
	 *<code>java.io.StringBuilder</code> or <code>java.io.StringIndexOutOfBoundsException</code> class that passes two arguments of any type.</p>
	 *
	 *<p>Constructor Examples:</p>
	 *<p><code><b>java.io.File.new(..)</b></code> matches the creation of a <code>java.io.File</code> with any number of arguments.</p>
	 *<p><code><b>javax..*.new()</b></code> matches the creation of any object in the <code>javax</code>
	 * package or in any of its sub-packages that passes zero arguments.</p>
	 *<p>
	 * @param s the method to check for matching
	 * @return true if there is a match, false if there is no match
	 */
	public boolean matches(String s){
		if (s.equals(_signature.toString()))
			return true;
		
		int lParen = s.indexOf('('), rParen = s.indexOf(')');
		
		if (lParen == rParen || lParen > rParen)	// Improper syntax
			return false;
		
		int lastPeriod = s.lastIndexOf('.', lParen);
		String passingArgs[] = new String[0];
		
		int commaIndex = 0, numArgs = 0, dotIndex = _signature.toString().indexOf('('), dotCount = 0;
		
		// If there's at least one parameter, count all
		if (rParen - lParen != 1) {
			do {
				numArgs++;
				commaIndex = s.indexOf(',', commaIndex+1);
			} while (commaIndex != -1);
		}
		
		if(numArgs > 0)
			passingArgs = getAllArguments(lParen, rParen, numArgs, s);
		
		do {	// Count the periods
			dotCount++;
			dotIndex = _signature.toString().lastIndexOf('.', dotIndex-1);
		} while (dotIndex > 0);
		
		// Take apart the action's signature 
		String signDecl[] = getDeclarations(_signature.toString(), dotCount);

		if (_returnType.equals("constructor")){
			if ((s.indexOf(' ') > 0 && s.indexOf(' ') < lParen) || (s.indexOf('.') < 0 || s.indexOf('.') > lParen))	// Improper syntax
				return false;
			else if (s.substring(0, lastPeriod).equals("*..*")) {
				if(s.substring(lastPeriod + 1, lParen).equals("new")) {
					if(!checkParameters(_formalUnwrappedArguments, passingArgs))
						return false;	// No match
				} 
				else
					return false;	// Improper syntax
			} 
			else {
				if(_arguments.length < numArgs && !s.substring(lParen+1, rParen).equals(".."))
					return false;	//No match
				else if(!checkDeclarations(signDecl, s.substring(0, s.indexOf('('))) || !checkParameters(_formalUnwrappedArguments, passingArgs))
					return false;	//No match
			}	
		} 
		else if(s.indexOf(' ') < 0 || s.indexOf(' ') > s.indexOf('('))
			return false;	// Improper syntax
		else if(!checkArgument(_returnType, s.substring(0, s.indexOf(' ')))) 
			return false;	// Incorrect return type
		else 
			if(!checkDeclarations(signDecl, s.substring(s.indexOf(' ') + 1, s.indexOf('('))) || !checkParameters(_formalUnwrappedArguments, passingArgs))
				return false; 
		
		return true;	// Found a match!
	}
	
	/**
	 * Sets the Class of the Action.
	 * @param c the Class of the Action
	 */
	void setActionClass(Class<?> c){_className = c;}
	
	/**
	 * Sets the arguments of an Action from a specified array of Objects.
	 * @param args the Objects to be set as arguments
	 */
	void setArguments(Object[] args) {
		
		String temp = _signature.toString();
		
		_arguments = args;
		_formalWrappedArguments = _formalUnwrappedArguments = new String[args.length];
		
		if (args.length > 0) {
			_formalUnwrappedArguments = getAllArguments(temp.indexOf('('), temp.indexOf(')'), args.length, temp);
			for (int i = 0; i < args.length; i++) 
				if(args[i] != null)
					_formalWrappedArguments[i] = args[i].getClass().getSimpleName().trim();
		}
	}

	/**
	 * Sets the name of the file where the Action occurs.
	 * @param s the name of the file where the Action occurs
	 */
	void setCaller(Object c) { _caller = c; }

	/**
	 * Sets the name of the file where the Action occurs.
	 * @param s the name of the file where the Action occurs
	 */
	void setFileName(String s) {_fileName = s;}
	
	/**
	 * Sets the line number at which the Actoin occurs.
	 * @param number the line number at which the Action occurs
	 */
	void setLineNumber(int number){_lineNumber = number;}
	
	/**
	 * Sets the method of the Action.
	 * @param s the method of the Action
	 */
	void setMethod(String s){_method = s;}
	
	/**
	 * Sets a Reaction to an Action (usually from a survey).
	 * @param r the Reaction to be assigned
	 */
	public void setReaction(Reaction r){_reaction = r; _hasReaction = true;}
	
	/**
	 * Sets the object obtained from executing the Action.
	 * @param obj the Action's proceed() result to be set
	 */
	public void setResult(Object obj){_executionResult = obj; _hasResult = true;}
	
	/**
	 * Sets the return type of the Action.
	 * @param s the return type of the Action
	 */
	void setReturnType(String s) {_returnType = s;}
	
	/**
	 * Sets the Signature object of the Action. 
	 * @param s The Signature to be set
	 * @see Signature
	 */
	void setSignature(Signature s){
		String temp = s.toString();
		_signature = s;
		if (temp.indexOf(' ') < 0 || temp.indexOf(' ') > temp.indexOf('.')) {
			_returnType = "constructor";
			_method = temp;
		} 
		else {
			_returnType = temp.substring(0, temp.indexOf(' '));
			_method = temp.substring(temp.indexOf(' ') + 1);
		}
	}
	
	/**
	 * Sets the Class in which the Action occurs lexically
	 * @param c the Class in which the Action occurs lexically
	 * @see <code>joinpoint.getSourceLocation().getWithinType()</code>
	 */
	void setWithinType(Class<?> c) {_withinType = c;}
	
	/**
	 * Helper method for matches.
	 * <p>
	 * Checks the classes from an Action's Signature against the class
	 * declarations from the string to be matched.  Returns true if everything
	 * matches and false if anything doesn't match.
	 * 
	 * @param classDec the class declarations from an Action's Signature
	 * @param match the signature to be matched (not including arguments)
	 * @return true if the declarations match and false if they don't match
	 */
	private boolean checkDeclarations(String[] classDec, String match){
		boolean anything = false;
		if (match.indexOf(' ') < 0)
			//System.out.println(match);
			match = match.substring(match.indexOf(' ') + 1);
			//System.out.println(match);}
		if (match.lastIndexOf('.') == match.length() - 1)
			return false;	// Improper syntax
		
		String temp = "";
		int cIndex = 0, genCounter = 0;
		int dotIndex = 0, nextDotIndex = match.indexOf('.', dotIndex+1);
		
		while (dotIndex != -1 && cIndex < classDec.length) {
			while (nextDotIndex - dotIndex == 1 && dotIndex != 0) {
				if (++genCounter > 1)
					return false;		// Improper syntax
				dotIndex = nextDotIndex;
				nextDotIndex = match.indexOf('.', dotIndex+1);
				anything = true;
			}
			genCounter = 0;
			
			if (nextDotIndex == -1) 
				temp = match.substring(match.lastIndexOf('.')+1);
			else 
				if (dotIndex == 0)
					temp = match.substring(dotIndex, nextDotIndex);
				else
					temp = match.substring(dotIndex+1, nextDotIndex);
			
			if(anything) {
				if ((temp.equals("*") && nextDotIndex != -1 && match.substring(nextDotIndex+1).equals("new")) || 
						(temp.equals("*") && nextDotIndex == -1))//match.substring(nextDot)) 
					return true;
				
				while (!checkArgument(classDec[cIndex], temp)) {
					cIndex++;
					if (cIndex == classDec.length)
						return false;
				}
				anything = false;
			} 
			else if (!checkArgument(classDec[cIndex], temp)) 
				return false;
			else if (temp.equals("*") && dotIndex == 0 && match.indexOf('.', nextDotIndex+1) == -1) 
				return true; // Added to check *()
			else if (dotIndex == 0 && nextDotIndex == -1) // No seperators
				return false;
			
			dotIndex = nextDotIndex;
			nextDotIndex = match.indexOf('.', dotIndex+1);
			cIndex++;			
		}
		
		if ((nextDotIndex != -1 && dotIndex > 0) || (dotIndex != -1 && nextDotIndex > dotIndex))
			return false;
		if (!_returnType.equals("constructor"))
			if ((cIndex < classDec.length && dotIndex == -1) || (cIndex == classDec.length && dotIndex != -1))
				return false;	// Added to check *.*.*() and the like 
		
		return true;
	}
	
	/**
	 * Helps the matches method
	 * 
	 * @param s The signature of the called method
	 * @param numDots The number of dots separating the class libraries
	 * @return An array consisting of the separate libraries
	 */
	private String[] getDeclarations(String s, int numDots){
		int lastIndex = s.indexOf('('), dotIndex = s.lastIndexOf('.', lastIndex);
		String declarations[] = new String[numDots];
		
		for (int i = numDots-1; i >= 0; i--) {
			declarations[i] = s.substring(dotIndex+1, lastIndex).trim();
			lastIndex = dotIndex;
			dotIndex = s.lastIndexOf('.', lastIndex-1);			
		}
		
		if (declarations[0].indexOf(' ') > 0)
			declarations[0] = declarations[0].substring(declarations[0].indexOf(' ') + 1);
		
		return declarations;
	}
	
	/**
	 * Helps the matches method
	 * 
	 * @param lParen The index of the left parenth
	 * @param rParen The index of the right parenth
	 * @param numArgs The number of arguments passed
	 * @param s The signature of the called method
	 * @return An array consisting of the types of the arguments passed in the method
	 */
	private String[] getAllArguments(int lParen, int rParen, int numArgs, String s){
		int commaIndex = 0;
		int commaPosition[] = new int[numArgs];
		String passingArgs[] = new String[numArgs];
		
		for(int i = 0; commaIndex != -1; i++) {
			commaIndex = s.indexOf(',', commaIndex+1);
			commaPosition[i] = commaIndex;
		}
		
		if (numArgs > 1) {
			passingArgs[0] = s.substring(lParen+1, commaPosition[0]);			
			for (int i = 1; i < commaPosition.length - 1; i++)
					passingArgs[i] = s.substring(commaPosition[i-1]+1, commaPosition[i]);
			passingArgs[numArgs-1] = s.substring(commaPosition[numArgs-2]+1, rParen);
		} 
		else 
			passingArgs[0] = s.substring(lParen+1, rParen);
		
		for(int i = 0; i < numArgs; i++)
			passingArgs[i] = passingArgs[i].trim();
		
		return passingArgs;
	} 
	
	/**
	 * Helps the matches method
	 * 
	 * @param aArgs The argument types passed in the called method
	 * @param pArgs The argument types to check
	 * @return true if the parameters match, false otherwise
	 */
	private boolean checkParameters(String[] aArgs, String[] pArgs) {
		int pCount = 0;
		if (aArgs.length < pArgs.length) {
			if (pArgs.length == 1)
				return (pArgs[0].equals(".."));			
			return false;
		} 
		else if (pArgs.length == 0) 
			if (aArgs.length == 0)
				return true;
			else
				return false;
		else {	
			for (int i = 0; i < aArgs.length; i++ ) {
				if (checkArgument(aArgs[i], pArgs[pCount]))
					pCount++;
				else if (!checkArgument(aArgs[i], pArgs[pCount]) && !pArgs[pCount].equals(".."))
					return false;
				else {
					while (pCount < pArgs.length && pArgs[pCount].equals(".."))
						pCount++;
					
					if (pCount == pArgs.length)
						return true;
					do {
						i++;
						if(i == aArgs.length)
							return false;
					} while (!checkArgument(aArgs[i], pArgs[pCount]));
					
					pCount++;
					
				}
				if (pCount == pArgs.length && i != aArgs.length-1)
					return false;
			}
			if (pCount < pArgs.length-1)
				return false;
		}		
		
		return true;
	} 
	
	/**
	 * Helps the matches method
	 * 
	 * @param aArg The type of the argument being passed
	 * @param pArg The type of the argument to check
	 * @return true if the arguments match, false otherwise
	 */
	private boolean checkArgument(String aArg, String pArg){
		if (pArg.equals(""))
			return false;
		if (!aArg.equals(pArg)){
			boolean notFirst = false;
			int aCount = 0; int pCount = 0;
			while (true) {
				if (aArg.charAt(aCount) != pArg.charAt(pCount) && pArg.charAt(pCount) != '*')
					if (pCount != 0)
						notFirst = true;
					else
						return false;
				else if (aArg.charAt(aCount) == pArg.charAt(pCount)) {
					aCount++; pCount++;
					if (aCount == aArg.length() && pCount == pArg.length() ||
							(pCount == pArg.length()-1 && pArg.charAt(pCount) == '*')) 
						return true;
					else if (pCount == pArg.length() && aCount != aArg.length())
						return false;
					else if (pCount != pArg.length()&& aCount == aArg.length())
						return false;
				} 
				else if (pArg.charAt(pCount) == '*'){
					while (pArg.charAt(pCount) == '*' && pCount < pArg.length() - 1)
						pCount++;
					if (pCount == pArg.length() - 1 && pArg.charAt(pCount) == '*')
						return true;	
				}
				if (notFirst) {
					while (aArg.charAt(aCount) != pArg.charAt(pCount)){
						aCount++;
						if (aCount == aArg.length())
							return false;
					}
					notFirst = false;
				}	
			}
		} 
		return true;
	} 
		
} 