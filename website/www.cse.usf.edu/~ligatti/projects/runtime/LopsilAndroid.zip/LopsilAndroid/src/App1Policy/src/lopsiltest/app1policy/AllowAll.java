package lopsiltest.app1policy;
import lopsil.*;
import lopsil.device.*;

/**
 * The AllowAll policy is a template policy for more complex policy. It takes no action upon
 * location updates or security relevant methods.
 * 
 * @author Joshua Finnis
 */
public class AllowAll extends Policy {	
	public LocationDevice[] devices = { new AndroidGPS() };		
	public LocationGranularityAssumption lga = new LocationGranularityAssumption(15, Units.METERS);
	public FrequencyOfUpdatesAssumption foua = new FrequencyOfUpdatesAssumption(15000.0);
	public PolicyAssumptions pa = new PolicyAssumptions(this, devices, lga, foua);	
	
	// do nothing in the event of granularity or time of update violations
 	public void handleGranularityViolation() { }
	public void handleTimeOfUpdateViolation() { }
	
	// acknowledge receipt of location update but don't act upon it
	public synchronized void onLocationUpdate() {
		  System.out.println("new location = " + devices[0].getLocation());
	}	
	
	//allow any security relevant methods to proceed
	public synchronized Reaction react(Action a) { return new Reaction("ok"); }
}