package lopsil.device;

import java.util.ArrayList;

/** This class defines time-based  utilities used in LoPSiL
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Nalin Saigal
 * 
*/
public class LocBuffer
{
	private ArrayList<Locs> locations;	/* Set of locations in the buffer.*/
	private long bufferSize; /* Size of buffer, in terms of time.*/

	public LocBuffer(int time, int unit)  {
		bufferSize = (new Integer(time)).longValue() * 
					(new Double((Units.getMultiplier(unit)))).longValue();
		locations = new ArrayList<Locs>();
	}
	
	public void add(Location newLocation) {
		Locs newLoc = new Locs(newLocation, System.currentTimeMillis());
		locations.add(newLoc);
		this.trimBuffer();
	}
	
	public void trimBuffer() {
		long currentTime = System.currentTimeMillis();
		for (int i = 0; i < locations.size(); i++)
		{
			Locs tempLoc = locations.get(i);
			if (currentTime - tempLoc.timeStamp <= bufferSize)
				break;
			else
				locations.remove(i);
		}
	}
	
	public Locs earliest() {
		this.trimBuffer();
		return locations.get(0);
	}

}