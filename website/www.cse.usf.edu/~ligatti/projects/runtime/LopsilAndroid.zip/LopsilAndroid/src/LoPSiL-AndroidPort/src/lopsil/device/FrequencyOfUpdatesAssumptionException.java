package lopsil.device;

/**
 * Signals an error regarding the FrequencyOfUpdatesAssumption.
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * 
 * @see FrequencyOfUpdatesAssumption
 */
public class FrequencyOfUpdatesAssumptionException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 *
	 */
	public FrequencyOfUpdatesAssumptionException() { }

	/**
	 * Constructor with a specific message.
	 * @param message the message to be displayed
	 */
	public FrequencyOfUpdatesAssumptionException(String message) { super(message); }

	/**
	 * Constructor with a specific cause.
	 * @param cause the cause of Throw
	 */
	public FrequencyOfUpdatesAssumptionException(Throwable cause) { super(cause); }

	/**
	 * Constructor with a specific message and cause.
	 * @param message the message to be displayed
	 * @param cause the cause of Throw
	 */
	public FrequencyOfUpdatesAssumptionException(String message, Throwable cause) { super(message, cause); }
} 