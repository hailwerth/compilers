package lopsiltest.app3policy;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

/**
 * The PathOverlay class is used to draw lines connecting two longitude/latitude pairs.
 * 
 * @author Joshua Finnis
 */
public class PathOverlay extends Overlay {
	private GeoPoint start;
	private GeoPoint end;
	private int defaultColor;
	
	public PathOverlay(GeoPoint gp1,GeoPoint gp2, int color) {
		this.start = gp1;
		this.end = gp2;
		this.defaultColor = color;
	}
	  
	@Override
	public boolean draw(Canvas canvas, MapView mapView, boolean shadow, long when) {
	    // projection used to convert between screen pixels and lat/long pairs
		Projection projection = mapView.getProjection();
	    if (shadow == false) {     
		    Paint paint = new Paint();
		    paint.setAntiAlias(true);
	    	paint.setColor(defaultColor); 
		    paint.setStrokeWidth(3);
		    paint.setAlpha(120);   
		    
		    Point point = new Point();
		    Point point2 = new Point();
		    projection.toPixels(start, point);
		    projection.toPixels(end , point2);
		    
		    canvas.drawLine(point.x, point.y, point2.x,point2.y, paint);      
		}
	    return super.draw(canvas, mapView, shadow, when);
	}
}
