package lopsil.device;

/**
* This is a class meant for containing positions. 
*/
public class Position  {	
	public static final double EARTH_RADIUS = 3963.1676;	
	private double lat, lon, altitude;
	
	/**
	* Makes a new position. Initializes the latitude and the longitude to 0.
	*/
	public Position() {
		this(0,0);
	}
	
	/** 
	* Initializes the Position with la as the latitude and lo as the longitude.
	*/
	public Position(double la, double lo) {
		lat = la;
		lon = lo;
		altitude = 0.0;
	}
	
	/** 
	* Initializes the Position with la as the latitude, lo as the longitude and alt as the altitude.
	*/
	public Position(double la, double lo, double alt) {
		lat = la;
		lon = lo;
		altitude = alt;
	}

	/**
	 * Initializes the Position with degrees, minutes and seconds.
	 * When entering degrees, Latitude degrees South and Longitude degrees West must be entered as negative.
	 */
	public Position(double latDeg, double latMin, double latSec, double lonDeg, double lonMin, double lonSec) {
		lat = (Math.PI / 180.0d) * ((latDeg) + (latMin / 60.0d) + (latSec / 3600.0d));
		lon = (Math.PI / 180.0d) * ((lonDeg) + (lonMin / 60.0d) + (lonSec / 3600.0d));
		altitude = 0.0;
	}
	
	/**
	 * Initializes the Position with degrees, minutes, seconds and an altitude.
	 * When entering degrees, Latitude degrees South and Longitude degrees West must be entered as negative.
	 */
	public Position(double latDeg, double latMin, double latSec, double lonDeg, double lonMin, double lonSec, double alt) {
		lat = (Math.PI / 180.0d) * ((latDeg) + (latMin / 60.0d) + (latSec / 3600.0d));
		lon = (Math.PI / 180.0d) * ((lonDeg) + (lonMin / 60.0d) + (lonSec / 3600.0d));
		altitude = alt;
	}
		
	/**
	 * Checks to see if a Position lies within a specified radius of another Position.
	 * 
	 * @param pos2 the Position to center radius at
	 * @param dist the length of the radius
	 * @param scale the unit measurement of the distance
	 * @return true if the Position lies within specified radius, and false otherwise
	 */
	public boolean isWithin(Position pos2, double dist, int scale){
		double multiplier = Units.getMultiplier(scale);		
		return (this.getDistanceFrom(pos2)) < (dist * multiplier);
	}
	
	/**
	 * Checks to see if a Position lies within a specified radius of any Position
	 * within an array.
	 * 
	 * @param posArray the Position array
	 * @param dist the length of the radius
	 * @param scale the unit measurement of the distance
	 * @return true if the Position lies within specified radius of every Position in the array, and false otherwise
	 */
	public boolean isWithin(Position[] posArray, double dist, int scale){
		if(posArray.length != 0){
			for(int i = 0; i < posArray.length; i++)
				if(this.isWithin(posArray[i], dist, scale))
					return true;
		}
		return false;
	}
		
	/**
	* Sets the latitude of this position.
	*/
	public void setLatitude(Double l) { lat = l; }

	/**
	* Sets the longitude of this position.
	*/
	public void setLongitude(Double l) { lon = l; }
	
	/**
	* Returns the latitude of this position.
	*/
	public Double getLatitude() { return lat; }
	
	/**
	* Returns the longitude of this position.
	*/
	public Double getLongitude() { return lon; }
	
	/**
	 * Sets the altitude of this position.
	 */
	public void setAltitude(double alt) { altitude = alt; }
	
	/**
	 * Returns the altitude of this position.
	 */
	public double getAltitude() { return altitude; }
	
	/**
	 * Return the distance (in miles) from another GPS Position.
	 * 
	 * @param pos the Position to calculate distance from
	 * @return the distance from the specified position
	 */
	public double getDistanceFrom(Position pos) {	
		double thisLatRad = this.getLatitude() * Math.PI / 180.0;
		double thisLonRad = this.getLongitude() * Math.PI / 180.0;
		double latRad = pos.getLatitude() * Math.PI / 180.0;
		double lonRad = pos.getLongitude() * Math.PI / 180.0;
		
		double distance = EARTH_RADIUS * Math.acos(Math.sin(thisLatRad)*Math.sin(latRad) +
		         Math.cos(thisLatRad)*Math.cos(latRad)*Math.cos(thisLonRad - lonRad));
		
		return distance;		
	}

	public String toString() { return "lat = " + lat + " long = " + lon; }	
}
