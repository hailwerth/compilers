package lopsil.device;

import lopsil.Policy;
import android.util.Log;

/**
 * FrequencyOfUpdatesAssumption checks to make sure that a GPS LocationDevice is updating
 * at least at a specific user-defined interval.
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Joshua Finnis
 *
 */
public class FrequencyOfUpdatesAssumption implements Runnable {
	private long _msec;
	private volatile LocationDevice[] _gd;
	private Policy _policy;	

	public long getMilliseconds() { return _msec; }	

	/**
	 * Construct a newly allocated FrequencyOfUpdatesAssumption with a specified time
	 * @param time the time interval (in milliseconds) at which to check
	 */
	public FrequencyOfUpdatesAssumption(double time) { _msec = (long) time; }

	/**
	 * Construct a newly allocated FrequencyOfUpdatesAssumption with an existing FrequencyOfUpdatesAssumption
	 * and an array of LocationDevices
	 * @param t the existing FrequencyOfUpdatesAssumption
	 * @param locationDevice the LocationDevices to use the FrequencyOfUpdatesAssumption
	 * @param p the existing Policy 
	 */
	public FrequencyOfUpdatesAssumption(FrequencyOfUpdatesAssumption t, LocationDevice[] locationDevice, Policy p) {
		_msec = t.getMilliseconds();
		_policy = p;
		_gd = locationDevice;
	}
	
	/**
	 * Compare the location update time with the current system time to make sure the device
	 * is updating at within the specified interval.
	 */
	public void run(){
		while (true) {
			try {
				Thread.sleep(_msec);
				for (int i = 0; i < _gd.length; i++) {
					if (_gd[i].isGPS()) {
						if (!_gd[i].isUpdated()) {							
							try { 
								_policy.handleTimeOfUpdateViolation(); 
							} 
							catch(Exception ex) { 
								Log.d("LoPSiL_FrequencyOfUpdatesAssumption", "Exception handling time violation, exiting");
								System.exit(1);	
							}
						}
						_gd[i].setNotUpdated();
					}
				}
			} 
			catch (Exception e) {
				Log.d("LoPSiL_FrequencyOfUpdatesAssumption", "Exception, exiting");
				System.exit(1);
			}
		}
	}
}