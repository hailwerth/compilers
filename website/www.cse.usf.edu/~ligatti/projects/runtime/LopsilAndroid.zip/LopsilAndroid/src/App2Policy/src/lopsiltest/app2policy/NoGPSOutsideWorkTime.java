package lopsiltest.app2policy;
import lopsil.Action;
import lopsil.Policy;
import lopsil.PolicyAssumptions;
import lopsil.Reaction;
import lopsil.device.AndroidGPS;
import lopsil.device.FrequencyOfUpdatesAssumption;
import lopsil.device.LocationDevice;
import lopsil.device.LocationGranularityAssumption;
import lopsil.device.Units;
import android.app.Activity;

/**
 * The NoGPSOutsideWorkTime policy is allows messages containing a location to be sent 
 * to a remote server during work time, but uses a replace reaction to send no messages outside
 * of work time.
 * 
 * @author Joshua Finnis
 */
public class NoGPSOutsideWorkTime extends Policy {	
	// for experimentation, set work time to end halfway through experiment
	double endWorkTime = System.currentTimeMillis() + 125000;    // 125 seconds from start
	public boolean isWorkTime() { return System.currentTimeMillis() < endWorkTime; }

	// Activity is the Android application type, it is needed to interact with
	// Android's user interface
	private WorkReport _act;        				
	public NoGPSOutsideWorkTime(Activity act) { _act = (WorkReport) act; }	
	
	public LocationDevice[] devices = { new AndroidGPS() };		
	public LocationGranularityAssumption lga = new LocationGranularityAssumption(15, Units.METERS);
	public FrequencyOfUpdatesAssumption foua = new FrequencyOfUpdatesAssumption(15000.0);
	public PolicyAssumptions pa = new PolicyAssumptions(this, devices, lga, foua);	
	
	// do nothing in the event of granularity or time of update violations
	public void handleGranularityViolation() { }
	public void handleTimeOfUpdateViolation() { }
	
	// if the security relevant function writes to a remote socket and it is not during 
	// work time, then replace the function with a null function (do nothing instead).
	// otherwise, proceed with the function 
	public synchronized Reaction react(Action a) {
		if (matchesGPSRead(a) && !isWorkTime()) {
			_act.loc.setText("not at work\n");
			//return a null location to the application
			return new Reaction("replace", null);
		}
		else {
			_act.loc.setText("at work\n");
			return new Reaction("ok"); 
		}
	}
	
	private boolean matchesGPSRead(Action a) {
		if (a.getMethod().contains("println")) 		// for socket.println()
			return true;
		else 
			return false;
	}		
}