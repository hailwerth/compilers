package lopsil.device;

import lopsil.LopsilUtil;
import lopsil.Policy;

/**
 * This abstract class is the base class for any type of Geographical device that is
 * to be used with the LoPSiL package.
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 *
 */
public abstract class LocationDevice {
	
	/** Instance Fields */
	protected boolean _gps, _valid;
	protected volatile boolean _updated;
	protected FrequencyOfUpdatesAssumption _foua;
	protected LocationGranularityAssumption _gran = new LocationGranularityAssumption(Units.INFINITY, Units.FEET);
	protected static Policy _securityPolicy;
	
	/**
	 * Checks to see if the device is a GPS device.
	 * @return true if the device is a GPS device and false otherwise
	 */
	public boolean isGPS() { return _gps; }
	
	/**
	 * Checks to see if the device is valid.
	 * @return true if the device is valid and false otherwise
	 */
	public boolean isValid() { return _valid; }
	
	/**
	 * Checks to see if device has been updated.
	 * @return true if device has been updated, and false otherwise
	 */
	synchronized boolean isUpdated() { return _updated; }
	
	/**
	 * Sets the device status as 'not updated'
	 */
	synchronized void setNotUpdated() { _updated = false; }
	
	/**
	 * Sets the device status as 'updated'
	 */
	synchronized void setUpdated() { _updated = true; }
	
	/**
	 * Sets a device to be valid.
	 */
	public void setValid() { _valid = true; }

	/**
	 * Sets a device to be a gps.
	 */
	public void setGPS() { _gps = true; }

	/**
	 * Sets the security policy of a location device.
	 * @param p the security policy associated with the location device
	 */
	public void setPolicy(Policy p) { _securityPolicy = p; }
	
	/**
	 * Returns the previous Locations (use with GPS devices)
	 * @return an array of previous (GPS) Locations
	 */
	public Location[] getPreviousLocations() { return new Location[0]; }
	  
	/**
	 * Abstract method to return the device location.
	 * @return the Location object of the device
	 */
	public abstract Location getLocation();
	
	/**
	 * Abstract method to set the device location.
	 * @param l the Location object that is to be set
	 */
	public abstract void setLocation(Location l);
	
	/** 
	 * Returns the LocationGranularityAssumption of a device.
	 * @return the LocationGranularityAssumption of a device
	 */
	public LocationGranularityAssumption getGranularity() { return _gran; }
	
	/**
	 * Returns the Position specifying the location of a GPS LocationDevice.
	 * @return the location specified by a GPS LocationDevice
	 */
	public Position getGPSDeviceLocation() { return this.getLocation().getGPSLocation(); }
	
	/**
	 * Sets the FrequencyOfUpdatesAssumption to be used with GPS LocationDevices.
	 * @param foua the TimeOfUpdateAssuption to be set
	 */
	void setFrequencyOfUpdatesAssumption(FrequencyOfUpdatesAssumption foua) { _foua = foua; }
	
	/**
	 * Returns the FrequencyOfUpdatesAssumption for the LocationDevice
	 * @return the FrequencyOfUpdatesAssumption for the LocationDevice
	 */
	FrequencyOfUpdatesAssumption getFrequencyOfUpdatesAssumption() { return this._foua; }
	
	/**
	 * Checks to see if a Location has been updated within a specific time interval
	 * @param time
	 * @param measurement
	 * @return true if the Location has been updated within the time interval, and false otherwise
	 */
	public boolean isUpdatedWithin(double time, int measurement) {
		switch (measurement) {
			case LopsilUtil.SECONDS:
				time *= 1000.0;
				break;
			case LopsilUtil.MINUTES:
				time *= 60000.0;
				break;
			case LopsilUtil.HOURS:
				time *= 3600000.0;
				break;			
		}		
		return System.currentTimeMillis() - this.getLocation().getLastTimeOfUpdate() < time;
	}	
}