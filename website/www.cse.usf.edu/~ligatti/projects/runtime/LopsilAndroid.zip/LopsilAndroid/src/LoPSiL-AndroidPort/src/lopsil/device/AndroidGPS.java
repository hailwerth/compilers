package lopsil.device;

/**
 * This class is the implementation of the abstract class LocationDevices for the Andriod platform.
 * 
 * @author Joshua Finnis
 */
public class AndroidGPS extends LocationDevice {
	private static Location _location;	
	private static final double _granLength = 5.0;
	private static final int _granScale = Units.METERS;	
	
	/**
	 * Concrete method to return the device location.
	 * @return the Location object of the device
	 */
	public Location getLocation() { return _location; }
	
	/**
	 * Concrete method to set the device location.
	 * @param l the Location object that is to be set
	 */
	public void setLocation(Location l) { 
		_location.setGPSLocation(l.getGPSLocation()); 
		setUpdated();
		if (_securityPolicy != null)
			_securityPolicy.onLocationUpdate();
	}	
	
	/**
	 * Construct a newly allocated AndroidGPS.
	 */
	public AndroidGPS() {
		setGPS();
		_location = new Location();	
		_gran = new LocationGranularityAssumption(_granLength, _granScale);	
	}	
} 