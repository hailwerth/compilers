package lopsil.device;

import lopsil.LopsilException;
import android.util.Log;

/**
 * LocationGranularityAssumption allows for the specification of the accuracy of a GPS device. 
 * 
 * @author Billy Rickey
 * @author Jay Ligatti
 * @author Nalin Saigal
 * 
 */
public class LocationGranularityAssumption {
	private double _value;
	public static final double YARDS = 1.0;
	public static final double FEET = 1.0/3.0;
	public static final double INCHES = 1.0/36.0;
	public static final double MILES = 1760.0;
	public static final double METERS = 100.0/2.54/36.0;
	public static final double CENTIMETERS = 1.0/2.54/36.0;
	public static final double INFINITY = 1.0/0.0;
	
	/**
	 * Construct a newly allocated LocationGranularityAssumption
	 * @param length the length of the granularity
	 * @param measurement the measurement to be used
	 */
	public LocationGranularityAssumption(double length, int measurement) {
		try {
			constructTest(measurement);
			_value = length * Units.getMultiplier(measurement);
		} catch (Exception e) {
			Log.d("LoPSiL_LocationGranularity", "Exception during constructtest, exiting");
			System.exit(1);
		}
	}
	
	/**
	 * Checks to see if the granularity complies with another granularity.
	 * @param gps the granularity to check against
	 * @return true if the granularity complies and false otherwise
	 */
	public boolean compliesWith(LocationGranularityAssumption gps){
		return (this._value <= gps.getValue(YARDS));
	}
	
	/**
	 * Returns the value of the granularity in the specified measurement.
	 * @param measurement the desired measurement for the returned LocationGranularityAssumption value
	 * @return the value of the granularity in the specified measurement
	 */
	public double getValue(double measurement){return _value / measurement;}

	/**
	 * Method to ensure the proper initialization of a LocationGranularityAssumption
	 * @param scale the measurement to be tested
	 * @throws LopsilException
	 */
	private void constructTest(int scale) throws LopsilException
	{
		if (scale != Units.INCHES && scale != Units.FEET && scale != Units.METERS
			&& scale != Units.CENTIMETERS && scale != Units.YARDS &&
			scale != Units.MILES && scale != Units.KILOMETERS && scale != Units.INFINITY)
			throw new LopsilException("Improper initialization of " + this.getClass());
	}
} 