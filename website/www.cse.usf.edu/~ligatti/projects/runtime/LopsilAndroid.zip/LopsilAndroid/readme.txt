---------------------------------------------------
Copyright (c) 2010 University of South Florida
---------------------------------------------------

LoPSiL - A Location-based Policy Specification Language for Mobile Devices
by Joshua Finnis, Nalin Saigal, Anda Iamnitchi, and Jay Ligatti

Implementation by: Joshua Finnis, Billy Rickey, Nalin Saigal, and Jay Ligatti

******************
** Introduction **
******************
LoPSiL is a location-based policy specification language that helps 
users specify policies that are location dependent. This package contains the 
source LoPSiL implementation on Android and the example applications and 
policies referred to in the paper. You can contact us to report for bugs or 
improvements to LoPSiL at the following email addresses:
    jfinnis@cse.usf.edu, nsaigal@cse.usf.edu, ligatti@cse.usf.edu


*******************************
** Installation Instructions **
*******************************
The following tools are required to compile LoPSiL policies for Android 
applications:
    Eclipse 
        - http://www.eclipse.org/
    AspectJ Developers Tools (AJDT) plugin for Eclipse 
        - http://www.eclipse.org/ajdt/
    Android SDK 
        - http://developer.android.com/sdk/index.html
    Android Development Tools (ADT) plugin for Eclipse 
        - http://developer.android.com/sdk/eclipse-adt.html

Once these tools are installed and configured, one of the following methods can 
be used to add LoPSiL policy enforcement to an Android application within 
Eclipse.

The following instructions have been tested on Android OS 1.5.

*************************************************
** To compile the example Android applications **
*************************************************
1. Right-click on Lopsil-AndroidPort.zip and choose Extract All. The path to 
   these extracted files will be referred to as %path-to-lopsil%.

2. Start Eclipse and click New->Java Project. 

3. Select Create Project From Existing Source. Type 
   %path-to-lopsil%/src/AppXPolicy as the location. 

4. Select an Android Virtual Device version 1.5 or higher as the Build Target.

5. Click Add External Jar and select the aspectjrt.jar, located in 
   %aspectJ-path%/lib/.

6. Click Add External Jar and select the LopsilAndroid.jar, located in 
   %path-to-lopsil%/src.

7. Right click on the project and select Run As->Android Application.

*************************************************************************
** To add LoPSiL policy enforcement to an existing Android application **
*************************************************************************
1. Right-click on Lopsil-AndroidPort.zip and choose Extract All. The path to 
   these extracted files will be referred to as %path-to-lopsil%.

2. Right click on the project in the Eclipse navigator and select Properties. 
   Select Java Build Path and choose the Libraries tab.

3. Click Add External Jar and select the aspectjrt.jar, located in 
   %aspectJ-path%/lib/.

4. Click Add External Jar and select the LopsilAndroid.jar, located in 
   %path-to-lopsil%/src.

5. Create a new Java file. Use one of the example LoPSiL policy files in 
   %path-to-lopsil%/src/AppXPolicy/src/lopsiltest/appxpolicy/ as a template.

6. Create a new Aspect.aj file. Use one of the example Aspect.aj in 
   %path-to-lopsil%/src/AppXPolicy/src/lopsiltest/appxpolicy/ as a template.
   Modify the text to reference the LoPSiL policy created in the previous step.

7. Right click on the project and select Run As->Android Application.

*******************************************************
** Running the provided example Android Applications **
*******************************************************
1. Right-click on Lopsil-AndroidPort.zip and choose Extract All. The path to 
   these extracted files will be referred to as %path-to-lopsil%.

2. Ensuring you have an Android device connected to your computer, use one of 
the following commands to install the application:
    (device) ----> adb -d install %path-to-lopsil%/%application-name%.apk 
    (emulator) --> adb -d install %path-to-lopsil%/%application-name%.apk

where %application-name% is one of the following:
    App1NoPolicy - Numeric Computation application with no policy-enforcement
    App1Policy   - Numeric Computation application which invokes an AllowAll 
                   policy
    App2NoPolicy - Work Report application with no policy-enforcement
    App2Policy   - Work Report application which prevents updates from being 
                   sent to a server using an NoGPSOutsideWorkTime policy
    App3NoPolicy - Expected Path application with no policy-enforcement
    App3Policy   - Expected Path application which calls a ShowNavigationAid 
                   policy
    App4NoPolicy - MapDisplay application with no policy-enforcement
    App4Policy   - MapDisplay application which invokes the 
                   InviteFriendsAfterTravel policy

3. Select MENU on the Android device and start the installed application.

