// Copyright (c) 2008-2009 University of South Florida
// www.csee.usf.edu/~ligatti/projects/poliseer/

*****    PoliSeer version 0.9.0    *****

{Introduction}
	This is a research-quality implementation of the PoliSeer project,
    which is a tool for more conveniently visualizing, specifying, analyzing,
    and updating policies written mainly by Daniel Lomsak under the advisement
    of Jay Ligatti and with contributions by Christine Cortes in the formative
    stages of development. This version of PoliSeer supports only policies in
    the Polymer language. The Polymer project can be found at
    www.cs.princeton.edu/sip/projects/polymer. Using PoliSeer with a different
    policy language requires modification of the files in poliseer/frontend and
    poliseer/backend.


{Release Notes}
    As an academic project, PoliSeer works well in our testing but should not
    be considered industrial-grade. We have composed policies with far less
    tedium compared to the textual approach, exported them, and found them to
    be readily compilable by Polymer. Also, we find that PoliSeer can cope with
    expanding directories with many policy files without any serious pause. 
    While there are no outstanding known errors in this release, it has not
    been tested in any rigorous way. If you discover any errors in this program
    we encourage you to send an email to one of the following addresses:
    dlomsak@cse.usf.edu	or ligatti@cse.usf.edu

	
{Installation and Execution}
	To unzip and compile the poliseer source, run the "install.sh" script.
    To run poliseer after it has been installed, run the "run.sh" script. As an
    additional measure, it is recommended that you add the base polymer
    directory to your classpath. You may also find it convenient to pool your
    policies in a common directory and add that directory to your classpath
    as well. Poliseer refers to policy instances by their fully-qualified
    name (package.classname) in the exported policies, and it determines this
    name based on the policy location and the classpath. This version of
    PoliSeer was installed and run successfully with Java(TM) version 1.6. 


{Examples}
	PoliSeer ships with one security policy (its own!) which can be found
    in the poliseer/policy directory. You can load the policy tree by selecting
    'Load Tree' from the 'File' menu and selecting 
    'poliseer/policy/PolPoliseer.psr'. If your classpath has been set up
    properly, the tree should load without any further effort. Otherwise, you
    will be prompted to find the individual policy files manually. This policy
    can be written out to Polymer code by selecting 'Export Policy' from the
    'file' menu. The result of this export ships at
    'poliseer/policy/PolPoliseer.poly'.


{Included Software}
	Besides PoliSeer, we also have included some policy files that make-up
    a sample security policy that ensures PoliSeer does not make network
    connections nor access any files except .poly and .psr files. This policy
    is not intended to be a thorough treatment of PoliSeer's possible
    vulnerabilities, but rather as an example of how this tool is useful for
    managing a security policy hierarchy. Some of the policy files included
    were copied from the Polymer distribution and in some cases were modified.
    The copyright comments in the copied files remains unchanged if unmodified.
    The Polymer parser grammar was copied verbatim except for a change in the
    package declaration.