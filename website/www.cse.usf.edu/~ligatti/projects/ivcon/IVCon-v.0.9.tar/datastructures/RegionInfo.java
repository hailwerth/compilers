/* The RegionInfo datastructure */
package datastructures;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RegionInfo implements Serializable, Comparable
{
	public int begPos, endPos;
	public String regionName;
	public List arrayListOfConcerns = new ArrayList();
	public RegionInfo(String name, List concernList, int begpos, int endpos)
	{
		regionName = name;
		begPos = begpos;
		endPos = endpos;
		arrayListOfConcerns = concernList;
	}
	public RegionInfo(RegionInfo regionCopy)
	{
		regionName = regionCopy.regionName;
		begPos = regionCopy.begPos;
		endPos = regionCopy.endPos;
		arrayListOfConcerns = regionCopy.arrayListOfConcerns;
	}
	public void display()
	{
		System.out.println(regionName + ": " + begPos + ", " + endPos);
		for (int i = 0; i < arrayListOfConcerns.size(); i++)
			System.out.println(arrayListOfConcerns.get(i));
	}
	public boolean equals(RegionInfo equateRegion)
	{
		if (begPos == equateRegion.begPos && endPos == equateRegion.endPos)
			return true;
		else
			return false;
	}
	public int compareTo(Object o)
	{
		return ((Integer)begPos).compareTo((Integer)(((RegionInfo)o).begPos));
	}
}