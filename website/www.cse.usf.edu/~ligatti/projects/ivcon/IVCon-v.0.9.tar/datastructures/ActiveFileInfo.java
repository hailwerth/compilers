/* The file structure as defined by IVCon*/
package datastructures;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;
import javax.swing.text.*;
import spatialindex.rtree.*;
import java.util.HashMap;
import javax.swing.*;
import java.io.*;

public class ActiveFileInfo
{
	public Color MCB;							//MCB: Multiple Concerns Background
	public HashMap concMap;
	public HashMap regionMap;
	public RTree regionTree;
	public int noOfConcerns, totalRegions, saved;
	public boolean viewFlags;
	public JScrollPane scrollPane;
	public JSplitPane splUnwoven, splPreview;
	public JTextPane wovenCode, concernLegend, currentConcerns;
	public JTextPane unwovenBody, unwovenConcerns;
	public AbstractDocument woven, legend, current;
	public AbstractDocument body, concerns;
	public File file;

	public ActiveFileInfo(HashMap concmap, HashMap regionmap, int noConcs, int noRegions, int ses,
		RTree rtree, boolean vFlags, Color mcb, JScrollPane scrPn, JSplitPane splUwn, JSplitPane splPrw,
		JTextPane wCode, JTextPane cLegend, JTextPane cConcerns, JTextPane uwBody,
		JTextPane uwConc, AbstractDocument wcode, AbstractDocument leg,
		AbstractDocument cacp, AbstractDocument uwbody, AbstractDocument uwconc, File fl)
	{
		saved = ses;
		concMap = concmap;
		regionMap = regionmap;
		noOfConcerns = noConcs;
		totalRegions = noRegions;
		scrollPane = scrPn;
		splUnwoven = splUwn;
		splPreview = splPrw;
		regionTree = rtree;
		wovenCode = wCode;
		concernLegend = cLegend;
		currentConcerns = cConcerns;
		unwovenBody = uwBody;
		unwovenConcerns = uwConc;
		MCB = mcb;
		woven = wcode;
		legend = leg;
		current = cacp;
		body = uwbody;
		concerns = uwconc;
		viewFlags = vFlags;
		file = fl;
	}

	/* Updates the RTree of the ActiveFileInfo object. Used because 
	 * new RTrees are created during weaving and unweaving */
	public void updateRTree(RTree newRTree)
	{ regionTree = newRTree; }

	public void updateViewFlagState(boolean state)
	{ viewFlags = state; }
	public void display() //Used for debugging
	{
		System.out.println("MCB = " + MCB);
		System.out.println("Total concerns = " + noOfConcerns);
		System.out.println("Total regions = " + totalRegions);
		System.out.println("unwoven body = " + unwovenBody.hashCode());
	}
}