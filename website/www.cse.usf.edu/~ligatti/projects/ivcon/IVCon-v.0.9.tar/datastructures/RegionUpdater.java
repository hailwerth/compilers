/*Data structure for updating regions as user types within IVCon*/
package datastructures;

public class RegionUpdater
{
	public int startPosition, charTyped;
}