/* The file structure as defined by IVCon*/
package datastructures;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;
import javax.swing.text.*;
import spatialindex.rtree.*;
import java.util.HashMap;

public class FileStruct implements Serializable
{
	static final long serialVersionUID = 4553850017097960722L;
	public String fileText;
	public StyledDocument wovenCodeAbstractDoc;
	public Color MCB;							//MCB: Multiple Concerns Background
	public HashMap concMap;
	public HashMap regionMap;
	public RTree regionTree;
	public int noOfConcerns, totalRegions;

	public FileStruct(String filetext, HashMap concmap, HashMap regionmap, int noConcs,
		int noRegions, RTree rtree, StyledDocument abstractDoc, Color mcb)
	{
		fileText = filetext;
		concMap = concmap;
		regionMap = regionmap;
		noOfConcerns = noConcs;
		totalRegions = noRegions;
		regionTree = rtree;
		wovenCodeAbstractDoc = abstractDoc;
		MCB = mcb;
	}
}