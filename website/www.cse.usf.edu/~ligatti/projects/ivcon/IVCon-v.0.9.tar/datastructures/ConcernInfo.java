/* The ConcernInfo datastructure */
package datastructures;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;

public class ConcernInfo implements Serializable
{
	public Color clr;
	public List arrayListOfRegions = new ArrayList();
	public ConcernInfo(Color color, List regionList)
	{
		clr = color;
		arrayListOfRegions = regionList;
	}
}