// Copyright (c) 2009 University of South Florida
// www.cse.usf.edu/~ligatti/projects/ivcon

IVCon - Inline Visualization of Concerns
Version 0.9

** Introduction **
This is a research-quality implementation, meaning that it is
unoptimized and contains bugs.  However, in our tests, the current
implementation has performed resonably efficiently and reliably.

We would love to hear about your improvements to and use of IVCon.  You
can contact us at the following email addresses:
nsaigal@cse.usf.edu, ligatti@cse.usf.edu


** Installation instructions **
0) If you do not have it already, download and install the Java(TM) 2
Runtime Environment, Standard Edition, version 1.6.0.  Although it
should work with later versions of Java, IVCon has only been tested
with Java version 1.6.0.

1) Throughout these instructions we assume that you have extracted
IVCon into the directory c:\IVCON.

2) Set your classpath to include the following directories:
    c:\IVCON\, c:\IVCON\spatialindex.java\lib\, c:\IVCON\lexer\

3) Change to the directory c:\IVCON\lib by executing the command:
  cd\IVCON\lib

4) Compile the IVCon source code by executing the command:
  javac IVCON.java

5) Run IVCon by executing the command
  java IVCON


** Included Software **

1) RTrees by Marios Hadjieleftheriou available at
http://www.research.att.com/~marioh/spatialindex/index.html.  This code
is released under the GNU GPL license.
2) A clipboard implementation, by Hirondelle Systems available for
download at http://www.javapractices.com/topic/TopicAction.do?Id=82.
This code is released under the Creative Commons Attribution 3.0
Unported license.
3) JavaCC lexer and Java grammar, available for download at
https://javacc.dev.java.net/.  This code is released under the BSD
license.

** Known Bugs **

In the unwoven-concerns panel, users can not select text from a later
character position to an earlier character position.
