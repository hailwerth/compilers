import java.util.*;
import java.io.*;

//import spatialindex.spatialindex.*;
//import spatialindex.storagemanager.*;
//import spatialindex.rtree.*;

/**
 * Summary description for Class1.
 */
public class RtreeDemo
{
	public RtreeDemo()
	{
		//
		// TODO: Add Constructor Logic here
		//
	}
	public static void main(String args[])
	{
		//System.out.print(args[0]);
		RTree rt;
	}
}
