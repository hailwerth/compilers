/* TokenVerifier.java: Communicates with the Lexer we define and performs
 Lexer actions in IVCON */

import datastructures.*;
import java.io.*;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;

import lexer.*;

import spatialindex.rtree.*;
import spatialindex.spatialindex.*;
import spatialindex.storagemanager.*;

class TokenVerifier
{
	/* Variables for communication with other classes */
	Windows mainWindow;
	ConcernManipulation concMan;

	private boolean tokensOK = true;

	/* Returns the value of the tokensOK variable */
	public boolean getTokensOK()
	{ return tokensOK; }

	/* Lexes the expression given to it and adds the start and end of tokens 
	 * to different Lists to analyse later. variable woven is to tell function
	 * where the call came so to display the appropriate error msg if reqd */
	void lexAndAddPositions(String expression, boolean woven)
	{
		int startOfToken = 0;
		{
			Token token = new Token();
			Lexer lexer = new Lexer(new StringReader(expression));
			try
			{
				int endOfToken = 0;
				while (true)
				{
					token = lexer.getnexttoken();
					if ((token.image).equals(new String("")))	//i.e. no more tokens left
						break;
					endOfToken = (startOfToken + (token.image).length() - 1);

					concMan.add("regionStartPosition", startOfToken);
					concMan.add("regionEndPositions", endOfToken);
					if ((token.image).equals(new String("\t")))
						startOfToken += 1;
					else
						startOfToken += (token.image).length();
				}
			}
			catch (TokenMgrError e)
			{
				if (woven)
				{
					JOptionPane.showMessageDialog(mainWindow.frame,
						"<html><B>Invalid Token: " +
						mainWindow.getText("wovenCode", startOfToken, 1),
					"Error", JOptionPane.ERROR_MESSAGE);
					mainWindow.select("wovenCode", startOfToken, startOfToken + 1);
				}
				tokensOK = false;
				return;
			}
			catch (ParseException pe)
			{
				/* We dont throw an exception here because we only lex*/
			}
		}
	}
}