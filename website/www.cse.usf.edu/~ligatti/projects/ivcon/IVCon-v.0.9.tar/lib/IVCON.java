/* IVCON.java: Main IVCON file, where we invoke all components.*/

import javax.swing.*;
import datastructures.*;

public class IVCON
{
	private static void createAndShowGUI()
	{
		//Set up all backend variables
		RTreeInterface regionTree = new RTreeInterface();
		Windows mainWindow = new Windows();
		ConcernManipulation concMan = new ConcernManipulation();
		FileUtilities fileMan = new FileUtilities();
		//Link all backend variables
		regionTree.concMan = concMan;
		regionTree.mainWindow = mainWindow;
		mainWindow.concMan = concMan;
		mainWindow.fileMan = fileMan;
		mainWindow.regionTree = regionTree;
		concMan.mainWindow = mainWindow;
		concMan.regionTree = regionTree;
		fileMan.mainWindow = mainWindow;
		fileMan.concMan = concMan;
		fileMan.regionTree = regionTree;
		//Create main frame
		mainWindow.frame = new JFrame("IVCon - Inline Visualization of Concerns");
		mainWindow.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Create&set menu bar and content pane.
		mainWindow.frame.setJMenuBar(mainWindow.createMenuBar());
		mainWindow.frame.setContentPane(mainWindow.createContentPane("Untitled"));
		ActiveFileInfo currentFile = new ActiveFileInfo(concMan.getMap("concernMap"), concMan.getMap("regionMap"),
								concMan.getNoOfConcerns(), concMan.getNoOfRegions(), 0, regionTree.getRTree(), false,
								concMan.getMCB(), mainWindow.getScrPan(), mainWindow.getSplitUnwoven(), mainWindow.getSplitPreview(),
								mainWindow.getWovenCode(), mainWindow.getLegend(),
								mainWindow.getCurrentConcerns(), mainWindow.getUnwovenBody(),
								mainWindow.getUnwovenConcerns(), mainWindow.getAbstractDocument("wovenCode"),
								mainWindow.getAbstractDocument("concernLegend"),
								mainWindow.getAbstractDocument("currentConcerns"),
								mainWindow.getAbstractDocument("unWovenBody"),
								mainWindow.getAbstractDocument("unWovenConcerns"), null);
		mainWindow.addToActiveFileList((mainWindow.getTotalTabs() - 1), currentFile);
		mainWindow.createPopupMenu();
		//Display the window.
		mainWindow.frame.setSize(878, 562);
		mainWindow.frame.setVisible(true);
	}

	public static void main(String[] args)
	{
		/* Schedule a job for the event-dispatching thread:
		creating and showing this application's GUI. */
		javax.swing.SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				createAndShowGUI();
			}
		});
	}
}