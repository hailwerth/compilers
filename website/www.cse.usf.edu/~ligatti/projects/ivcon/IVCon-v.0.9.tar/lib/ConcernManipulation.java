/* ConcernManipulation.java: Is the center for all concerns-related operations. */

import java.util.Scanner;
import datastructures.*;
import java.io.*;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import java.util.HashMap;

import lexer.*;

import spatialindex.rtree.*;
import spatialindex.spatialindex.*;
import spatialindex.storagemanager.*;

class ConcernManipulation implements ListSelectionListener
{
	final static Border BORDER = BorderFactory.createEtchedBorder();

	/*  Elements of the preview pane used in renaming code-regions*/
	private JTextPane previewText;
	private StyledDocument previewStyledDoc;
	private AbstractDocument previewAbstractDoc;
	private JList list = new JList();
	private int listCaller = 0;
	private List holeJoinPoints = new ArrayList();

	/* Elements describing the state of the backend at a point*/
	private Color MCB = Color.DARK_GRAY;	//MCB:Multiple Concern Background
	private boolean woven = true;	// Whether current view is woven or unwoven
	private boolean viewFlags = false;
	private int noOfConcerns = 0;
	private int uniqueId = 0;
	private int totalRegions = 0;
	private File fileopen;				//File currently open
	private HashMap concernMap = new HashMap();	//List of ConcernMap's
	private HashMap regionMap = new HashMap();	//List of regionMap's

	/* Elements used in conjunction with the RTree */
	private List listOfRegions = new ArrayList();
	private List listOfRegionIds = new ArrayList();
	private List listOfConcerns = new ArrayList();

	/* Elements used in conjunction with the Lexer*/
	private List regionStartPosition = new ArrayList();
	private List regionEndPositions = new ArrayList();

	/* Variable for communication with other classes */
	Windows mainWindow;
	RTreeInterface regionTree;
	GlobalVariables globalVariable;

	/* Adds a value to the list specified by the calling object */
	public void add(String listName, Object value)
	{
		if (listName == "listOfRegions")
			listOfRegions.add(value);
		else if (listName == "listOfRegionIds")
			listOfRegionIds.add(value);
		else if (listName == "listOfConcerns")
			listOfConcerns.add(value);
		else if (listName == "regionStartPosition")
			regionStartPosition.add(value);
		else if (listName == "regionEndPositions")
			regionEndPositions.add(value);
		else
			System.out.println("INTERNAL ERROR: Cannot ADD to list. List:"
				+ listName + " not defined");
	}

	/* Clears the list specified by the calling object */
	public void clear(String mapName)
	{
		if (mapName == "listOfConcerns")
			listOfConcerns.clear();
		else if (mapName == "concernMap")
			concernMap.clear();
		else if (mapName == "regionMap")
			regionMap.clear();
		else
			System.out.println("INTERNAL ERROR: Cannot CLEAR list. List:" +
				mapName + " not defined");
	}

	/* Gets value of the object at the given index in the List specified by
	 * the calling object */
	public Object get(String listName, int index)
	{
		if (listName == "concernMap")
		{
			Object[] concernList = concernMap.keySet().toArray();
			return (String)concernList[index];	//here, index is the index number 
			//of the concern in the list
		}
		else if (listName == "regionMap")
			return regionMap.get(index);	//here, index is the regionID
		else
		{
			System.out.println("INTERNAL ERROR: Cannot GET from list. List:" +
				listName + " not defined");
			return null;
		}
	}

	/* Gives the size of the list specified by the calling object */
	public int size(String mapName)
	{
		if (mapName == "concernMap")
			return concernMap.size();
		else if (mapName == "regionMap")
			return regionMap.size();
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get SIZE from list. List:" +
				mapName + " not defined");
			return -1;
		}
	}

	/* Returns the list requested by the calling object */
	public HashMap getMap(String listName)
	{
		if (listName == "concernMap")
			return concernMap;
		else if (listName == "regionMap")
			return regionMap;
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get list. List:" +
				listName + " not defined");
			return null;
		}
	}

	/* Equates a list specified by the calling object to another list */
	public void setMap(String listName, HashMap aMap)
	{
		if (listName == "concernMap")
			concernMap = aMap;
		else if (listName == "regionMap")
			regionMap = aMap;
		else
		{
			System.out.println("INTERNAL ERROR: Cannot set list. List:" +
				listName + " not defined");
		}
	}

	public Color getConcernColor(String concern)
	{ return ((ConcernInfo)(concernMap.get(concern))).clr; }

	/* Returns the value of the MCB */
	public Color getMCB()
	{ return MCB; }

	/* Sets the value of the MCB */
	public void setMCB(Color mcb)
	{ MCB = mcb; }

	/* Returns the value of noOfConcerns */
	public int getNoOfConcerns()
	{ return noOfConcerns; }

	/* Sets the value of noOfConcerns */
	public void setNoOfConcerns(int noOfConcs)
	{ noOfConcerns = noOfConcs; }

	/* Returns the value of totalRegions */
	public int getNoOfRegions()
	{ return totalRegions; }

	/* Sets the value of uniqueId */
	public void setUniqueId()
	{
		List regionList = java.util.Arrays.asList(regionMap.keySet().toArray());
		if (regionList.size() == 0)
			uniqueId = -1;
		else
			uniqueId = (Integer)java.util.Collections.max(regionList);
		uniqueId++;
	}

	/* Sets the value of totalRegions */
	public void setNoOfRegions(int noRegions)
	{ totalRegions = noRegions; }

	/* Returns the value of  fileopen */
	public File getOpenFile()
	{ return fileopen; }

	/* Sets the value of  fileopen */
	public void setOpenFile(File file)
	{ fileopen = file; }

	/* Returns the value of the variable woven */
	public boolean getWoven()
	{ return woven; }

	/* Sets the value of the variable woven */
	public void setWoven(boolean state)
	{ woven = state; }

	public void setViewFlags(boolean state)
	{ viewFlags = state; }

	public boolean getViewFlags()
	{ return viewFlags; }

	/* Renames join points */
	void renameJoinPoints()
	{
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		if (totalRegions == 0)		// if there are no join points defined yet
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"No Code Regions defined yet.", "IVCON",
				JOptionPane.WARNING_MESSAGE);
			return;
		}
		previewText = new JTextPane();
		previewStyledDoc = previewText.getStyledDocument();
		if (previewStyledDoc instanceof AbstractDocument)
			previewAbstractDoc = (AbstractDocument)previewStyledDoc;
		else
		{
			System.err.println("Preview's document isn't an AbstractDocument!");
			System.exit(-1);
		}
		DefaultListModel listModel;
		listModel = new DefaultListModel();
		Object[] regionList = regionMap.keySet().toArray();
		for (int i = 0; i < regionMap.size(); i++)
			listModel.addElement(
				((RegionInfo)(regionMap.get((Integer)regionList[i]))).regionName);
		//Create the list of joinpoints and put it in a scroll pane.
		list = new JList(listModel);
		Font tempFont = new Font("tempFont", 0, 12);
		list.setFont(tempFont);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.addListSelectionListener(this);
		list.setVisibleRowCount(20);
		JScrollPane listScroll = new JScrollPane(list);
		JScrollPane previewScroll = new JScrollPane(previewText);
		listScroll.setBorder(BorderFactory.createTitledBorder(BORDER,
									"Code Regions", TitledBorder.LEFT, 1));
		previewScroll.setBorder(BorderFactory.createTitledBorder(BORDER,
										"Preview", TitledBorder.LEFT, 1));
		JSplitPane renameDialog = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
												listScroll, previewScroll);
		renameDialog.setDividerSize(5);
		renameDialog.setResizeWeight(.5);
		previewText.setEditable(false);
		Object[] selectionOptions ={ "Rename", "Cancel" };
		//preview pane shows the code at the join point selected by user
		previewText.setText("							");
		//Show the "rename join point" dialog
		int selectedOption = JOptionPane.showOptionDialog(mainWindow.frame,
			renameDialog, "Rename Code Regions", JOptionPane.YES_NO_OPTION,
			JOptionPane.PLAIN_MESSAGE, null, selectionOptions, selectionOptions[0]);
		if (selectedOption == 0)
		{
			int index = list.getSelectedIndex();
			if (index < 0)
				return;
			String initialJoinPointName =
				((RegionInfo)(regionMap.get((Integer)regionList[index]))).regionName;
			String newRegionName = new String("");
			while (newRegionName.equals(new String("")))
			{
				newRegionName = (String)JOptionPane.showInputDialog(
						mainWindow.frame, "Enter New Name for Code region:",
						"Rename Code Region", JOptionPane.QUESTION_MESSAGE,
						null, null, initialJoinPointName);
				if (newRegionName == null)
					return;
				newRegionName = newRegionName.trim();
				if (!checkJoinPointName(newRegionName, initialJoinPointName))
					newRegionName = "";
			}
			if (!initialJoinPointName.equals(newRegionName))	//Change region Name
				((RegionInfo)(regionMap.get(index))).regionName = newRegionName;
		}
	}

	/* Changes the value of the MCB according to the user's choice*/
	void changeMultiColor()
	{
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		Color newColor = JColorChooser.showDialog(mainWindow.frame,
			"Choose a New Color for the Background for Multiple Concerns", MCB);
		if (newColor != null)
		{
			if (!newColor.equals(MCB))
			{
				MCB = newColor;
				int regionMapSize = regionMap.size();
				int counter = 0;
				Object[] regionList = regionMap.keySet().toArray();
				while (counter < regionMapSize)
				{
					RegionInfo tempInfo =
						((RegionInfo)(regionMap.get((Integer)regionList[counter])));
					//Apply the setting of the new MCB to the window
					mainWindow.removeTextFilter();
					editMultiColor(tempInfo.begPos, tempInfo.endPos);
					mainWindow.setTextFilter();
					counter++;
				}
			}
		}
	}

	/* Applies the setting of the new MCB to the window */
	void editMultiColor(int startPosition, int endPosition)
	{
		String targetDoc, targetWindow;
		if (woven)	//When we are in woven view, the target window is wovenCode
		{
			targetWindow = "wovenCode";
			targetDoc = "wovenCodeAbstractDoc";
		}
		else        //When we are in woven view, the target window is unWovenBody
		{
			targetWindow = "unWovenBody";
			targetDoc = "unWovenBodyAbstractDoc";
		}
		//Collect points where "regions" begin and end. A Region is 
		//the area enclosed by points where any region begins or ends
		mainWindow.setInteger("currentNoOfRegions", 0);
		listOfRegions.clear();
		int startPos = startPosition;
		int endPos = endPosition + 1;
		regionTree.queryMethod(startPos, endPos, 2);
		listOfRegions.add(startPos);
		listOfRegions.add(endPos);
		int i;
		java.util.Collections.sort(listOfRegions);
		int startIndex = java.util.Collections.binarySearch(listOfRegions, startPos);
		int endIndex = java.util.Collections.binarySearch(listOfRegions, endPos);
		List tempList = new ArrayList();
		i = startIndex;
		while (i <= endIndex)
		{
			tempList.add(listOfRegions.get(i));
			i++;
		}
		tempList = removeDuplicates(tempList);
		i = 0;
		mainWindow.selectAll(targetWindow);
		//Apply formatting to the regions based on number of concerns in the region.
		//Note that for any region, the number of concerns in the region will be constant.
		while (i < tempList.size() - 1)
		{
			startPos = (Integer)(tempList.get(i));
			endPos = (Integer)(tempList.get(i + 1));
			mainWindow.setCaretPosition(targetWindow, startPos);
			if (mainWindow.getInteger("currentNoOfRegions") > 1)
			{
				StyleConstants.setBold(mainWindow.attrs[5], false);
				StyleConstants.setForeground(mainWindow.attrs[5], Color.WHITE);
				StyleConstants.setBackground(mainWindow.attrs[5], MCB);
				mainWindow.select(targetWindow, startPos, endPos);
				String tempText = mainWindow.getSelectedText(targetWindow);
				mainWindow.replaceSelection(targetWindow, "");
				mainWindow.insertText(targetDoc, tempText, startPos, 5);
			}
			i++;
		}
	}

	/* Removes a concern completely */
	void removeConcern()
	{
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		int initialPosition = mainWindow.getCaretPosition("wovenCode");
		Object[] possibilities = new Object[noOfConcerns];
		int i = 0;
		if (noOfConcerns != 0)
		{
			possibilities = concernMap.keySet().toArray();
			//Show dialog for user to select concern
			String selectedConcern = (String)JOptionPane.showInputDialog(
				mainWindow.frame, "Select the Concern to remove:\n\n",
				"Remove a Concern", JOptionPane.PLAIN_MESSAGE,
				null, possibilities, "");
			if (selectedConcern != null)
			{
				/*int selectedConcernNum = 0;
				while (selectedConcernNum < concernMap.size())
				{
					if (selectedConcern.equals(((ConcernMap)
						(concernMap.get(selectedConcernNum))).concernName.name))
						break;
					selectedConcernNum++;
				}*/
				ConcernInfo tempConcernInfo = (ConcernInfo)
					(concernMap.get(selectedConcern));
				i = 0;
				while (i < tempConcernInfo.arrayListOfRegions.size())
				{
					int tempRegionId =
						(Integer)(tempConcernInfo.arrayListOfRegions.get(i));
					((RegionInfo)regionMap.get(tempRegionId)).
						arrayListOfConcerns.remove(selectedConcern);
					int tempBegin =
						((RegionInfo)(regionMap.get(tempRegionId))).begPos;
					int tempEnd =
						((RegionInfo)(regionMap.get(tempRegionId))).endPos;
					mainWindow.select("wovenCode", tempBegin, tempEnd + 1);
					//refresh text formatting in window
					removeColors(mainWindow.getSelectionStart("wovenCode"),
						mainWindow.getSelectionEnd("wovenCode"));
					i++;
				}
				//remove concern from concernMap.
				concernMap.remove(selectedConcern);
				noOfConcerns--;
				refreshConcernLegend();
				/*mainWindow.selectAll("wovenCode");
				removeColors(mainWindow.getSelectionStart("wovenCode"),
					mainWindow.getSelectionEnd("wovenCode"));*/
			}
		}
		else
			JOptionPane.showMessageDialog(mainWindow.frame,
				"No Concerns defined yet.", "IVCON", JOptionPane.WARNING_MESSAGE);
		mainWindow.setCaretPosition("wovenCode", initialPosition);
		//Update popup menu so that deleted concern is removed from popup menu
		mainWindow.createPopupMenu();
	}

	/* Updates text formatting in a window after a concern has been removed */
	void removeColors(int startPosition, int endPosition)
	{
		int i;
		Color initialColor = Color.BLACK;
		mainWindow.setInteger("currentNoOfRegions", 0);
		listOfRegions.clear();
		if (noOfConcerns != 0)
		{
			//Collect points where "regions" begin and end.
			regionTree.queryMethod(startPosition, endPosition, 2);
			listOfRegions.add(startPosition);
			listOfRegions.add(endPosition);
			java.util.Collections.sort(listOfRegions);
			int startIndex =
				java.util.Collections.binarySearch(listOfRegions, startPosition);
			int endIndex =
				java.util.Collections.binarySearch(listOfRegions, endPosition);
			List tempList = new ArrayList();
			i = startIndex;
			while (i <= endIndex)
			{
				tempList.add(listOfRegions.get(i));
				i++;
			}
			tempList = removeDuplicates(tempList);
			i = 0;
			mainWindow.selectAll("wovenCode");
			//Apply formatting to regions based on number of concerns in region.
			while (i < tempList.size() - 1)
			{
				startPosition = (Integer)(tempList.get(i));
				endPosition = (Integer)(tempList.get(i + 1));
				mainWindow.setCaretPosition("wovenCode", startPosition);
				if (mainWindow.getInteger("currentNoOfRegions") == 0)
				{
					StyleConstants.setBold(mainWindow.attrs[4], false);
					StyleConstants.setForeground(mainWindow.attrs[4], Color.BLACK);
					mainWindow.select("wovenCode", startPosition, endPosition);
					String tempText = mainWindow.getSelectedText("wovenCode");
					mainWindow.replaceSelection("wovenCode", "");
					mainWindow.insertText("wovenCodeAbstractDoc",
						tempText, startPosition, 4);
				}
				else if (mainWindow.getInteger("currentNoOfRegions") == 1)
				{
					AttributeSet currentAttributes =
						mainWindow.getCharacterAttributes("wovenCode");
					Enumeration attributeNames =
						currentAttributes.getAttributeNames();
					Color foregroundColor = Color.BLACK;
					Color backgroundColor = Color.WHITE;
					while (attributeNames.hasMoreElements())
					{
						Object nextAttribute = attributeNames.nextElement();
						String attributeString = nextAttribute.toString();
						if (attributeString.equals("foreground"))
						{
							foregroundColor = (Color)
								(currentAttributes.getAttribute(nextAttribute));
							initialColor = foregroundColor;
						}
						if (attributeString.equals("background"))
						{
							backgroundColor = (Color)
								(currentAttributes.getAttribute(nextAttribute));
						}

					}
					if (foregroundColor.equals(Color.WHITE) &&
						backgroundColor.equals(MCB))
					{
						listOfRegionIds.clear();
						regionTree.queryMethod(startPosition, startPosition, 0);
						int regionId = (Integer)(listOfRegionIds.get(0));
						listOfRegionIds.clear();
						String tempConcernName =
							(String)(((RegionInfo)(regionMap.get(regionId))).
							arrayListOfConcerns.get(0));
						initialColor =
							((ConcernInfo)(concernMap.get(tempConcernName))).clr;
					}
					StyleConstants.setBold(mainWindow.attrs[4], false);
					StyleConstants.setForeground(mainWindow.attrs[4], initialColor);
					mainWindow.select("wovenCode", startPosition, endPosition);
					String tempText = mainWindow.getSelectedText("wovenCode");
					mainWindow.replaceSelection("wovenCode", "");
					mainWindow.insertText("wovenCodeAbstractDoc",
						tempText, startPosition, 4);
				}
				i++;
			}
		}
		else
		{
			StyleConstants.setBold(mainWindow.attrs[5], false);
			StyleConstants.setForeground(mainWindow.attrs[5], initialColor);
			StyleConstants.setBackground(mainWindow.attrs[5], java.awt.Color.WHITE);
			mainWindow.select("wovenCode", startPosition, endPosition);
			String tempText = mainWindow.getSelectedText("wovenCode");
			mainWindow.replaceSelection("wovenCode", "");
			mainWindow.insertText("wovenCodeAbstractDoc",
				tempText, startPosition, 5);
		}
	}
	/* Performs frontend operation to deassign a 
	 * concern on the current cursor position */
	void deAssignConcern()
	{
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		if (mainWindow.getSelectedText("wovenCode") != (null))
		{
			int startPosition = mainWindow.getSelectionStart("wovenCode");
			int endPosition = mainWindow.getSelectionEnd("wovenCode") - 1;
			listOfRegionIds.clear();
			regionTree.queryMethod(startPosition, endPosition, 0);
			List rangeQueryResults = new ArrayList(listOfRegionIds);
			listOfRegionIds.clear();
			regionTree.queryMethod(startPosition, startPosition, 0);
			List startQueryResults = new ArrayList(listOfRegionIds);
			listOfRegionIds.clear();
			regionTree.queryMethod(endPosition, endPosition, 0);
			List endQueryResults = new ArrayList(listOfRegionIds);
			/*			System.out.print("\nRANGE:");
						for (int i = 0; i < rangeQueryResults.size(); i++)
							System.out.print(rangeQueryResults.get(i) + ",");
						System.out.print("\nSTART:");
						for (int i = 0; i < startQueryResults.size(); i++)
							System.out.print(startQueryResults.get(i) + ",");
						System.out.print("\nEND:");
						for (int i = 0; i < endQueryResults.size(); i++)
							System.out.print(endQueryResults.get(i) + ",");*/
			List sizeArray = new ArrayList();
			sizeArray.add(rangeQueryResults.size());
			sizeArray.add(startQueryResults.size());
			sizeArray.add(endQueryResults.size());
			List commonIndices = new ArrayList();
			int minSize = (Integer)java.util.Collections.min(sizeArray);
			int minIndex = sizeArray.indexOf(minSize);
			List[] queryResultsArray = new List[3];
			queryResultsArray[0] = rangeQueryResults;
			queryResultsArray[1] = startQueryResults;
			queryResultsArray[2] = endQueryResults;
			for (int i = 0; i < queryResultsArray[minIndex].size(); i++)
			{
				Object queryObj = queryResultsArray[minIndex].get(i);
				if (queryResultsArray[0].contains(queryObj) &&
					queryResultsArray[1].contains(queryObj) &&
					queryResultsArray[2].contains(queryObj))
					commonIndices.add(queryObj);
			}
			/*		for (int i = 0; i < commonIndices.size(); i++)
						System.out.println(commonIndices.get(i));*/
			if (commonIndices.isEmpty())
			{
				JOptionPane.showMessageDialog(mainWindow.frame,
					"All text in Highlighted region must be assigned to at least "
					+ "one common concern.", "IVCON", JOptionPane.WARNING_MESSAGE);
				return;
			}
			List availableConcerns = new ArrayList();
			for (int i = 0; i < commonIndices.size(); i++)
			{
				int tempIndex = (Integer)commonIndices.get(i);
				List tempConcernList =
					((RegionInfo)(regionMap.get(tempIndex))).arrayListOfConcerns;
				for (int j = 0; j < tempConcernList.size(); j++)
					availableConcerns.add(((String)tempConcernList.get(j)));
			}
			Object[] possibilities = new Object[availableConcerns.size()];
			for (int i = 0; i < availableConcerns.size(); i++)
				possibilities[i] = (String)(availableConcerns.get(i));
			String selectedConcern =
				(String)JOptionPane.showInputDialog(mainWindow.frame,
				"Select the Concern to Deassign:\n\n", "Deassign a Concern",
				JOptionPane.PLAIN_MESSAGE, null, possibilities, "");
			if (selectedConcern == null)
				return;
			int regionIndex = 0;
			int concernIndex = 0;
			boolean exit = false;
			for (regionIndex = 0; regionIndex < commonIndices.size(); regionIndex++)
			{
				int tempIndex = (Integer)commonIndices.get(regionIndex);
				List tempConcernList =
					((RegionInfo)(regionMap.get(tempIndex))).arrayListOfConcerns;
				for (concernIndex = 0;
					concernIndex < tempConcernList.size();
					concernIndex++)
				{
					if (((String)tempConcernList.get(concernIndex)).
						equals(selectedConcern))
					{
						exit = true;
						break;
					}
				}
				if (exit)
					break;
			}
			int regionNumber = (Integer)commonIndices.get(regionIndex);
			RegionInfo checkRegion = (RegionInfo)(regionMap.get(regionNumber));
			int concernNumber = 0;

			int removalCase = 0;
			String newRegionName1 = "";
			String newRegionName2 = "";

			if (checkRegion.begPos == mainWindow.getSelectionStart("wovenCode") &&
				checkRegion.endPos == mainWindow.getSelectionEnd("wovenCode") - 1)
			{ /* do nothing */ }
			else
			{
				if (checkRegion.begPos == mainWindow.getSelectionStart("wovenCode") ||
					checkRegion.endPos == mainWindow.getSelectionEnd("wovenCode") - 1)
				{
					removalCase = 1;
					if ((((RegionInfo)
						(regionMap.get(regionNumber))).arrayListOfConcerns).size() > 1)
					{
						while (newRegionName1.equals(new String("")))
						{
							int newRegionNumber =
								((ConcernInfo)(concernMap.get(selectedConcern))).
								arrayListOfRegions.size();
							newRegionName1 = (String)JOptionPane.showInputDialog(
						mainWindow.frame, "Please Enter Name for the new Code region:",
						"Rename Code region", JOptionPane.QUESTION_MESSAGE,
						null, null, "region_" + selectedConcern + "_" + newRegionNumber);
							if (newRegionName1 == null)
								return;
							newRegionName1 = newRegionName1.trim();
							if (!checkJoinPointName(newRegionName1, ""))
								newRegionName1 = "";
						}
					}
					else
						newRegionName1 =
							((RegionInfo)(regionMap.get(regionNumber))).regionName;
				}
				else
				{
					while (newRegionName1.equals(new String("")))
					{
						int newRegionNumber =
							((ConcernInfo)(concernMap.get(selectedConcern))).
							arrayListOfRegions.size();
						newRegionName1 = (String)JOptionPane.showInputDialog(
					mainWindow.frame,
					"By deassigning the concern from currently highlighted text\n" +
					"you are effectively defining two different code regions.\n\n" +
					"Please Enter Name for the first code regions:",
					"Rename Code Region", JOptionPane.QUESTION_MESSAGE,
					null, null, "region_" + selectedConcern + "_" + newRegionNumber);

						if (newRegionName1 == null)
							return;
						newRegionName1 = newRegionName1.trim();
						if (!checkJoinPointName(newRegionName1, ""))
							newRegionName1 = "";
					}
					while (newRegionName2.equals(new String("")))
					{
						int newRegionNumber =
							(((ConcernInfo)(concernMap.get(selectedConcern))).arrayListOfRegions.size()) + 1;
						newRegionName2 = (String)JOptionPane.showInputDialog(
					mainWindow.frame, "Please Enter Name for the second code region:",
					"Rename Code Region", JOptionPane.QUESTION_MESSAGE,
					null, null, "region_" + selectedConcern + "_" + newRegionNumber);
						if (newRegionName2 == null)
							return;
						newRegionName2 = newRegionName2.trim();
						if (!checkJoinPointName(newRegionName2, ""))
							newRegionName2 = "";
						if (newRegionName2.equals(newRegionName1))
						{
							JOptionPane.showMessageDialog(mainWindow.frame,
											"Code region Name\"" + newRegionName2 +
											"\" exists already.", "IVCON",
											JOptionPane.WARNING_MESSAGE);
							newRegionName2 = "";
						}
					}
					removalCase = 2;
				}
			}
			//Remove the region->concern mapping
			List tempConcernList =
				((RegionInfo)(regionMap.get(regionNumber))).arrayListOfConcerns;
			tempConcernList.remove(selectedConcern);
			//if no more concerns are assigned to a region and the the current 
			//concern is being completely deassigned then logically delete the region
			if (tempConcernList.isEmpty())
				((RegionInfo)(regionMap.get(regionNumber))).regionName = "{remove}";
			RegionInfo removeRegionInfo = (RegionInfo)(regionMap.get(regionNumber));
			//Remove the concern -> region mapping
			((ConcernInfo)(concernMap.get(selectedConcern))).
				arrayListOfRegions.remove((Object)regionNumber);
			if (removalCase == 1)
			{
				RegionInfo addRegionInfo;
				List addConcern = new ArrayList();
				addConcern.add(selectedConcern);
				if (removeRegionInfo.begPos == mainWindow.getSelectionStart("wovenCode"))
					addRegionInfo = new RegionInfo(newRegionName1, addConcern,
						mainWindow.getSelectionEnd("wovenCode"),
					removeRegionInfo.endPos);
				else
					addRegionInfo =
						new RegionInfo(newRegionName1, addConcern, removeRegionInfo.begPos,
						mainWindow.getSelectionStart("wovenCode") - 1);
				((ConcernInfo)concernMap.get(selectedConcern)).arrayListOfRegions.add(uniqueId);
				regionMap.put(uniqueId, addRegionInfo);
				totalRegions++;
				uniqueId++;
			}
			if (removalCase == 2)
			{
				RegionInfo addRegionInfo;
				List addConcern = new ArrayList();
				addConcern.add("selectedConcern");
				addRegionInfo =
					new RegionInfo(newRegionName1, addConcern, removeRegionInfo.begPos,
					mainWindow.getSelectionStart("wovenCode") - 1);
				((ConcernInfo)concernMap.get(selectedConcern)).
					arrayListOfRegions.add(uniqueId);
				regionMap.put(uniqueId, addRegionInfo);
				totalRegions++;
				uniqueId++;

				addRegionInfo = new
					RegionInfo(newRegionName2, addConcern, mainWindow.getSelectionEnd(
					"wovenCode"), removeRegionInfo.endPos);
				((ConcernInfo)concernMap.get(selectedConcern)).
					arrayListOfRegions.add(uniqueId);
				regionMap.put(uniqueId, addRegionInfo);
				totalRegions++;
				uniqueId++;
			}
			cleanUpMapsAndTree();
			removeColors(mainWindow.getSelectionStart("wovenCode"),
				mainWindow.getSelectionEnd("wovenCode"));
		}
		else
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"Select Code Text to Deassign Concern from."
				, "IVCON", JOptionPane.WARNING_MESSAGE);
			return;
		}
	}

	/* Allows a user to edit a concern's name or color */
	void editConcern()
	{
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		String targetWindow = "wovenCode";
		Object[] possibilities = new Object[noOfConcerns];
		int i = 0;
		if (noOfConcerns != 0)
		{
			possibilities = concernMap.keySet().toArray();
			//Display a list of existing concerns
			String selectedConcern =
				(String)JOptionPane.showInputDialog(mainWindow.frame,
				"Select the concern to edit:\n\n", "Edit a Concern",
				JOptionPane.PLAIN_MESSAGE, null, possibilities, "");
			if (selectedConcern != null)
			{
				//Get initial names and color for selected concern
				Color tempColor = ((ConcernInfo)(concernMap.get(selectedConcern))).clr;
				int initialPos = mainWindow.getCaretPosition(targetWindow);
				String newConcernName = new String("");
				//Prompt for new name for concern
				while (newConcernName.equals(new String("")))
				{
					newConcernName =
						(String)JOptionPane.showInputDialog(mainWindow.frame,
						"Enter a New Name for concern:", "Edit Concern",
						JOptionPane.PLAIN_MESSAGE, null, null, selectedConcern); ;
					if (newConcernName == null)
						break;
					newConcernName = newConcernName.trim();
					if (!checkConcernName(newConcernName, selectedConcern))
						newConcernName = "";
				}
				//Prompt for new color for concern if
				//user did not cancel earlier prompt
				if (newConcernName != null)
				{
					newConcernName = newConcernName.trim();
					boolean colorOK = false;
					Color newColor = tempColor;
					while (!colorOK)
					{
						newColor =
							JColorChooser.showDialog(mainWindow.frame,
							"Choose New Color for Concern " + selectedConcern, tempColor);
						colorOK = checkConcernColor(newColor, tempColor);
					}
					if (newColor != null)
					{
						//Update name if it's different from the original name
						if (!newConcernName.equals(selectedConcern))
						{
							ConcernInfo tempConcernInfo =
								(ConcernInfo)(concernMap.get(selectedConcern));
							concernMap.remove(selectedConcern);
							concernMap.put(newConcernName, tempConcernInfo);
							List regionsForConcern = tempConcernInfo.arrayListOfRegions;
							for (int j = 0; j < regionsForConcern.size(); j++)
							{
								int index = (Integer)regionsForConcern.get(j);
								((RegionInfo)(regionMap.get(index))).
									arrayListOfConcerns.remove(selectedConcern);
								((RegionInfo)(regionMap.get(index))).
									arrayListOfConcerns.add(newConcernName);
							}
							mainWindow.selectAll(targetWindow);
							mainWindow.setCaretPosition(targetWindow, initialPos);
						}
						//Update color if its different from the original color
						if (!newColor.equals(tempColor))
						{
							int regionListSize =
								((ConcernInfo)(concernMap.get(newConcernName))).
								arrayListOfRegions.size();
							int counter = 0;
							while (counter < regionListSize)
							{
								int tempID =
									(Integer)(((ConcernInfo)(concernMap.get(newConcernName))).
									arrayListOfRegions.get(counter));
								RegionInfo tempRegionInfo =
									(RegionInfo)(regionMap.get(tempID));
								//refresh text formatting
								editColor(tempRegionInfo.begPos, tempRegionInfo.endPos,
									newColor);
								((ConcernInfo)(concernMap.get(newConcernName))).clr =
									newColor;
								counter++;
							}
						}
						//Update concern legend if either the new name 
						// or new color is different from the original.
						if (!newConcernName.equals(selectedConcern) ||
							!newColor.equals(tempColor))
							refreshConcernLegend();
						mainWindow.setCaretPosition(targetWindow, initialPos);
					}
				}
			}
		}
		else //display an error if no concerns have been defined yet
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"No Concerns defined yet.", "IVCON", JOptionPane.WARNING_MESSAGE);
			return;
		}
	}

	/* Adds a concern to the list of concerns 
	 * without assigning it to any specific text */
	void addConcern()
	{
		int initialPosition = mainWindow.getCaretPosition("wovenCode");
		String newConcern = new String("");
		while (newConcern.equals(new String("")))
		{	//Prompt for a concern name
			newConcern = (String)JOptionPane.showInputDialog(mainWindow.frame,
									"Enter Name of New Concern:", "Add New Concern",
									JOptionPane.QUESTION_MESSAGE, null, null, null);
			if (newConcern == null)
				return;
			newConcern = newConcern.trim();
			if (!checkConcernName(newConcern, ""))
				newConcern = "";
		}
		if (newConcern != null)
		{
			// Generate a Random Color for the new Concern
			Random randomGenerator = new Random();
			int int1 = randomGenerator.nextInt(255);
			int int2 = randomGenerator.nextInt(255);
			int int3 = randomGenerator.nextInt(255);
			Color tempColor = new Color(int1, int2, int3);
			Color newColor = tempColor;
			boolean colorOK = false;
			while (!colorOK)
			{
				newColor = JColorChooser.showDialog(mainWindow.frame,
					"Choose New Color for Concern " + newConcern, tempColor);
				colorOK = checkConcernColor(newColor, tempColor);
			}
			if (newColor == null)
				return;
			if (newColor != null)
			{	//Add concern to the list of ConcernMaps
				List tempList = new ArrayList();
				concernMap.put(newConcern, new ConcernInfo(newColor, tempList));
			}
			noOfConcerns++;
			refreshConcernLegend();
			mainWindow.setCaretPosition("wovenCode", initialPosition);
		}
		//Update pop up menu so that the new concern shows up in the pop up menu
		mainWindow.createPopupMenu();
	}

	/* Refreshes the Concern Legend */
	void refreshConcernLegend()
	{	//Clear the list and add all the concerns
		int loopVar = 0;
		mainWindow.setEditable("concernLegend", true);
		mainWindow.selectAll("concernLegend");
		mainWindow.replaceSelection("concernLegend", "");
		Object[] concernList = concernMap.keySet().toArray();
		while (loopVar < concernList.length)
		{
			Color tempColor =
				((ConcernInfo)(concernMap.get(concernList[loopVar]))).clr;
			StyleConstants.setForeground(mainWindow.attrs[1], tempColor);
			mainWindow.insertText("concernLegendAbstractDoc",
				concernList[loopVar] +
				globalVariable.NEWLINE, -1, 1);
			loopVar++;
		}
		mainWindow.setEditable("concernLegend", false);
	}

	/* Takes as input a concern name and assigns the selected text in woven code to that concern */
	void findConcernAndAdd(String selectedConcern)
	{
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		if (mainWindow.getSelectedText("wovenCode") == null)
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"Select Code Text to Assign to a Concern.", "IVCON",
				JOptionPane.WARNING_MESSAGE);
			return;
		}
		int selectionStart = mainWindow.getSelectionStart("wovenCode");
		int selectionEnd = mainWindow.getSelectionEnd("wovenCode");

		// Checking whether currently selected text is already 
		// assigned to the concern which user selects
		List tempRegionList =
			((ConcernInfo)(concernMap.get(selectedConcern))).arrayListOfRegions;
		int regionNo = 0;
		while (regionNo < tempRegionList.size())
		{
			int tempID = (Integer)tempRegionList.get(regionNo);
			RegionInfo tempRegion = (RegionInfo)(regionMap.get(tempID));
			if (tempRegion.begPos <= selectionStart &&
				tempRegion.endPos >= (selectionEnd - 1))
			{
				int i = 0;
				if (tempRegion.arrayListOfConcerns.contains(selectedConcern))
				{
					JOptionPane.showMessageDialog(mainWindow.frame,
							"This Code has already been assigned to Concern \""
							+ selectedConcern + "\"",
							"IVCON", JOptionPane.WARNING_MESSAGE);
					return;
				}
			}
			regionNo++;
		}
		// Minimizing number of regions
		// DEF: Relevant regions are those which overlap with the selected text.
		listOfRegionIds.clear();
		regionTree.queryMethod(selectionStart, selectionEnd, 0);
		int i = 0, j = 0, noOfRelevantRegion = 0;	//no of relevant regions
		List relevantRegionCoords = new ArrayList();	//relevant region coordinates
		List relevantRegionIds = new ArrayList();		//relevant region ids
		relevantRegionCoords.add(selectionStart);
		relevantRegionCoords.add(selectionEnd - 1);
		while (i < listOfRegionIds.size())
		{
			j = 0;
			List locRegions =
				((ConcernInfo)(concernMap.get(selectedConcern))).arrayListOfRegions;
			while (j < locRegions.size())
			{
				int tempId = (Integer)(listOfRegionIds.get(i));
				int compareId = (Integer)locRegions.get(j);
				if (tempId == compareId)
				{
					relevantRegionIds.add(tempId);
					noOfRelevantRegion++;
					break;
				}
				j++;
			}
			i++;
		}
		i = 0;
		while (i < relevantRegionIds.size())
		{
			j = (Integer)(relevantRegionIds.get(i));
			if (((RegionInfo)regionMap.get(j)).arrayListOfConcerns.size() > 1)
			{
				(((RegionInfo)regionMap.get(j)).arrayListOfConcerns).
					remove(selectedConcern);
				relevantRegionIds.set(i, -1);
			}
			i++;
		}
		Integer minusOne = new Integer(-1);
		if (noOfRelevantRegion != 0)
		{
			while (relevantRegionIds.remove(minusOne))
				noOfRelevantRegion--;
			i = 0;
			while (i < relevantRegionIds.size())
			{
				j = (Integer)(relevantRegionIds.get(i));
				relevantRegionCoords.add(((RegionInfo)regionMap.get(j)).begPos);
				relevantRegionCoords.add(((RegionInfo)regionMap.get(j)).endPos);
				i++;
			}
			i = 0;
			java.util.Collections.sort(relevantRegionCoords);
			i = relevantRegionCoords.size();
			String newRegionName = new String("");
			//Prompt for a name for the join point
			while (newRegionName.equals(new String("")))
			{
				int newRegionNumber =
					((ConcernInfo)(concernMap.get(selectedConcern))).
					arrayListOfRegions.size();
				newRegionName =
					(String)JOptionPane.showInputDialog(mainWindow.frame,
					"Enter a Name for this code region:", "Name Code Region",
					JOptionPane.QUESTION_MESSAGE, null, null, "region_"
					+ selectedConcern + "_" + newRegionNumber);
				if (newRegionName == null)
					return;
				newRegionName = newRegionName.trim();
				if (!checkJoinPointName(newRegionName, ""))
					newRegionName = "";
			}
			//Create a new entry in regionMap
			List tempConcern = new ArrayList();
			tempConcern.add(selectedConcern);
			RegionInfo tempRegion =
				new RegionInfo(newRegionName, tempConcern,
				(Integer)(relevantRegionCoords.get(0)),
				(Integer)(relevantRegionCoords.get(i - 1)));
			regionMap.put(uniqueId, tempRegion);
			((ConcernInfo)(concernMap.get(selectedConcern))).
				arrayListOfRegions.add((Object)uniqueId);
			// Logical deletion of duplicate regions
			i = 0;
			while (i < relevantRegionIds.size())
			{
				j = (Integer)(relevantRegionIds.get(i));
				((RegionInfo)regionMap.get(j)).arrayListOfConcerns.clear();
				i++;
			}
			changeColor(tempRegion.begPos, tempRegion.endPos,
				((ConcernInfo)concernMap.get(selectedConcern)).clr);
			regionTree.addRegionToTree
				(tempRegion.begPos, tempRegion.endPos, uniqueId);
			totalRegions++;
			uniqueId++;
		}
		else // if no Relevant Regions
		{
			regionNo = 0;
			// Checking whether currently selected region already exists or not
			boolean regionExists = false;
			Object[] regionList = regionMap.keySet().toArray();
			while (regionNo < regionMap.size())
			{
				int id = (Integer)regionList[regionNo];
				if (((RegionInfo)(regionMap.get(id))).begPos == selectionStart &&
					((RegionInfo)(regionMap.get(id))).endPos == selectionEnd - 1)
				{
					regionExists = true;
					break;
				}
				regionNo++;
			}
			Color newColor = ((ConcernInfo)(concernMap.get(selectedConcern))).clr;
			if (regionExists)	//if region exists Add concern to its list of concerns
			{
				changeColor(selectionStart, (selectionEnd - 1), newColor);
				((RegionInfo)regionMap.get(regionList[regionNo])).
					arrayListOfConcerns.add(selectedConcern);
				((ConcernInfo)concernMap.get(selectedConcern)).
					arrayListOfRegions.add((Object)regionList[regionNo]);
			}
			else if (!regionExists)	//if region doesnt exist make a new entry
			{
				String newRegionName = new String("");
				while (newRegionName.equals(new String("")))
				{
					int newRegionNumber =
((ConcernInfo)(concernMap.get(selectedConcern))).arrayListOfRegions.size();
					newRegionName =
						(String)JOptionPane.showInputDialog(mainWindow.frame,
						"Enter a Name for this code region:", "Name Code Region",
						JOptionPane.QUESTION_MESSAGE, null, null,
						"region_" + selectedConcern + "_" + newRegionNumber);
					if (newRegionName == null)
						return;
					newRegionName = newRegionName.trim();
					if (!checkJoinPointName(newRegionName, ""))
						newRegionName = "";
				}
				//Refresh text formatting
				changeColor(selectionStart, (selectionEnd - 1), newColor);
				//Update regionMap and ConcernMap
				List tempConcern = new ArrayList();
				tempConcern.add(selectedConcern);
				regionMap.put(uniqueId, new RegionInfo
					(newRegionName, tempConcern, selectionStart, (selectionEnd - 1)));
				((ConcernInfo)concernMap.get(selectedConcern)).
					arrayListOfRegions.add((Object)uniqueId);
				regionTree.addRegionToTree
					(selectionStart, (selectionEnd - 1), uniqueId);
				totalRegions++;
				uniqueId++;
			}
		}
		mainWindow.setCaretPosition("wovenCode", selectionStart);
	}

	/* Translation from unwoven to woven view */
	void viewWoven()
	{	//Set up display to woven view
		mainWindow.setText("statusBar", "Weaving Code...");
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		cleanUpMapsAndTree();
		if (getViewFlags())
		{
			mainWindow.setViewFlagState(false);
			viewFlags();
		}
		woven = true;
		mainWindow.removeCaretListener("wovenCode");
		mainWindow.removeCaretListener("unWovenBody");
		mainWindow.removeCaretListener("unWovenConcerns");
		mainWindow.removeKeyListener("unWovenConcerns");
		//copy text from unwoven body to woven code.
		String unwovenBodyText = mainWindow.getText("unWovenBody", 0,
			mainWindow.getLength("unWovenBodyAbstractDoc"));
		mainWindow.selectAll("wovenCode");
		mainWindow.replaceSelection("wovenCode", "");
		StyleConstants.setForeground(mainWindow.attrs[5], Color.BLACK);
		StyleConstants.setBackground(mainWindow.attrs[5], Color.WHITE);
		mainWindow.insertText("wovenCodeAbstractDoc", unwovenBodyText, 0, 0);
		// Hole to Text translation
		List joinPoints = new ArrayList();
		String allText = mainWindow.getText("wovenCode", 0,
			mainWindow.getLength("wovenCodeAbstractDoc"));
		String unWovenText = mainWindow.getText("unWovenBody", 0,
			mainWindow.getLength("unWovenBodyAbstractDoc"));
		int delCounter = 0;
		int lenReplaced = 0;
		int[] newLength = new int[regionMap.size()];
		int[] newBegPosition = new int[regionMap.size()];
		Object[] allRegionsArray = regionMap.keySet().toArray();
		List allRegions = java.util.Arrays.asList(allRegionsArray);
		boolean[] done = new boolean[regionMap.size()];
		java.util.Arrays.fill(done, false);
		java.util.Arrays.fill(newLength, -1);
		// Take one hole at a time and get hole text from unwoven concerns
		while (allText.contains(globalVariable.HOLE))
		{
			int hIndex = allText.indexOf(globalVariable.HOLE);
			int holePosition = hIndex - lenReplaced;
			mainWindow.setInteger("currentNoOfRegions", 0);
			listOfRegionIds.clear();
			regionTree.queryMethod(holePosition, holePosition, 0);
			String holeText = "";
			holeJoinPoints.clear();
			joinPoints.clear();
			//Clear ambiguity arising due to different text 
			//for the same hole in different subconcerns
			for (int hsc = 0; hsc < listOfRegionIds.size(); hsc++)
			{
				int tempId = (Integer)(listOfRegionIds.get(hsc));
				RegionInfo tempRegion = (RegionInfo)regionMap.get(tempId);
				int tempIndex = allRegions.indexOf(tempId);
				if (!done[tempIndex])
				{
					done[tempIndex] = true;
					newBegPosition[tempIndex] = hIndex;
				}
				int inLoop = 0;
				String concernText = getConcernText(tempRegion.regionName,
					(String)(tempRegion.arrayListOfConcerns.get(inLoop)));
				while (concernText.contains(globalVariable.CLOSEHOLE + " "))
				{
					int holeSpaceIndex = concernText.indexOf(
						globalVariable.CLOSEHOLE + " ");
					concernText = concernText.substring(0, holeSpaceIndex + 1) +
						concernText.substring(holeSpaceIndex + 2,
						concernText.length());
				}
				int holeNumber = hIndex - lenReplaced - tempRegion.begPos;
				holeText = getHoleText(concernText, (holeNumber + 1));
			}
			String tempHoleText = new String(holeText);
			if (holeText.equals(""))
			{
				woven = false;
				mainWindow.setText("statusBar",
					"IVCon - Inline Visualization of Concerns");
				JOptionPane.showMessageDialog(mainWindow.frame,
					"ERROR: Subconcerns cannot be blank.",
					"Error", JOptionPane.ERROR_MESSAGE);
				mainWindow.addCaretListener("unWovenBody");
				mainWindow.addCaretListener("unWovenConcerns");
				return;
			}
			//Apply appropriate text formatting
			int holeCounter;
			int offset = -1;
			int unwovenIndex = 0;
			for (holeCounter = 0; holeCounter <= delCounter; holeCounter++)
			{
				unwovenIndex = unWovenText.indexOf(globalVariable.HOLE, offset + 1);
				offset = unwovenIndex;
			}
			mainWindow.setCaretPosition("unWovenBody", unwovenIndex);
			AttributeSet currentAttributes =
				mainWindow.getCharacterAttributes("unWovenBody");
			Enumeration attributeNames = currentAttributes.getAttributeNames();
			Color foregroundColor = Color.BLACK;
			Color backgroundColor = Color.WHITE;
			while (attributeNames.hasMoreElements())
			{
				Object nextAttribute = attributeNames.nextElement();
				String attributeString = nextAttribute.toString();
				if (attributeString.equals("foreground"))
					foregroundColor =
						(Color)(currentAttributes.getAttribute(nextAttribute));
				if (attributeString.equals("background"))
					backgroundColor =
						(Color)(currentAttributes.getAttribute(nextAttribute));
			}
			for (int hsc = 0; hsc < listOfRegionIds.size(); hsc++)
			{
				int tempindex = (Integer)(listOfRegionIds.get(hsc));
				newLength[allRegions.indexOf(tempindex)] += holeText.length();
			}
			mainWindow.select("wovenCode", hIndex, hIndex + 1);
			mainWindow.replaceSelection("wovenCode", "");
			StyleConstants.setForeground(mainWindow.attrs[5], foregroundColor);
			StyleConstants.setBackground(mainWindow.attrs[5], backgroundColor);
			mainWindow.insertText("wovenCodeAbstractDoc", holeText, hIndex, 5);
			delCounter++;
			lenReplaced += holeText.length() - 1;
			allText = mainWindow.getText("wovenCode", 0,
				mainWindow.getLength("wovenCodeAbstractDoc"));
		}

		// Updating RTree and regionMap
		int tempBegPos, tempEndPos, tempId, i;
		double[] lowerLimit = new double[2];
		double[] upperLimit = new double[2];
		// Store beginning and end positions of unwoven view regions in case
		// tokenizing is not correct.
		int[] beginningPositions = new int[regionMap.size()];
		int[] endPositions = new int[regionMap.size()];
		//Update regionMap
		i = 0;
		while (i < regionMap.size())
		{
			if (newLength[i] != -1)
			{
				beginningPositions[i] =
					((RegionInfo)regionMap.get((Integer)allRegions.get(i))).begPos;
				((RegionInfo)regionMap.get((Integer)allRegions.get(i))).begPos =
					newBegPosition[i];
				endPositions[i] =
					((RegionInfo)regionMap.get((Integer)allRegions.get(i))).endPos;
				((RegionInfo)regionMap.get((Integer)allRegions.get(i))).endPos =
					newBegPosition[i] + newLength[i];
			}
			i++;
		}

		//Verify Tokens
		boolean error = false;
		String expression = mainWindow.getText("wovenCode",
			0, mainWindow.getLength("wovenCodeAbstractDoc"));
		regionStartPosition.clear();
		regionEndPositions.clear();
		TokenVerifier tokenVerifier = new TokenVerifier();
		tokenVerifier.concMan = this;
		tokenVerifier.mainWindow = mainWindow;
		//Lex the whole text in the woven code
		tokenVerifier.lexAndAddPositions(expression, false);
		if (!tokenVerifier.getTokensOK())	//return if code does not lex correctly
		{
			woven = false;
			mainWindow.setText("statusBar",
				"IVCon - Inline Visualization of Concerns");
			error = true;
		}
		//Check if all concerns begin and end at beginning and end of tokens.
		//If they don't then show an error message.
		if (!error)
		{
			for (i = 0; i < regionMap.size(); i++)
			{
				RegionInfo tempRegion =
					((RegionInfo)regionMap.get((Integer)allRegions.get(i)));
				if (tempRegion.arrayListOfConcerns.isEmpty())
					continue;
				int bPos = tempRegion.begPos;
				int ePos = tempRegion.endPos;
				int startIndex = java.util.Collections.binarySearch(
					regionStartPosition, bPos);
				if (startIndex < 0)
				{	//Show error msg
					JOptionPane.showMessageDialog(mainWindow.frame,
						"<html><B>Concerns must begin and end at boundaries of " +
						"tokens.<BR><BR>", "Error", JOptionPane.ERROR_MESSAGE);
					woven = false;
					mainWindow.setText("statusBar",
						"IVCon - Inline Visualization of Concerns");
					error = true;
					break;
				}
				startIndex = java.util.Collections.binarySearch(
					regionEndPositions, ePos);
				if (startIndex < 0)
				{	//Show error msg
					JOptionPane.showMessageDialog(mainWindow.frame,
		"<html><B>Concerns must begin and end at boundaries of tokens.<BR><BR>",
		"Error",
		JOptionPane.ERROR_MESSAGE);
					woven = false;
					mainWindow.setText("statusBar",
						"IVCon - Inline Visualization of Concerns");
					error = true;
					break;
				}
			}
		}
		if (error)
		{
			i = 0;
			while (i < regionMap.size())
			{
				if (newLength[i] != -1)
				{
					((RegionInfo)regionMap.get((Integer)allRegions.get(i))).begPos =
						beginningPositions[i];
					((RegionInfo)regionMap.get((Integer)allRegions.get(i))).endPos =
						endPositions[i];
				}
				i++;
			}
			mainWindow.addCaretListener("unWovenBody");
			mainWindow.addCaretListener("unWovenConcerns");
			return;
		}
		//Clear RTree
		regionTree.initRTree();
		mainWindow.updateRTree(regionTree.getRTree());
		//Update RTree
		for (i = 0; i < regionMap.size(); i++)
		{
			RegionInfo tempRegion =
				((RegionInfo)(regionMap.get((Integer)allRegions.get(i))));
			if (!tempRegion.arrayListOfConcerns.isEmpty())
			{
				tempBegPos = tempRegion.begPos;
				tempEndPos = tempRegion.endPos;
				tempId = (Integer)allRegions.get(i);
				regionTree.addRegionToTree(tempBegPos, tempEndPos, tempId);
			}
		}
		// Display settings
		mainWindow.setEnabled("jumpToConcern", false);
		mainWindow.setEnabled("compile", true);
		mainWindow.setEnabled("export", true);
		mainWindow.setEnabled("renameJoinPointMenuItem", true);
		mainWindow.setVisible("splitUnwoven", false);
		mainWindow.setDividerLocation("splitPreview", 1);
		mainWindow.setVisible("scrPan", true);
		mainWindow.setEnabled("unWovenFormMenuItem", true);
		mainWindow.setEnabled("wovenFormMenuItem", false);
		mainWindow.setEnabled("assignToConcernMenuItem", true);
		mainWindow.setEnabled("save", true);
		mainWindow.setEnabled("saveAs", true);
		mainWindow.setEnabled("submenuRemove", true);
		mainWindow.setEnabled("addAConcernMenuItem", true);
		mainWindow.setEnabled("editConcern", true);
		mainWindow.addCaretListener("wovenCode");
		mainWindow.addKeyListener("wovenCode");
		mainWindow.createPopupMenu();
		mainWindow.setText("statusBar",
			"IVCon - Inline Visualization of Concerns");
		mainWindow.setTabSize();
	}

	/* Takes as input text from a subconcern and a hole number 
	 * and returns the text for the hole number specified */
	String getHoleText(String concText, int holeNo)
	{
		while (holeNo > 1)
		{
			int regionPosition = nextRegionPosition(concText);
			if (regionPosition == 0)
			{
				int tempInt = concText.indexOf(" ");
				concText = concText.substring(tempInt + 1);
			}
			else if (regionPosition > 0)
			{
				concText = concText.substring(regionPosition);
				int tempInt = concText.indexOf(" ");
				concText = concText.substring(tempInt + 1);
				holeNo--;
			}
			else
				return concText;
		}
		String holeText = "";
		while (holeNo > 0)
		{
			int regionPosition = nextRegionPosition(concText);
			if (regionPosition == 0)
			{
				int tempInt = concText.indexOf(" ");
				concText = concText.substring(tempInt + 1);
			}
			else if (regionPosition > 0)
			{
				holeText = concText.substring(0, regionPosition);
				holeNo--;
			}
			else if (regionPosition < 0)
			{
				holeText = concText;
				holeNo--;
			}
		}
		return holeText;
	}

	/* Give next position of a flag represented by >> or << in a (subconcern) text */
	int nextRegionPosition(String text)
	{
		int tempId = 0;
		int openId = text.indexOf(globalVariable.OPENHOLE);
		int closeId = text.indexOf(globalVariable.CLOSEHOLE);
		if (openId < 0)
			tempId = closeId;
		else if (closeId < 0)
			tempId = openId;
		else
		{
			if (openId < closeId)
				tempId = openId;
			else
				tempId = closeId;
		}
		return tempId;
	}

	/* Returns subconcern the text in a particular concern for a 
	 * particular joinpoint specified by the regionName*/
	String getConcernText(String regionName, String concern)
	{
		regionName = regionName + globalVariable.NEWLINE;
		mainWindow.removeCaretListener("unWovenConcerns");
		AttributeSet currentAttributes =
			mainWindow.getCharacterAttributes("unWovenConcerns");
		Enumeration attributeNames = currentAttributes.getAttributeNames();
		Color tempColor = ((ConcernInfo)(concernMap.get(concern))).clr;
		String allUnwovenText = mainWindow.getText("unWovenConcerns",
			0, mainWindow.getLength("unWovenConcernsAbstractDoc"));
		String find = "concern " + concern;
		int offset = 0;
		int tempdId = 0;
		//Find the beginning of the concern
		while (true)
		{
			tempdId = allUnwovenText.indexOf(find, offset);
			if (tempdId < 0)
				break;
			offset = tempdId + 1;
			mainWindow.setCaretPosition("unWovenConcerns", tempdId);
			currentAttributes =
				mainWindow.getCharacterAttributes("unWovenConcerns");
			attributeNames = currentAttributes.getAttributeNames();
			Color foregroundColor = null;
			while (attributeNames.hasMoreElements())
			{
				Object nextAttribute = attributeNames.nextElement();
				String attributeString = nextAttribute.toString();
				if (attributeString.equals("foreground"))
				{
					foregroundColor = (Color)
						(currentAttributes.getAttribute(nextAttribute));
					break;
				}
			}
			if (foregroundColor.equals(tempColor))
				break;
		}
		//Find the end of the concern
		find = "}";
		int ctropen = 0;
		int closeBlockCounter = 0;
		boolean foundEnd = false;
		offset = 0;
		int tempId2 = 0;
		while (true)
		{
			tempId2 = allUnwovenText.indexOf(find, offset);
			if (tempId2 < 0)
				break;
			mainWindow.setCaretPosition("unWovenConcerns", tempId2);
			currentAttributes =
				mainWindow.getCharacterAttributes("unWovenConcerns");
			attributeNames = currentAttributes.getAttributeNames();
			Color foregroundColor = null;
			while (attributeNames.hasMoreElements())
			{
				Object nextAttribute = attributeNames.nextElement();
				String attributeString = nextAttribute.toString();
				if (attributeString.equals("foreground"))
					foregroundColor = (Color)
						(currentAttributes.getAttribute(nextAttribute));
			}
			if (!foregroundColor.equals(tempColor) && foundEnd)
				break;
			if (foregroundColor.equals(tempColor))
			{
				closeBlockCounter++;
				foundEnd = true;
			}
			offset = tempId2 + 1;
		}
		//Search within the range of the concern text for the joinpoint
		String regionText = mainWindow.getText("unWovenConcerns",
			tempdId, offset - tempdId);
		offset = 0;
		while (true)
		{
			int noOfOpen = 0;
			int noOfClose = 0;
			int offsetForOpen = 0;
			int offsetForClose = 0;
			tempdId = regionText.indexOf(regionName, offset);
			if (tempdId < 0)
				break;
			offset = tempdId + 1;
			String tempRegionText = regionText.substring(0, tempdId);
			while (true)
			{
				int tempIdOpen = tempRegionText.indexOf(
					globalVariable.OPENARROW, offsetForOpen);
				if (tempIdOpen < 0)
					break;
				offsetForOpen = tempIdOpen + 1;
				noOfOpen++;
			}
			while (true)
			{
				int tempIdClose = tempRegionText.indexOf(
					globalVariable.CLOSEARROW, offsetForClose);
				if (tempIdClose < 0)
					break;
				offsetForClose = tempIdClose + 1;
				noOfClose++;
			}
			if (noOfClose == noOfOpen)
				break;
		}
		regionText = regionText.substring(tempdId);
		int tempIndex = regionText.indexOf(globalVariable.OPENARROW);
		regionText = regionText.substring(tempIndex + 3);
		tempIndex = regionText.indexOf(globalVariable.CLOSEARROW);
		regionText = regionText.substring(0, tempIndex - 2);
		return (regionText);
	}

	public HashMap returnEqualHoles()
	{
		int currentPos = mainWindow.getCaretPosition("unWovenConcerns");
		String textTillCurrentPosition = mainWindow.getText("unWovenConcerns", 0, currentPos);
		int atPos = lastIndexOfAt(textTillCurrentPosition);
		textTillCurrentPosition = textTillCurrentPosition.substring(atPos);
		int endOfRegionPos = textTillCurrentPosition.indexOf("\n");
		String regionName = textTillCurrentPosition.substring(2, endOfRegionPos);
		int beginOfSubconcern = textTillCurrentPosition.indexOf(globalVariable.OPENARROW);
		String concernTextTillCurrentPos = textTillCurrentPosition.substring(beginOfSubconcern + 3);
		int holeNumber = getHoleNumber(concernTextTillCurrentPos);
		Object[] regionList = regionMap.keySet().toArray();
		RegionInfo currentRegionInfo = new RegionInfo("", new ArrayList(), -1, -1);
		int i = 0;
		for (i = 0; i < regionList.length; i++)
		{
			Integer regId = (Integer)regionList[i];
			currentRegionInfo = (RegionInfo)regionMap.get(regId);
			if (currentRegionInfo.regionName.equals(regionName))
				break;
		}
		int currPos = currentRegionInfo.begPos;
		int queryPos = currPos + holeNumber;
		listOfRegionIds.clear();
		regionTree.queryMethod(queryPos, queryPos, 0);
		HashMap equalHoles = new HashMap();
		for (i = 0; i < listOfRegionIds.size(); i++)
		{
			int tempId = (Integer)(listOfRegionIds.get(i));
			RegionInfo tempRegion = (RegionInfo)regionMap.get(tempId);
			int cSize = tempRegion.arrayListOfConcerns.size();
			if (tempRegion.regionName.equals(regionName) && cSize < 2)
				continue;
			int tempHoleNum = currPos + holeNumber - tempRegion.begPos;
			equalHoles.put(tempId, tempHoleNum);
		}
		return equalHoles;
	}

	int getHoleNumber(String text)
	{
		int tempIndex = 0;
		int holeNum = 0;
		boolean openSelected = false;
		while (text.indexOf(globalVariable.OPENHOLE) >= 0 ||
				text.indexOf(globalVariable.CLOSEHOLE) >= 0)
		{
			int openIndex = text.indexOf(globalVariable.OPENHOLE);
			int closeIndex = text.indexOf(globalVariable.CLOSEHOLE);
			if (openIndex < 0 && closeIndex >= 0)
			{ tempIndex = closeIndex; openSelected = false; }
			else if (openIndex >= 0 && closeIndex < 0)
			{ tempIndex = openIndex; openSelected = true; }
			else if (openIndex < closeIndex)
			{ tempIndex = openIndex; openSelected = true; }
			else if (closeIndex < openIndex)
			{ tempIndex = closeIndex; openSelected = false; }
			if (tempIndex == 0)
				tempIndex++;
			else //if (tempIndex > 0)
				holeNum++;
			if (openSelected)
			{
				text = text.substring(tempIndex);
				int spaceIndex = text.indexOf(" ");
				text = text.substring(spaceIndex + 1);
			}
			else
			{
				text = text.substring(tempIndex);
				int spaceIndex = text.indexOf(" ");
				text = text.substring(spaceIndex + 1);
				spaceIndex = text.indexOf(" ");
				text = text.substring(spaceIndex + 1);
			}

		}
		return holeNum;
	}

	int lastIndexOfAt(String text)
	{
		int tempIndex = text.lastIndexOf("@");
		if (tempIndex < 0)
			return -1;
		String tempText = text.substring(0, tempIndex);
		int countQuotes = 0;
		while (true)
		{
			int qIndex = tempText.indexOf('"');
			if (qIndex < 0)
				break;
			else
			{
				tempText = tempText.substring(qIndex + 1);
				countQuotes++;
			}
		}
		if (countQuotes % 2 == 0)
			return tempIndex;
		else
		{
			text = text.substring(0, tempIndex);
			return lastIndexOfAt(text);
		}
	}

	/* Translates from woven to unwoven view */
	void viewUnwoven()
	{
		mainWindow.removeTextFilter();
		mainWindow.removeTextFilter2();
		mainWindow.setText("statusBar", "Unweaving Code...");
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		if (getViewFlags())
		{
			mainWindow.setViewFlagState(false);
			viewFlags();
		}
		mainWindow.setText("unWovenConcerns", "");
		mainWindow.setText("unWovenBody", "");
		Object[] allRegions = regionMap.keySet().toArray();
		ArrayList tabPositions = new ArrayList();	/* ArrayList to capture locations in
													 * unwoven concerns where code is written.
													 * We modify tab sizes in those locations */
		String expression = mainWindow.getText("wovenCode",
	   0, mainWindow.getLength("wovenCodeAbstractDoc"));
		regionStartPosition.clear();
		regionEndPositions.clear();
		TokenVerifier tokenVerifier = new TokenVerifier();
		tokenVerifier.concMan = this;
		tokenVerifier.mainWindow = mainWindow;
		//Lex the whole text in the woven code
		tokenVerifier.lexAndAddPositions(expression, true);
		if (!tokenVerifier.getTokensOK())	//return if code does not lex correctly
		{
			woven = true;
			mainWindow.setText("statusBar",
				"IVCon - Inline Visualization of Concerns");
			return;
		}
		int i = 0;
		allRegions = regionMap.keySet().toArray();
		//Check if all concerns begin and end at beginning and end of tokens.
		//If they don't then show an error message, highlight that region and return
		for (i = 0; i < regionMap.size(); i++)
		{
			RegionInfo tempRegion = (RegionInfo)(regionMap.get((Integer)allRegions[i]));
			if (tempRegion.arrayListOfConcerns.isEmpty())
				continue;
			int bPos = tempRegion.begPos;
			int ePos = tempRegion.endPos;
			String joinpointName = tempRegion.regionName;
			int startIndex = java.util.Collections.binarySearch(
				regionStartPosition, bPos);
			final int ERRORCODELENGTH = 900;
			if (startIndex < 0)
			{	//Select erroneous text
				mainWindow.select("wovenCode", bPos, ePos + 1);
				String displayText = mainWindow.getSelectedText("wovenCode");
				if (displayText.length() > ERRORCODELENGTH)
					displayText = displayText.substring(0, ERRORCODELENGTH);
				while (displayText.indexOf(globalVariable.NEWLINE) > 0)
				{
					int ind = displayText.indexOf(globalVariable.NEWLINE);
					displayText = displayText.substring(0, ind) + "<BR>"
						+ displayText.substring(ind + 1);
				}
				//Show error msg
				JOptionPane.showMessageDialog(mainWindow.frame,
					"<html><B>The following concern at <I>" + joinpointName +
					" </I>is invalid.<BR><BR></B>...<font face=Courier New>" +
					displayText + "...</font><BR>" +
					"	<BR><font size=3>Code assigned to concerns must start at " +
					"the start of a token and end at the end of a token<BR><BR>",
					"Error", JOptionPane.ERROR_MESSAGE);
				woven = true;
				mainWindow.setText("statusBar",
					"IVCon - Inline Visualization of Concerns");
				return;
			}
			startIndex = java.util.Collections.binarySearch(regionEndPositions, ePos);
			if (startIndex < 0)
			{
				//Select erroneous text
				mainWindow.select("wovenCode", bPos, ePos + 1);
				String displayText = mainWindow.getSelectedText("wovenCode");
				if (displayText.length() > ERRORCODELENGTH)
					displayText = displayText.substring(0, ERRORCODELENGTH);
				while (displayText.indexOf(globalVariable.NEWLINE) > 0)
				{
					int ind = displayText.indexOf(globalVariable.NEWLINE);
					displayText = displayText.substring(0, ind) + "<BR>"
						+ displayText.substring(ind + 1);
				}
				//Show error msg
				JOptionPane.showMessageDialog(mainWindow.frame,
					"<html><B>The following concern at <I>" + joinpointName +
					" </I>is invalid.<BR><BR></B>...<font face=Courier New>" +
					displayText + "...</font><BR>" +
					"	<BR><font size=3>Code assigned to concerns must start at " +
					"the start of a token and end at the end of a token<BR><BR>",
					"Error", JOptionPane.ERROR_MESSAGE);
				woven = true;
				mainWindow.setText("statusBar",
					"IVCon - Inline Visualization of Concerns");
				return;
			}
		}
		String wovenCodeText = mainWindow.getText("wovenCode",
			0, mainWindow.getLength("wovenCodeAbstractDoc"));
		mainWindow.setVisible("splitUnwoven", true);
		mainWindow.setDividerLocation("splitPreview", 1);
		mainWindow.setVisible("scrPan", false);
		StyleConstants.setForeground(mainWindow.attrs[0], Color.BLACK);
		cleanUpMapsAndTree();
		totalRegions = regionMap.size();
		// Appending text to Unwoven Concerns
		// Go concern wise, checking where duplicate code appears within the same concern.
		// Duplicate code under the same concern is put under the same subconcern.
		Object[] allConcerns = concernMap.keySet().toArray();
		for (i = 0; i < concernMap.size(); i++)
		{
			String tempConcern = (String)(allConcerns[i]);
			ConcernInfo tempConcernInfo = (ConcernInfo)(concernMap.get(tempConcern));
			StyleConstants.setForeground(mainWindow.attrs[0], tempConcernInfo.clr);
			StyleConstants.setForeground(mainWindow.attrs[6], tempConcernInfo.clr);
			StyleConstants.setForeground(mainWindow.attrs[5], tempConcernInfo.clr);
			mainWindow.insertText("unWovenConcernsAbstractDoc",
				"concern " + tempConcern + "\n{\n", -1, 0);
			int j = 0;
			List tempList = new ArrayList();
			tempList = tempConcernInfo.arrayListOfRegions;
			boolean[] duplicates = new boolean[tempList.size()];
			//duplicates is a set of regions to indicate that this joinpoint shared code 
			//text with another joinpoint and has been appended to unwoven concerns already
			java.util.Arrays.fill(duplicates, false);
			while (j < tempList.size())
			{
				if (duplicates[j])
				{
					j++;
					continue;
				}
				RegionInfo tempRegion = (RegionInfo)(regionMap.get(tempList.get(j)));
				int startPosition = tempRegion.begPos;
				int endPosition = tempRegion.endPos;
				mainWindow.select("wovenCode", startPosition, (endPosition + 1));
				// Building the Subconcern Text
				String subConcern = mainWindow.getSelectedText("wovenCode");
				int startPosition2 = startPosition;
				int endPosition2 = endPosition;
				mainWindow.setInteger("currentNoOfRegions", 0);
				listOfRegionIds.clear();
				regionTree.queryMethod(startPosition2, endPosition2, 0);
				int loop = 0;
				List regionsBegin, regionsEnd;
				regionsBegin = new ArrayList();
				regionsEnd = new ArrayList();
				//				System.out.println("SIZE:"+listOfRegionIds.size());
				while (loop < listOfRegionIds.size())
				{
					int tempID = (Integer)listOfRegionIds.get(loop);
					RegionInfo tempReg = (RegionInfo)(regionMap.get(tempID));
					if (!tempReg.arrayListOfConcerns.isEmpty())
					{
						int tempInt = tempReg.begPos;
						if (tempInt >= startPosition2 && tempInt <= endPosition2)
							regionsBegin.add(tempReg);
						tempInt = tempReg.endPos;
						if (tempInt >= startPosition2 && tempInt <= endPosition2)
							regionsEnd.add(tempReg);
					}
					loop++;
				}
				/*				System.out.println("Fbesize "+regionsBegin.size());
								System.out.println("Fendsize " + regionsEnd.size());*/
				java.util.Collections.sort(regionsBegin);
				java.util.Collections.sort(regionsEnd);
				java.util.Collections.reverse(regionsEnd);
				int insertedChar = 0;
				List beginAndEnd = new ArrayList();
				List beginPositions = new ArrayList();
				List endPositions = new ArrayList();
				for (int ctr = 0; ctr < regionsBegin.size(); ctr++)
				{
					RegionInfo tempReg1 = (RegionInfo)regionsBegin.get(ctr);
					int loop1 = 0;
					while (loop1 < tempReg1.arrayListOfConcerns.size())
					{
						//						System.out.println(tempReg1.arrayListOfConcerns.size());
						if (!((String)(tempReg1.arrayListOfConcerns.get(loop1))).
							equals(tempConcern))
						{
							PositionConcernMap x = new PositionConcernMap
								(((RegionInfo)(regionsBegin.get(ctr))).begPos,
								((String)(tempReg1.arrayListOfConcerns.get(loop1))));
							beginAndEnd.add(x);
							beginPositions.add(x);
							//break;
						}
						loop1++;
					}
				}
				for (int ctr = 0; ctr < regionsEnd.size(); ctr++)
				{
					RegionInfo tempReg1 = (RegionInfo)regionsEnd.get(ctr);
					int loop1 = 0;
					while (loop1 < tempReg1.arrayListOfConcerns.size())
					{
						if (!((String)tempReg1.arrayListOfConcerns.get(loop1)).
							equals(tempConcern))
						{
							PositionConcernMap x = new PositionConcernMap
								(((RegionInfo)(regionsEnd.get(ctr))).endPos + 1,
								((String)tempReg1.arrayListOfConcerns.get(loop1)));
							beginAndEnd.add(x);
							endPositions.add(x);
							//break;
						}
						loop1++;
					}
				}
				java.util.Collections.sort(beginAndEnd);
				for (loop = 0; loop < beginAndEnd.size(); loop++)
				{
					PositionConcernMap position =
						(PositionConcernMap)beginAndEnd.get(loop);
					if (beginPositions.contains(position))
					{
						int insAtPos =
							position.position - startPosition2 + insertedChar;
						String preConc = subConcern.substring(0, insAtPos);
						String postConc =
							subConcern.substring(insAtPos, subConcern.length());
						subConcern = preConc + globalVariable.OPENHOLE + postConc;
						insertedChar++;
					}
					if (endPositions.contains(position))
					{
						int insAtPos =
							position.position - startPosition2 + insertedChar;
						String preConc =
							subConcern.substring(0, insAtPos);
						String postConc =
							subConcern.substring(insAtPos, subConcern.length());
						subConcern = preConc + globalVariable.CLOSEHOLE + postConc;
						insertedChar++;
					}
				}
				for (loop = 0; loop < beginAndEnd.size(); loop++)
					((PositionConcernMap)(beginAndEnd.get(loop))).position -=
						startPosition2;

				//Add the names of concerns existing within subconcern text 
				List concernAtOpen = new ArrayList();
				List concernAtClose = new ArrayList();
				int insSubcLoop = 0;
				while (insSubcLoop < regionsBegin.size())
				{
					RegionInfo insSubcMapf =
						(RegionInfo)regionsBegin.get(insSubcLoop);
					int nestSubc = 0;
					while (nestSubc < insSubcMapf.arrayListOfConcerns.size())
					{
						if (!((String)(insSubcMapf.arrayListOfConcerns.get(nestSubc)))
							.equals(tempConcern))
							concernAtOpen.add
								((String)(insSubcMapf.arrayListOfConcerns.get(nestSubc)));
						nestSubc++;
					}
					insSubcLoop++;
				}
				insSubcLoop = 0;
				while (insSubcLoop < regionsEnd.size())
				{
					RegionInfo insSubcMapf = (RegionInfo)regionsEnd.get(insSubcLoop);
					int nestSubc = 0;
					while (nestSubc < insSubcMapf.arrayListOfConcerns.size())
					{
						if (!((String)insSubcMapf.arrayListOfConcerns.get(nestSubc))
							.equals(tempConcern))
							concernAtClose.add((String)
								insSubcMapf.arrayListOfConcerns.get(nestSubc));
						nestSubc++;
					}
					insSubcLoop++;
				}
				mainWindow.insertText("unWovenConcernsAbstractDoc",
					"\tsubconcern @ " + tempRegion.regionName +
					globalVariable.NEWLINE, -1, 0);
				int k = j;
				while (k < tempList.size())
				{	//check to confirm that a concern already written is not written again.
					if (duplicates[k])
					{
						k++;
						continue;
					}
					if (k != j)
					{
						RegionInfo tempRegCheck =
							(RegionInfo)(regionMap.get(tempList.get(k)));
						//RegionInfo tempRegCheck = (RegionInfo)(tempList.get(k));
						int startPositionCheck = tempRegCheck.begPos;
						int endPositionCheck = tempRegCheck.endPos;
						mainWindow.select("wovenCode",
							startPositionCheck, (endPositionCheck + 1));
						// Building the subConcernCheck Text
						String subConcernCheck =
							mainWindow.getSelectedText("wovenCode");
						int startPositionCheck2 = startPositionCheck;
						int endPositionCheck2 = (endPositionCheck);
						mainWindow.setInteger("currentNoOfRegions", 0);
						listOfRegionIds.clear();
						regionTree.queryMethod
							(startPositionCheck2, endPositionCheck2, 0);
						int loopCheck = 0;
						List regionsBeginCheck, regionsEndCheck;
						regionsBeginCheck = new ArrayList();
						regionsEndCheck = new ArrayList();
						while (loopCheck < listOfRegionIds.size())
						{
							int tempIDCheck =
								(Integer)listOfRegionIds.get(loopCheck);
							RegionInfo locRegInfo =
								(RegionInfo)(regionMap.get(tempIDCheck));
							if (!locRegInfo.arrayListOfConcerns.isEmpty())
							{
								int tempIntCheck = locRegInfo.begPos;
								if (tempIntCheck >= startPositionCheck2 &&
									tempIntCheck <= endPositionCheck2)
									regionsBeginCheck.add(locRegInfo);
								tempIntCheck = locRegInfo.endPos;
								if (tempIntCheck >= startPositionCheck2 &&
									tempIntCheck <= endPositionCheck2)
									regionsEndCheck.add(locRegInfo);
							}
							loopCheck++;
						}
						java.util.Collections.sort(regionsBeginCheck);
						java.util.Collections.sort(regionsEndCheck);
						java.util.Collections.reverse(regionsEndCheck);
						int insertedCharCheck = 0;
						List beginAndEndCheck = new ArrayList();
						List beginPositionsCheck = new ArrayList();
						List endPositionChecks = new ArrayList();
						for (int ctr = 0; ctr < regionsBeginCheck.size(); ctr++)
						{
							RegionInfo tempReg1 =
								(RegionInfo)regionsBeginCheck.get(ctr);
							int loopCheck1 = 0;
							while (loopCheck1 < tempReg1.arrayListOfConcerns.size())
							{
								if (!((String)tempReg1.arrayListOfConcerns.
									get(loopCheck1)).equals(tempConcern))
								{
									PositionConcernMap posConcernMap = new
										PositionConcernMap(((RegionInfo)(
										regionsBeginCheck.get(ctr))).begPos,
										((String)tempReg1.
										arrayListOfConcerns.get(loopCheck1)));
									beginAndEndCheck.add(posConcernMap);
									beginPositionsCheck.add(posConcernMap);
									break;
								}
								loopCheck1++;
							}
						}
						for (int ctr = 0; ctr < regionsEndCheck.size(); ctr++)
						{
							RegionInfo tempReg1 =
								(RegionInfo)regionsEndCheck.get(ctr);
							int loopCheck1 = 0;
							while (loopCheck1 < tempReg1.arrayListOfConcerns.size())
							{
								if (!((String)tempReg1.arrayListOfConcerns.get(
									loopCheck1)).equals(tempConcern))
								{
									PositionConcernMap posConcernMap =
									new PositionConcernMap(
									((RegionInfo)(regionsEndCheck.get(ctr))).endPos
									+ 1, ((String)tempReg1.arrayListOfConcerns.
									get(loopCheck1)));
									beginAndEndCheck.add(posConcernMap);
									endPositionChecks.add(posConcernMap);
									break;
								}
								loopCheck1++;
							}
						}
						java.util.Collections.sort(beginAndEndCheck);
						for (loopCheck = 0;
							loopCheck < beginAndEndCheck.size();
							loopCheck++)
						{
							PositionConcernMap position = (PositionConcernMap)
								beginAndEndCheck.get(loopCheck);
							if (beginPositionsCheck.contains(position))
							{
								int insAtPos = position.position -
									startPositionCheck2 + insertedCharCheck;
								String preConc = subConcernCheck.substring(0, insAtPos);
								String postConc = subConcernCheck.substring(
									insAtPos, subConcernCheck.length());
								subConcernCheck = preConc + globalVariable.OPENHOLE
									+ postConc;
								insertedCharCheck++;
							}
							if (endPositionChecks.contains(position))
							{
								int insAtPos = position.position -
									startPositionCheck2 + insertedCharCheck;
								String preConc = subConcernCheck.substring(0, insAtPos);
								String postConc = subConcernCheck.substring(
									insAtPos, subConcernCheck.length());
								subConcernCheck = preConc +
									globalVariable.CLOSEHOLE + postConc;
								insertedCharCheck++;
							}
						}
						for (loopCheck = 0;
							loopCheck < beginAndEndCheck.size();
							loopCheck++)
							((PositionConcernMap)(beginAndEndCheck.get(loopCheck))).
								position -= startPositionCheck2;

						//Add the names of concerns existing within subconcern text 
						List concernOpenCheck = new ArrayList();
						List concernCloseCheck = new ArrayList();
						insSubcLoop = 0;
						while (insSubcLoop < regionsBeginCheck.size())
						{
							RegionInfo insSubcMapf = (RegionInfo)regionsBeginCheck.get(
								insSubcLoop);
							int nestSubc = 0;
							while (nestSubc < insSubcMapf.arrayListOfConcerns.size())
							{
								if (!((String)insSubcMapf.arrayListOfConcerns.
									get(nestSubc)).equals(tempConcern))
									concernOpenCheck.add(
				((String)insSubcMapf.arrayListOfConcerns.get(nestSubc)));
								nestSubc++;
							}
							insSubcLoop++;
						}

						insSubcLoop = 0;
						while (insSubcLoop < regionsEndCheck.size())
						{
							RegionInfo insSubcMapf =
								(RegionInfo)regionsEndCheck.get(insSubcLoop);
							int nestSubc = 0;
							while (nestSubc < insSubcMapf.arrayListOfConcerns.size())
							{
								if (!((String)insSubcMapf.arrayListOfConcerns.
									get(nestSubc)).equals(tempConcern))
									concernCloseCheck.add
				(((String)insSubcMapf.arrayListOfConcerns.get(nestSubc)));
								nestSubc++;
							}
							insSubcLoop++;
						}
						boolean areListsEqual = true;
						if (beginAndEnd.size() != beginAndEndCheck.size())
							areListsEqual = false;
						if (areListsEqual)
						{
							for (int it = 0; it < beginAndEnd.size(); it++)
							{
								if (!((PositionConcernMap)beginAndEnd.get(it)).
									equals((PositionConcernMap)
									(beginAndEndCheck.get(it))))
								{
									areListsEqual = false;
									break;
								}
							}
						}
						if (subConcern.equals(subConcernCheck) &&
							areListsEqual)
						{
							//if the subconcern text being checked is equivalent to the previously 
							//built subconcern text, we only add the joinpoint name. By equivalent 
							//we mean that the text content of both the subconcerns as well as the 
							//concerns nested within both the subconcerns code are same.
							mainWindow.insertText("unWovenConcernsAbstractDoc",
								"\t\t\t\t\t " + tempRegCheck.regionName +
								globalVariable.NEWLINE, -1, 0);
							duplicates[k] = true;
						}
					}
					k++;
				}
				// Inserting SubConcern text in UnWovenConerns Window
				mainWindow.insertText("unWovenConcernsAbstractDoc",
					"\t" + globalVariable.OPENARROW + "\n", -1, 0);
				int extraNoOfChars = 0;
				int offset = 0;
				int concernCounter = 0;
				int initialPosition =
					mainWindow.getLength("unWovenConcernsAbstractDoc");
				mainWindow.insertText
					("unWovenConcernsAbstractDoc", subConcern, initialPosition, 0);
				/* Capture code location in unwoven concerns panel*/
				tabPositions.add(initialPosition);
				// Inserting concern names with <<'s and >>'s in the subconcern text
				for (int addConcernCtr = 0;
					addConcernCtr < beginAndEnd.size();
					addConcernCtr++)
				{
					PositionConcernMap combo =
						(PositionConcernMap)beginAndEnd.get(addConcernCtr);
					StyleConstants.setForeground(mainWindow.attrs[6],
						((ConcernInfo)(concernMap.get(combo.concern))).clr);
					mainWindow.insertText("unWovenConcernsAbstractDoc",
						combo.concern, (initialPosition + combo.position
						+ 1 + extraNoOfChars + addConcernCtr), 6);
					if (mainWindow.getText("unWovenConcerns", (initialPosition +
						combo.position + extraNoOfChars + addConcernCtr), 1).
						equals(globalVariable.CLOSEHOLE))
					{
						StyleConstants.setBackground(mainWindow.attrs[5], Color.RED);
						mainWindow.insertText("unWovenConcernsAbstractDoc", " ",
								(initialPosition + combo.position + 1 +
								extraNoOfChars + addConcernCtr), 5);
						StyleConstants.setBackground(mainWindow.attrs[5], Color.WHITE);
						mainWindow.insertText("unWovenConcernsAbstractDoc", " ",
							(initialPosition + combo.position + 2 + extraNoOfChars +
							combo.concern.length() + addConcernCtr), 5);
						extraNoOfChars += combo.concern.length() + 2;
					}
					else
					{
						StyleConstants.setBackground
							(mainWindow.attrs[5], globalVariable.GREENCOLOR);
						mainWindow.insertText("unWovenConcernsAbstractDoc", " ",
						   (initialPosition + combo.position + 1 + extraNoOfChars
						   + combo.concern.length() + addConcernCtr), 5);
						extraNoOfChars += combo.concern.length() + 1;
					}
				}
				//System.out.println("Done Analyzing regions!!!");
				mainWindow.insertText("unWovenConcernsAbstractDoc",
					"\n\t" + globalVariable.CLOSEARROW + "\n", -1, 0);
				mainWindow.setMargin(initialPosition,
					initialPosition + subConcern.length() + extraNoOfChars);
				j++;
			}
			mainWindow.insertText("unWovenConcernsAbstractDoc", "}\n\n", -1, 0);
		}
		//Constructing the Unwoven Main Body
		StyleConstants.setForeground(mainWindow.attrs[0], Color.BLACK);
		mainWindow.insertText("unWovenBodyAbstractDoc", wovenCodeText, 0, 0);
		int startIndex, endIndex;
		int startPosition3 = 0;
		int endPosition3 = mainWindow.getLength("unWovenBodyAbstractDoc");
		mainWindow.setInteger("currentNoOfRegions", 0);
		listOfRegions.clear();
		regionTree.queryMethod(startPosition3, endPosition3, 2);
		//Collect points where "regions" begin and end.
		listOfRegions.add(startPosition3);
		listOfRegions.add(endPosition3);
		java.util.Collections.sort(listOfRegions);
		startIndex =
			java.util.Collections.binarySearch(listOfRegions, startPosition3);
		endIndex = java.util.Collections.binarySearch(listOfRegions, endPosition3);
		List tempList = new ArrayList();
		allRegions = regionMap.keySet().toArray();
		for (i = 0; i < regionMap.size(); i++)
		{
			if (!((RegionInfo)(regionMap.get((Integer)allRegions[i]))).
				arrayListOfConcerns.isEmpty())
				tempList.add
					(((RegionInfo)(regionMap.get((Integer)allRegions[i]))).begPos);
		}
		List tempList2 = new ArrayList();
		i = startIndex;
		while (i <= endIndex)
		{
			tempList2.add(listOfRegions.get(i));
			i++;
		}
		tempList2 = removeDuplicates(tempList2);
		i = 0;
		List regionSorted = new ArrayList();
		i = 0;
		while (i < regionMap.size())
		{
			RegionInfo tempRegion =
				new RegionInfo((RegionInfo)(regionMap.get((Integer)allRegions[i])));
			regionSorted.add(tempRegion);
			i++;
		}
		java.util.Collections.sort(regionSorted);
		i = 0;
		mainWindow.selectAll("wovenCode");
		int replacedLength = 0;
		int[] noOfRegions = new int[regionMap.size()];
		//noOfRegions: no of regions associated with a particular region. This
		//array helps in updating values in regionMap and RTree.
		java.util.Arrays.fill(noOfRegions, 0);
		List indexRef = java.util.Arrays.asList(regionMap.keySet().toArray());
		// HOLE Replacement Code: Each "region" gets replaced by a hole
		while (i < tempList2.size() - 1)
		{
			startPosition3 = (Integer)(tempList2.get(i));
			endPosition3 = (Integer)(tempList2.get(i + 1));
			listOfRegionIds.clear();
			regionTree.queryMethod(startPosition3, startPosition3, 0);
			mainWindow.setCaretPosition("wovenCode", startPosition3);
			//Replace "region" text with a hole and apply formatting to the hole
			//in accordance with the number of concerns at the hole position
			if (mainWindow.getInteger("currentNoOfRegions") == 1)
			{
				StyleConstants.setBold(mainWindow.attrs[4], false);
				int regionId = (Integer)(listOfRegionIds.get(0));
				listOfRegionIds.clear();
				String tempConcern = (String)(((RegionInfo)
					(regionMap.get(regionId))).arrayListOfConcerns.get(0));
				Color tempColor =
					((ConcernInfo)(concernMap.get(tempConcern))).clr;
				StyleConstants.setForeground(mainWindow.attrs[4], tempColor);
				mainWindow.select
					("unWovenBody", (startPosition3 - replacedLength),
					(endPosition3 - replacedLength));
				String selectedText = mainWindow.getSelectedText("unWovenBody");
				mainWindow.replaceSelection("unWovenBody", "");
				mainWindow.insertText("unWovenBodyAbstractDoc",
					globalVariable.HOLE, (startPosition3 - replacedLength), 4);
				noOfRegions[indexRef.indexOf((Object)regionId)]++;
				if (tempList.contains(startPosition3))
					((RegionInfo)(regionMap.get(regionId))).begPos =
						startPosition3 - replacedLength;
				replacedLength += endPosition3 - startPosition3 - 1;
			}
			else if (mainWindow.getInteger("currentNoOfRegions") > 1)
			{
				StyleConstants.setForeground(mainWindow.attrs[5], Color.WHITE);
				StyleConstants.setBackground(mainWindow.attrs[5], MCB);
				mainWindow.select("unWovenBody", (startPosition3 - replacedLength),
					(endPosition3 - replacedLength));
				String selectedText = mainWindow.getSelectedText("unWovenBody");
				mainWindow.replaceSelection("unWovenBody", "");
				mainWindow.insertText("unWovenBodyAbstractDoc",
					globalVariable.HOLE, (startPosition3 - replacedLength), 5);
				for (int itHoles = 0;
					itHoles < listOfRegionIds.size();
					itHoles++)
				{
					int tempRegionId = (Integer)listOfRegionIds.get(itHoles);
					noOfRegions[indexRef.indexOf((Object)tempRegionId)]++;
					if (((RegionInfo)(regionMap.get(tempRegionId))).begPos ==
						startPosition3)
						((RegionInfo)(regionMap.get(tempRegionId))).begPos =
							startPosition3 - replacedLength;
				}
				replacedLength += endPosition3 - startPosition3 - 1;
			}
			i++;
		}
		// Transforming Regions 
		//indexRef.clear();
		indexRef = java.util.Arrays.asList(regionMap.keySet().toArray());
		i = 0;
		boolean[] done = new boolean[regionMap.size()];
		java.util.Arrays.fill(done, false);
		int initialPosition = 0;
		replacedLength = 0;
		while (i < regionMap.size())
		{
			int tempIndex = (Integer)indexRef.get(i);
			if (((RegionInfo)(regionMap.get(tempIndex))).begPos >= 0)
				((RegionInfo)(regionMap.get(tempIndex))).endPos =
					((RegionInfo)(regionMap.get(tempIndex))).begPos +
					noOfRegions[i] - 1;
			i++;
		}
		// Updating RTree
		int tempBegPosition, tempEndPosition, tempID;
		regionTree.initRTree();
		mainWindow.updateRTree(regionTree.getRTree());
		for (i = 0; i < regionMap.size(); i++)
		{
			int tempIndex = (Integer)indexRef.get(i);
			if (!((RegionInfo)(regionMap.get(tempIndex))).
				arrayListOfConcerns.isEmpty())
			{
				tempBegPosition =
					((RegionInfo)(regionMap.get(tempIndex))).begPos;
				tempEndPosition =
					((RegionInfo)(regionMap.get(tempIndex))).endPos;
				tempID = tempIndex;
				regionTree.addRegionToTree
					(tempBegPosition, tempEndPosition, tempID);
			}
		}
		woven = false;
		/* Making the >>'s invisible: They function only as delimiters now*/
		String unWovenConcernText = mainWindow.getText("unWovenConcerns", 0,
			mainWindow.getLength("unWovenConcernsAbstractDoc"));
		int openHoleIndex = 0;
		int searchIndex = 0;
		while (openHoleIndex >= 0)
		{
			openHoleIndex =
				unWovenConcernText.indexOf(globalVariable.OPENHOLE, searchIndex);
			if (openHoleIndex < 0)
				break;
			if (!mainWindow.getText("unWovenConcerns", (openHoleIndex - 1), 2).
				equals(globalVariable.OPENARROW))
			{
				mainWindow.select
					("unWovenConcerns", openHoleIndex, openHoleIndex + 1);
				mainWindow.replaceSelection("unWovenConcerns", "");
				mainWindow.insertText("unWovenConcernsAbstractDoc",
					globalVariable.OPENHOLE, openHoleIndex, 7);
			}
			searchIndex = openHoleIndex + 1;
		}
		unWovenConcernText = mainWindow.getText("unWovenConcerns", 0,
			mainWindow.getLength("unWovenConcernsAbstractDoc"));
		int closeHoleIndex = 0;
		searchIndex = 0;
		/* Making the <<'s invisible: They function only as delimiters now*/
		while (closeHoleIndex >= 0)
		{
			closeHoleIndex =
				unWovenConcernText.indexOf(globalVariable.CLOSEHOLE, searchIndex);
			if (closeHoleIndex < 0)
				break;
			if (!mainWindow.getText("unWovenConcerns", closeHoleIndex, 2).equals
				(globalVariable.CLOSEARROW))
			{
				mainWindow.select("unWovenConcerns",
					closeHoleIndex, closeHoleIndex + 1);
				mainWindow.replaceSelection("unWovenConcerns", "");
				mainWindow.insertText("unWovenConcernsAbstractDoc",
					globalVariable.CLOSEHOLE, closeHoleIndex, 7);
			}
			searchIndex = closeHoleIndex + 1;
		}

		/* Set smaller tabs in the unwoven concerns window at code locations*/
		for (int tabs = 0; tabs < tabPositions.size(); tabs++)
		{
			int tabsPos = (Integer)tabPositions.get(tabs);
			mainWindow.setCaretPosition("unWovenConcerns", tabsPos);
			mainWindow.setTabSize();
		}
		/* Display Settings */
		mainWindow.setEnabled("jumpToConcern", true);
		mainWindow.setEnabled("compile", false);
		mainWindow.setEnabled("export", false);
		mainWindow.setEnabled("renameJoinPointMenuItem", false);
		mainWindow.setEnabled("unWovenFormMenuItem", false);
		mainWindow.setEnabled("wovenFormMenuItem", true);
		mainWindow.setEnabled("assignToConcernMenuItem", false);
		mainWindow.setEnabled("save", false);
		mainWindow.setEnabled("saveAs", false);
		mainWindow.setEnabled("submenuRemove", false);
		mainWindow.setEnabled("addAConcernMenuItem", false);
		mainWindow.setEnabled("editConcern", false);
		mainWindow.addKeyListener("unWovenBody");
		mainWindow.addKeyListener("unWovenConcerns");
		mainWindow.addCaretListener("unWovenBody");
		mainWindow.addCaretListener("unWovenConcerns");
		mainWindow.removeKeyListener("wovenCode");
		mainWindow.removeCaretListener("wovenCode");
		mainWindow.createPopupMenu();
		mainWindow.setText("statusBar",
			"IVCon - Inline Visualization of Concerns");
		mainWindow.setTextFilter();
		mainWindow.setTextFilter2();
	}

	/* Assigns selected text to a new concern */
	void newConcern()
	{
		if (mainWindow.getCharTyped() != 0)
		{
			updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		if (mainWindow.getSelectedText("wovenCode") != null)
		{
			String newConcernName = new String("");
			while (newConcernName.equals(new String("")))
			{//Prompt user for a new concern name
				newConcernName =
					(String)JOptionPane.showInputDialog(mainWindow.frame,
						"Enter Name of New Concern:", "Add New Concern",
						JOptionPane.QUESTION_MESSAGE, null, null, null);
				if (newConcernName == null)
					return;
				newConcernName = newConcernName.trim();
				if (!checkConcernName(newConcernName, ""))
					newConcernName = "";
			}
			//Generate a random color for the new concern
			Random randomGenerator = new Random();
			int int1 = randomGenerator.nextInt(255);
			int int2 = randomGenerator.nextInt(255);
			int int3 = randomGenerator.nextInt(255);
			Color randomColor = new Color(int1, int2, int3);
			//Prompt user for a color for the new concern
			Color newColor = randomColor;
			boolean colorOK = false;
			while (!colorOK)
			{
				newColor = JColorChooser.showDialog(mainWindow.frame,
					"Choose New Color for Concern " +
					newConcernName, randomColor);
				colorOK = checkConcernColor(newColor, randomColor);
			}


			if (newColor != null)
			{
				// Checking whether currently selected Region already exists or not
				boolean regionExists = false;
				int regionNum = 0;
				int startPosition = mainWindow.getSelectionStart("wovenCode");
				int endPosition = mainWindow.getSelectionEnd("wovenCode");
				Object[] allRegions = regionMap.keySet().toArray();
				while (regionNum < regionMap.size())
				{
					if (((RegionInfo)(regionMap.get((Integer)allRegions[regionNum])))
						.begPos == startPosition &&
						((RegionInfo)(regionMap.get((Integer)allRegions[regionNum])))
						.endPos == endPosition - 1)
					{
						regionExists = true;
						break;
					}
					regionNum++;
				}
				changeColor(startPosition, (endPosition - 1), newColor);
				if (!regionExists)
				{
					String newRegionName = new String("");
					while (newRegionName.equals(new String("")))
					{//Prompt user for the name of a new joinpoint
						newRegionName =
							(String)JOptionPane.showInputDialog(mainWindow.frame,
							"Enter a Name for this code region:",
							"Name Code Region",
							JOptionPane.QUESTION_MESSAGE, null, null,
							"region_" + newConcernName + "_" + 0);
						if (newRegionName == null)
							return;
						newRegionName = newRegionName.trim();
						if (!checkJoinPointName(newRegionName, ""))
							newRegionName = "";
					}
					//Update regionMap and Concernmap with information from new concern
					List newConcernList = new ArrayList();
					newConcernList.add(newConcernName);
					regionMap.put(uniqueId, new RegionInfo
						(newRegionName, newConcernList, startPosition,
						(endPosition - 1)));
					List newRegionList = new ArrayList();
					newRegionList.add(uniqueId);
					concernMap.put(newConcernName,
						new ConcernInfo(newColor, newRegionList));
					regionTree.addRegionToTree(startPosition,
						(endPosition - 1), uniqueId);
					totalRegions++;
					uniqueId++;
				}
				if (regionExists)
				{
					((RegionInfo)(regionMap.get(allRegions[regionNum]))).
						arrayListOfConcerns.add(newConcernName);
					List newRegionList = new ArrayList();
					newRegionList.add((Object)allRegions[regionNum]);
					concernMap.put(newConcernName,
						new ConcernInfo(newColor, newRegionList));
				}
				StyleConstants.setBold(mainWindow.attrs[0], false);
				StyleConstants.setForeground(mainWindow.attrs[0], newColor);
				mainWindow.insertText("concernLegendAbstractDoc",
					newConcernName + globalVariable.NEWLINE, -1, 0);
				mainWindow.setCaretPosition("wovenCode", startPosition);
				noOfConcerns++;
				//Update pop up menu so that the new concern shows up in the pop up menu
				mainWindow.createPopupMenu();
			}
		}
		else	//if no text selected then display error message and return
			JOptionPane.showMessageDialog(mainWindow.frame,
				"Select Code Text to Assign to a Concern.",
				"IVCON", JOptionPane.WARNING_MESSAGE);
	}

	/* Used to refresh text formatting when assigning new areas to a concern */
	void changeColor(int startPosition, int endPosition, Color newColor)
	{
		int startPos = startPosition;
		int endPos = endPosition + 1;
		mainWindow.setInteger("currentNoOfRegions", 0);
		listOfRegions.clear();
		if (noOfConcerns != 0)
		{   //Collect points where "regions" within the given area (i.e. area 
			//for which text formatting has to be updated begin and end.
			regionTree.queryMethod(startPos, endPos, 2);
			listOfRegions.add(startPos);
			listOfRegions.add(endPos);
			int i;
			java.util.Collections.sort(listOfRegions);
			int startIndex =
				java.util.Collections.binarySearch(listOfRegions, startPos);
			int endIndex =
				java.util.Collections.binarySearch(listOfRegions, endPos);
			List tempList = new ArrayList();
			i = startIndex;
			while (i <= endIndex)
			{
				tempList.add(listOfRegions.get(i));
				i++;
			}
			tempList = removeDuplicates(tempList);
			i = 0;
			mainWindow.selectAll("wovenCode");
			//Apply formatting to the regions based on number of concerns in the region.
			while (i < tempList.size() - 1)
			{
				startPos = (Integer)(tempList.get(i));
				endPos = (Integer)(tempList.get(i + 1));
				mainWindow.setCaretPosition("wovenCode", startPos);
				if (mainWindow.getInteger("currentNoOfRegions") == 0)
				{
					StyleConstants.setBold(mainWindow.attrs[4], false);
					StyleConstants.setForeground(mainWindow.attrs[4], newColor);
					mainWindow.select("wovenCode", startPos, endPos);
					String selectedText = mainWindow.getSelectedText("wovenCode");
					mainWindow.replaceSelection("wovenCode", "");
					mainWindow.insertText
						("wovenCodeAbstractDoc", selectedText, startPos, 4);
				}
				else if (mainWindow.getInteger("currentNoOfRegions") > 0)
				{
					StyleConstants.setBold(mainWindow.attrs[5], false);
					StyleConstants.setForeground(
						mainWindow.attrs[5], java.awt.Color.WHITE);
					StyleConstants.setBackground
						(mainWindow.attrs[5], MCB);
					mainWindow.select("wovenCode", startPos, endPos);
					String selectedText = mainWindow.getSelectedText("wovenCode");
					mainWindow.replaceSelection("wovenCode", "");
					mainWindow.insertText
						("wovenCodeAbstractDoc", selectedText, startPos, 5);
				}
				i++;
			}
		}
		else	//if this is the first concern, we just select the specified area and color it.
		{
			StyleConstants.setBold(mainWindow.attrs[5], false);
			StyleConstants.setForeground(mainWindow.attrs[5], newColor);
			mainWindow.select("wovenCode", startPos, endPos);
			String selectedText = mainWindow.getSelectedText("wovenCode");
			mainWindow.replaceSelection("wovenCode", "");
			mainWindow.insertText("wovenCodeAbstractDoc", selectedText, startPos, 5);
		}
	}

	/* Refreshes text formatting when a concern color is edited */
	void editColor(int startPosition, int endPosition, Color newColor)
	{
		String targetDoc, targetWindow;
		if (woven)
		{
			targetWindow = "wovenCode";
			targetDoc = "wovenCodeAbstractDoc";
		}
		else
		{
			targetWindow = "unWovenBody";
			targetDoc = "unWovenBodyAbstractDoc";
		}
		//Collect points where "regions" within the given area (i.e. area 
		//for which text formatting has to be updated begin and end.
		int startPos = startPosition;
		int endPos = endPosition + 1;
		mainWindow.setInteger("currentNoOfRegions", 0);
		listOfRegions.clear();
		regionTree.queryMethod(startPos, endPos, 2);
		listOfRegions.add(startPos);
		listOfRegions.add(endPos);
		int i;
		java.util.Collections.sort(listOfRegions);
		int startIndex = java.util.Collections.binarySearch(listOfRegions, startPos);
		int endIndex = java.util.Collections.binarySearch(listOfRegions, endPos);
		List tempList = new ArrayList();
		i = startIndex;
		while (i <= endIndex)
		{
			tempList.add(listOfRegions.get(i));
			i++;
		}
		i = 0;
		tempList = removeDuplicates(tempList);
		mainWindow.selectAll(targetWindow);
		//Apply formatting to the regions based on number of concerns in the region.
		while (i < tempList.size() - 1)
		{
			startPos = (Integer)(tempList.get(i));
			endPos = (Integer)(tempList.get(i + 1));

			mainWindow.setCaretPosition(targetWindow, startPos);
			if (mainWindow.getInteger("currentNoOfRegions") == 1)
			{
				StyleConstants.setBold(mainWindow.attrs[4], false);
				StyleConstants.setForeground(mainWindow.attrs[4], newColor);
				mainWindow.select(targetWindow, startPos, endPos);
				String temp = mainWindow.getSelectedText(targetWindow);
				mainWindow.replaceSelection(targetWindow, "");
				mainWindow.insertText(targetDoc, temp, startPos, 4);
			}
			else if (mainWindow.getInteger("currentNoOfRegions") > 1)
			{// Formatting does not change in this case
			}
			i++;
		}
	}

	public void updateEqualHoles(HashMap equalHoles)
	{
		Object[] regions = equalHoles.keySet().toArray();
		int position = mainWindow.getCaretPosition("unWovenConcerns");
		String currentHoleText = getCurrentHoleText();
		for (int i = 0; i < equalHoles.size(); i++)
		{
			Integer regionID = (Integer)regions[i];
			int rid = regionID.intValue();
			int holeid = ((Integer)equalHoles.get(regionID)).intValue();
			this.updateRegionText(rid, holeid, currentHoleText);
		}
		mainWindow.setCaretPosition("unWovenConcerns", position);
	}

	public String getCurrentHoleText()
	{
		int tempIndex;
		int currPos = mainWindow.getCaretPosition("unWovenConcerns");
		int uwcLen = mainWindow.getLength("unWovenConcernsAbstractDoc");
		boolean openFlag = false;
		int preIndex = 0;
		int postIndex = 0;
		String preText = mainWindow.getText("unWovenConcerns", 0, currPos);
		int prePos = preText.lastIndexOf(globalVariable.OPENARROW);
		preText = preText.substring(prePos + 3);
		int index1 = preText.lastIndexOf(globalVariable.OPENHOLE);
		int index2 = preText.lastIndexOf(globalVariable.CLOSEHOLE);
		if (index1 < 0 && index2 < 0)
			preIndex = -1;
		else if (index1 < 0 && index2 >= 0)
			preIndex = index2;
		else if (index1 >= 0 && index2 < 0)
		{ preIndex = index1; openFlag = true; }
		else if (index1 >= 0 && index2 >= 0)
		{
			if (index1 > index2)
			{ preIndex = index1; openFlag = true; }
			else
				preIndex = index2;
		}
		if (preIndex != -1)
		{
			preText = preText.substring(preIndex);
			if (openFlag)
			{
				tempIndex = preText.indexOf(" ");
				preText = preText.substring(tempIndex + 1);
			}
			else
			{
				tempIndex = preText.indexOf(" ");
				preText = preText.substring(tempIndex + 1);
				tempIndex = preText.indexOf(" ");
				preText = preText.substring(tempIndex + 1);
			}
		}
		String postText = mainWindow.getText("unWovenConcerns", currPos,
			uwcLen - currPos);
		int postPos = postText.indexOf(globalVariable.CLOSEARROW);
		postText = postText.substring(0, postPos - 2);
		index1 = postText.indexOf(globalVariable.OPENHOLE);
		index2 = postText.indexOf(globalVariable.CLOSEHOLE);
		if (index1 < 0 && index2 < 0)
			postIndex = -1;
		else if (index1 < 0 && index2 >= 0)
			postIndex = index2;
		else if (index1 >= 0 && index2 < 0)
			postIndex = index1;
		else if (index1 >= 0 && index2 >= 0)
		{
			if (index1 < index2)
				postIndex = index1;
			else
				postIndex = index2;
		}
		if (postIndex != -1)
			postText = mainWindow.getText("unWovenConcerns", currPos, postIndex);
		String holeText = preText.concat(postText);
		return holeText;
	}

	public void updateRegionText(int rid, int holeNum, String text)
	{
		int tempIndex;
		int replacedLen = 0;
		String regionName = ((RegionInfo)regionMap.get(rid)).regionName;
		int uwcLen = mainWindow.getLength("unWovenConcernsAbstractDoc");
		int regionNum = 1;
		boolean loop = true;
		do
		{
			replacedLen = 0;
			String uwcText = mainWindow.getText("unWovenConcerns", 0, uwcLen);
			int initialLength = uwcText.length();
			int ctr = 0;
			while (ctr < regionNum)
			{
				int skipIndex = uwcText.indexOf(regionName);
				if (skipIndex < 0)
				{
					loop = false;
					break;
				}
				uwcText = uwcText.substring(skipIndex + 1);
				ctr++;
			}
			if (!loop)
				break;
			regionNum++;
			int finalLength = uwcText.length();
			replacedLen += initialLength - finalLength;
			/*int rIndex = uwcText.indexOf(regionName);
uwcText = uwcText.substring(rIndex);
			replacedLen += rIndex;*/
						int oaIndex = uwcText.indexOf(globalVariable.OPENARROW);
			uwcText = uwcText.substring(oaIndex + 3);
			replacedLen += oaIndex + 3;
			int caIndex = uwcText.indexOf(globalVariable.CLOSEARROW);
			uwcText = uwcText.substring(0, caIndex - 2);
			int i = 0;
			int j = 0;
			int lenI = uwcText.length();
			uwcText = removeAdjoiningFlags(uwcText);
			int lenF = uwcText.length();
			replacedLen += lenI - lenF;
			while (i < holeNum)
			{
				int index1 = uwcText.indexOf(globalVariable.OPENHOLE);
				int index2 = uwcText.indexOf(globalVariable.CLOSEHOLE);
				if (index1 < 0 && index2 < 0)
					break;
				else if (index1 < 0 && index2 > 0)
				{
					tempIndex = uwcText.indexOf(globalVariable.CLOSEHOLE);
					uwcText = uwcText.substring(tempIndex + 2);
					replacedLen += tempIndex + 2;
					tempIndex = uwcText.indexOf(" ");
					uwcText = uwcText.substring(tempIndex + 1);
					replacedLen += tempIndex + 1;
					lenI = uwcText.length();
					uwcText = removeAdjoiningFlags(uwcText);
					lenF = uwcText.length();
					replacedLen += lenI - lenF;
					i++;
				}
				else if (index1 > 0 && index2 < 0)
				{
					tempIndex = uwcText.indexOf(globalVariable.OPENHOLE);
					uwcText = uwcText.substring(tempIndex + 1);
					replacedLen += tempIndex + 1;
					tempIndex = uwcText.indexOf(" ");
					uwcText = uwcText.substring(tempIndex + 1);
					replacedLen += tempIndex + 1;
					lenI = uwcText.length();
					uwcText = removeAdjoiningFlags(uwcText);
					lenF = uwcText.length();
					replacedLen += lenI - lenF;
					i++;
				}
				else if (index1 > 0 && index2 > 0)
				{
					if (index1 < index2)
					{
						tempIndex = uwcText.indexOf(globalVariable.OPENHOLE);
						uwcText = uwcText.substring(tempIndex + 1);
						replacedLen += tempIndex + 1;
						tempIndex = uwcText.indexOf(" ");
						uwcText = uwcText.substring(tempIndex + 1);
						replacedLen += tempIndex + 1;
						lenI = uwcText.length();
						uwcText = removeAdjoiningFlags(uwcText);
						lenF = uwcText.length();
						replacedLen += lenI - lenF;
						i++;
					}
					else
					{
						tempIndex = uwcText.indexOf(globalVariable.CLOSEHOLE);
						uwcText = uwcText.substring(tempIndex + 2);
						replacedLen += tempIndex + 2;
						tempIndex = uwcText.indexOf(" ");
						uwcText = uwcText.substring(tempIndex + 1);
						replacedLen += tempIndex + 1;
						lenI = uwcText.length();
						uwcText = removeAdjoiningFlags(uwcText);
						lenF = uwcText.length();
						replacedLen += lenI - lenF;
						i++;
					}
				}
			}
			int offset = 0;
			// Find the end of the hole
			while (true)
			{
				int index1 = uwcText.indexOf(globalVariable.OPENHOLE);
				int index2 = uwcText.indexOf(globalVariable.CLOSEHOLE);
				if (index1 < 0 && index2 < 0)
				{
					offset = uwcText.length();
					break;
				}
				if (index1 < 0 && index2 > 0)
				{ offset = index2; break; }
				else if (index1 > 0 && index2 < 0)
				{ offset = index1; break; }
				else if (index1 > 0 && index2 > 0)
				{
					if (index1 < index2)
					{ offset = index1; break; }
					else
					{ offset = index2; break; }
				}
			}
			mainWindow.select("unWovenConcerns", replacedLen, replacedLen + offset);
			mainWindow.replaceSelection("unWovenConcerns", text);
		} while (loop);
	}

	String removeAdjoiningFlags(String concernText)
	{
		while (concernText.indexOf(globalVariable.OPENHOLE) == 0 ||
				concernText.indexOf(globalVariable.CLOSEHOLE) == 0)
		{
			if (concernText.indexOf(globalVariable.OPENHOLE) == 0)
			{
				int tempIndex = concernText.indexOf(" ");
				concernText = concernText.substring(tempIndex + 1);
			}
			else if (concernText.indexOf(globalVariable.CLOSEHOLE) == 0)
			{
				int tempIndex = concernText.indexOf(" ");
				concernText = concernText.substring(tempIndex + 1);
				tempIndex = concernText.indexOf(" ");
				concernText = concernText.substring(tempIndex + 1);
			}
		}
		return concernText;
	}

	public void viewFlags()
	{
		class FlagInformation implements Comparable
		{
			int position, ID;
			List listOfConcerns;
			boolean begFlag;
			public FlagInformation(int pos, int id, List concerns, boolean bFlag)
			{
				position = pos;
				ID = id;
				listOfConcerns = concerns;
				begFlag = bFlag;
			}
			public void display()
			{
				System.out.println(position + "," + ID + "," + listOfConcerns + "," + begFlag);
			}
			public int compareTo(Object o)
			{ return ((Integer)position).compareTo((Integer)(((FlagInformation)o).position)); }
		}
		if (mainWindow.getViewFlagState())
		{
			List allFlags = new ArrayList();
			Object[] regionIds = regionMap.keySet().toArray();
			for (int i = 0; i < regionMap.size(); i++)
			{
				RegionInfo tempRegion = (RegionInfo)regionMap.get(i);
				//			System.out.println(tempRegion.arrayListOfConcerns);
				FlagInformation tempFlagInfo = new FlagInformation(tempRegion.begPos, ((Integer)regionIds[i]).intValue(), tempRegion.arrayListOfConcerns, true);
				allFlags.add(tempFlagInfo);
				tempFlagInfo = new FlagInformation(tempRegion.endPos, ((Integer)regionIds[i]).intValue(), tempRegion.arrayListOfConcerns, false);
				allFlags.add(tempFlagInfo);
			}
			java.util.Collections.sort(allFlags);
			int replacedLen = 0;
			for (int i = 0; i < allFlags.size(); i++)
			{
				FlagInformation tempFlagInfo = (FlagInformation)allFlags.get(i);
				//System.out.println(tempFlagInfo.position + "," + tempFlagInfo.regionName + "," + tempFlagInfo.concerns + "," + tempFlagInfo.begFlag);
				if (tempFlagInfo.begFlag)
				{
					StyleConstants.setBackground(mainWindow.attrs[5], Color.GREEN);
					for (int j = 0; j < tempFlagInfo.listOfConcerns.size(); j++)
					{
						mainWindow.insertText("wovenCodeAbstractDoc", " ", replacedLen + tempFlagInfo.position, 5);
						mainWindow.insertText("wovenCodeAbstractDoc", globalVariable.OPENHOLE, replacedLen + tempFlagInfo.position, 7);
						String concernName = (String)tempFlagInfo.listOfConcerns.get(j);
						Color concernColor = ((ConcernInfo)concernMap.get(concernName)).clr;
						StyleConstants.setForeground(mainWindow.attrs[6], concernColor);
						mainWindow.insertText("wovenCodeAbstractDoc", concernName, replacedLen + tempFlagInfo.position, 6);
						replacedLen += 2 + concernName.length();
					}
					RegionInfo tempRegion = (RegionInfo)regionMap.get(tempFlagInfo.ID);
					tempRegion.begPos += replacedLen;
				}
				else
				{
					StyleConstants.setBackground(mainWindow.attrs[5], Color.WHITE);
					RegionInfo tempRegion = (RegionInfo)regionMap.get(tempFlagInfo.ID);
					tempRegion.endPos += replacedLen;
					for (int j = 0; j < tempFlagInfo.listOfConcerns.size(); j++)
					{
						mainWindow.insertText("wovenCodeAbstractDoc", " ", replacedLen + tempFlagInfo.position + 1, 5);
						String concernName = (String)tempFlagInfo.listOfConcerns.get(j);
						Color concernColor = ((ConcernInfo)concernMap.get(concernName)).clr;
						StyleConstants.setForeground(mainWindow.attrs[6], concernColor);
						mainWindow.insertText("wovenCodeAbstractDoc", concernName, replacedLen + tempFlagInfo.position + 1, 6);
						StyleConstants.setBackground(mainWindow.attrs[5], Color.RED);
						mainWindow.insertText("wovenCodeAbstractDoc", " ", replacedLen + tempFlagInfo.position + 1, 5);
						mainWindow.insertText("wovenCodeAbstractDoc", globalVariable.CLOSEHOLE, replacedLen + tempFlagInfo.position + 1, 7);
						replacedLen += 3 + concernName.length();
					}
				}
			}
		}
		else
		{
			mainWindow.setEditable("wovenCode", true);
			mainWindow.removeCaretListener("wovenCode");
			List allFlags = new ArrayList();
			Object[] regionIds = regionMap.keySet().toArray();
			for (int i = 0; i < regionMap.size(); i++)
			{
				RegionInfo tempRegion = (RegionInfo)regionMap.get(i);
				//			System.out.println(tempRegion.arrayListOfConcerns);
				FlagInformation tempFlagInfo = new FlagInformation(tempRegion.begPos, ((Integer)regionIds[i]).intValue(), tempRegion.arrayListOfConcerns, true);
				allFlags.add(tempFlagInfo);
				tempFlagInfo = new FlagInformation(tempRegion.endPos, ((Integer)regionIds[i]).intValue(), tempRegion.arrayListOfConcerns, false);
				allFlags.add(tempFlagInfo);
			}
			//JOptionPane.showMessageDialog(null, "alert", "alert", JOptionPane.ERROR_MESSAGE); 
			java.util.Collections.sort(allFlags);
			//java.util.Collections.reverse(allFlags);
			int replacedLen = 0;
			for (int i = 0; i < allFlags.size(); i++)
			{
				FlagInformation tempFlagInfo = (FlagInformation)allFlags.get(i);
				int tempReplacedLen = 0;
				//System.out.println(tempFlagInfo.position + "," + tempFlagInfo.ID + "," + tempFlagInfo.listOfConcerns + "," + tempFlagInfo.begFlag);
				if (tempFlagInfo.begFlag)
				{
					for (int j = 0; j < tempFlagInfo.listOfConcerns.size(); j++)
					{
						String concernName = (String)tempFlagInfo.listOfConcerns.get(j);
						tempReplacedLen += 2 + concernName.length();
					}
					//System.out.println("***********"+replacedLen + "*************");
					mainWindow.select("wovenCode", tempFlagInfo.position - replacedLen - tempReplacedLen, tempFlagInfo.position - replacedLen);
					//System.out.println((tempFlagInfo.position - replacedLen) + "," + tempFlagInfo.position);
					mainWindow.replaceSelection("wovenCode", "");
					replacedLen += tempReplacedLen;
					RegionInfo tempRegion = (RegionInfo)regionMap.get(tempFlagInfo.ID);
					tempRegion.begPos -= replacedLen;
				}
				else
				{
					for (int j = 0; j < tempFlagInfo.listOfConcerns.size(); j++)
					{
						String concernName = (String)tempFlagInfo.listOfConcerns.get(j);
						tempReplacedLen += 3 + concernName.length();
					}
					//System.out.println("***********"+replacedLen + "*************");
					mainWindow.select("wovenCode", tempFlagInfo.position - replacedLen + 1, tempFlagInfo.position - replacedLen + tempReplacedLen + 1);
					//System.out.println((tempFlagInfo.position - replacedLen) + "," + tempFlagInfo.position);
					mainWindow.replaceSelection("wovenCode", "");
					RegionInfo tempRegion = (RegionInfo)regionMap.get(tempFlagInfo.ID);
					tempRegion.endPos -= replacedLen;
					replacedLen += tempReplacedLen;
				}
			}
			mainWindow.addCaretListener("wovenCode");
		}
		//Updating RTree
		List indexRef = java.util.Arrays.asList(regionMap.keySet().toArray());
		int tempBegPosition, tempEndPosition, tempID;
		regionTree.initRTree();
		for (int i = 0; i < regionMap.size(); i++)
		{
			int tempIndex = (Integer)indexRef.get(i);
			if (!((RegionInfo)(regionMap.get(tempIndex))).
				arrayListOfConcerns.isEmpty())
			{
				tempBegPosition =
					((RegionInfo)(regionMap.get(tempIndex))).begPos;
				tempEndPosition =
					((RegionInfo)(regionMap.get(tempIndex))).endPos;
				tempID = tempIndex;
				regionTree.addRegionToTree
					(tempBegPosition, tempEndPosition, tempID);
			}
		}
		mainWindow.updateRTree(regionTree.getRTree());
	}

	public void valueChanged()
	{ previewText.setText((String)holeJoinPoints.get(0)); }

	/* Updates the preview pane in accordance with the option selected in the List*/
	public void valueChanged(ListSelectionEvent e)
	{
		if (e.getValueIsAdjusting() == false)
		{
			if (listCaller == 0)	//i.e. call came from rename join points action
			{
				Object[] allRegions = regionMap.keySet().toArray();
				previewText.setText("");
				int temp = list.getSelectedIndex();
				int startPos = ((RegionInfo)
					(regionMap.get((Integer)allRegions[temp]))).begPos;
				int endPos = ((RegionInfo)
					(regionMap.get((Integer)allRegions[temp]))).endPos + 1;
				String tempText = "";		//Text from the preview bar
				String exception = "";
				String[] textAndStatus =
					mainWindow.getPreviewText(startPos, endPos);
				tempText = textAndStatus[0];
				exception = textAndStatus[1];
				//if exception occured then display is normal
				if (exception == "true")
				{
					StyleConstants.setBold(mainWindow.attrs[2], true);
					StyleConstants.setFontSize(mainWindow.attrs[2], 12);
					StyleConstants.setItalic(mainWindow.attrs[2], false);
					try
					{
						previewAbstractDoc.
							insertString(0, tempText, mainWindow.attrs[2]);
					}
					catch (BadLocationException ble)
					{
						System.out.println(ble);
					}
				}
				else	//if exception did not occur, do some formatting to the preview text
				{
					temp = tempText.length();
					StyleConstants.setForeground
						(mainWindow.attrs[0], Color.BLACK);
					int smallTextSize = 10;
					StyleConstants.setFontSize
						(mainWindow.attrs[2], smallTextSize);
					StyleConstants.setBold(mainWindow.attrs[2], false);
					StyleConstants.setItalic(mainWindow.attrs[2], true);
					try
					{
						previewAbstractDoc.insertString(0, "..." +
							tempText.substring(0, 5), mainWindow.attrs[2]);
						StyleConstants.setFontSize(mainWindow.attrs[2], 12);
						StyleConstants.setBold(mainWindow.attrs[2], true);
						StyleConstants.setItalic(mainWindow.attrs[2], false);
						previewAbstractDoc.insertString(
							previewAbstractDoc.getLength(),
							tempText.substring(5, temp - 5),
							mainWindow.attrs[2]);
						StyleConstants.setFontSize
							(mainWindow.attrs[2], smallTextSize);
						StyleConstants.setItalic
							(mainWindow.attrs[2], true);
						StyleConstants.setBold
							(mainWindow.attrs[2], false);
						previewAbstractDoc.insertString
							(previewAbstractDoc.getLength(),
							tempText.substring(temp - 5, temp) +
							"...", mainWindow.attrs[2]);
					}
					catch (BadLocationException ble)
					{
						System.out.println(ble);
					}
				}
			}
			else if (listCaller == 1)	//call came from hole replacement.
			{
				previewText.setText("");
				int temp = list.getSelectedIndex();
				previewText.setText((String)holeJoinPoints.get(temp));
			}
		}
	}

	/* Removes regions which have no concerns associated with them from
	 * regionMap and ConcernMap. Updates RTree accordingly. */
	void cleanUpMapsAndTree()
	{
		/*if (true)
			return;*/
		boolean update = false;
		Object[] concernList = concernMap.keySet().toArray();
		List emptyList = new ArrayList();
		RegionInfo removeRegion = new RegionInfo("{remove}", emptyList, -1, -1);
		int size = regionMap.size();
		Object[] allRegions = regionMap.keySet().toArray();
		for (int i = 0; i < size; i++)
		{
			int tempIndex = (Integer)allRegions[i];
			if (((RegionInfo)regionMap.get(tempIndex)).arrayListOfConcerns.isEmpty())
			{
				update = true;
				regionMap.remove((Integer)allRegions[i]);
				for (int j = 0; j < concernMap.size(); j++)
				{
					if (((ConcernInfo)concernMap.get((String)concernList[j])).
						arrayListOfRegions.contains(tempIndex))
						((ConcernInfo)concernMap.get((String)concernList[j])).
							arrayListOfRegions.remove((Object)tempIndex);
				}
				totalRegions--;
			}
		}
		if (update)
		{
			allRegions = regionMap.keySet().toArray();
			regionTree.initRTree();
			mainWindow.updateRTree(regionTree.getRTree());
			for (int i = 0; i < regionMap.size(); i++)
			{
				//if (!((regionMap)(regionMap.get(i))).concernListForFlags.isEmpty())
				//{
				int tempBegPos = ((RegionInfo)
					(regionMap.get((Integer)allRegions[i]))).begPos;
				int tempEndPos = ((RegionInfo)
					(regionMap.get((Integer)allRegions[i]))).endPos;
				int tempId = (Integer)allRegions[i];
				regionTree.addRegionToTree(tempBegPos, tempEndPos, tempId);
				//}
			}
		}
	}

	/* Updates changes in RTree and regionMap occuring due to key presses made by user */
	synchronized void updateRegions(boolean deletePressed)
	{
		//System.out.println("got called:"+deletePressed);
		if (mainWindow.getCharTyped() == 0)
		{
			mainWindow.setInteger("overRidePosition", 0);
			mainWindow.setInteger("overRidePosition2", 0);
			return;
		}
		String targetWindow;
		if (woven)
			targetWindow = "wovenCode";
		else
			targetWindow = "unWovenBody";
		boolean textHighlighted = false;
		if (mainWindow.getSelectionStart(targetWindow) ==
			mainWindow.getSelectionEnd(targetWindow))
			textHighlighted = false;
		else
			textHighlighted = true;
		int initialPosition = 0, initialPosition2 = 0;
		initialPosition = mainWindow.getStartPosition();
		if (mainWindow.getInteger("overRidePosition") !=
			mainWindow.getInteger("overRidePosition2"))
			textHighlighted = true;
		int i = 0;
		if (mainWindow.getCharTyped() != 0)
		{
			Object[] allRegions = regionMap.keySet().toArray();
			while (i < regionMap.size())
			{
				RegionInfo tempRegionInfo = (RegionInfo)
					(regionMap.get((Integer)allRegions[i]));
				//System.out.print("Processing:");
				//tempflag.displayFlag();
				int initialBegPosition = tempRegionInfo.begPos;
				int initialEndPosition = tempRegionInfo.endPos;
				int finalBegPosition = initialBegPosition;
				int finalEndPosition = finalBegPosition;
				boolean updateRegions = false;
				if (!textHighlighted)
				{
					if (initialBegPosition >= initialPosition)
					{
						if (deletePressed && initialBegPosition == initialPosition)
						{ /* dont update regions */}
						else
						{
							if (mainWindow.getCharTyped() > 0 &&
								getForeGroundColor(targetWindow,
								initialBegPosition) ==
								getForeGroundColor(targetWindow, initialBegPosition
								+ mainWindow.getCharTyped()) &&
								getBackGroundColor(targetWindow,
								initialBegPosition) ==
								getBackGroundColor(targetWindow, initialBegPosition
								+ mainWindow.getCharTyped()) &&
								initialBegPosition == initialPosition)
							{ /* do nothing */}
							else
								((RegionInfo)(regionMap.get((Integer)allRegions[i]))).
									begPos += mainWindow.getCharTyped();
						}
						finalBegPosition = ((RegionInfo)(regionMap.get
							((Integer)allRegions[i]))).begPos;
						updateRegions = true;
					}
					if ((initialEndPosition + 1) >= initialPosition)
					{
						if (deletePressed && (initialEndPosition + 1) ==
							initialPosition)
						{ /* dont update regions */}
						else
						{
							if (mainWindow.getCharTyped() > 0 &&
								getForeGroundColor(targetWindow,
								initialEndPosition) !=
								getForeGroundColor(targetWindow,
								(initialEndPosition + 1)) &&
								getBackGroundColor(targetWindow,
								initialEndPosition) !=
								getBackGroundColor(targetWindow,
								(initialEndPosition + 1)) &&
								(initialEndPosition + 1) == initialPosition)
							{ /*do nothing*/}
							else
								((RegionInfo)(regionMap.
									get((Integer)allRegions[i]))).endPos +=
									mainWindow.getCharTyped();
						}
						finalEndPosition = ((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos;
						updateRegions = true;
					}
				}
				else if (textHighlighted)
				{
					initialPosition = mainWindow.getSelectionStart(targetWindow);
					initialPosition2 = mainWindow.getSelectionEnd(targetWindow);
					if (mainWindow.getInteger("overRidePosition") !=
						mainWindow.getInteger("overRidePosition2"))
					{
						initialPosition =
							mainWindow.getInteger("overRidePosition");
						initialPosition2 =
							mainWindow.getInteger("overRidePosition2");
					}
					if (initialBegPosition > initialPosition &&
						initialBegPosition >= initialPosition2)
					{
						//System.out.println("CASE1");
						((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).begPos -=
							(initialPosition2 - initialPosition);
						((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos -=
							(initialPosition2 - initialPosition);
						finalBegPosition =
							((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).begPos;
						finalEndPosition =
							((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos;
						updateRegions = true;
					}
					else if (initialEndPosition + 1 <= initialPosition &&
						initialEndPosition + 1 <= initialPosition2)
					{ //System.out.println("CASE2");
						updateRegions = false;
					}
					else if (initialBegPosition > initialPosition &&
						initialEndPosition + 1 > initialPosition2)
					{
						//System.out.println("CASE3");
						((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).begPos =
							initialPosition;
						((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos -=
							(initialPosition2 - initialPosition);
						finalBegPosition =
							((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).begPos;
						finalEndPosition =
							((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos;
						updateRegions = true;
					}
					else if (initialBegPosition < initialPosition &&
						initialEndPosition + 1 < initialPosition2)
					{
						//System.out.println("CASE4");
						((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos =
							initialPosition - 1;
						finalEndPosition =
							((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos;
						updateRegions = true;
					}
					else if (initialBegPosition < initialPosition &&
						initialEndPosition + 1 > initialPosition2)
					{
						//System.out.println("CASE5");
						((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos -=
							(initialPosition2 - initialPosition);
						finalEndPosition =
							((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).endPos;
						updateRegions = true;
					}
					else if (initialBegPosition > initialPosition &&
						initialEndPosition + 1 < initialPosition2)
					{	//Remove that region
						//System.out.println("CASE6"); 
						((RegionInfo)
							(regionMap.get((Integer)allRegions[i]))).
							arrayListOfConcerns.clear();
						finalBegPosition = 0;
						finalEndPosition = 0;
						updateRegions = true;
					}
					//cover all equality cases
					else if (initialBegPosition == initialPosition)
					{
						if (initialEndPosition + 1 < initialPosition2)
						{
							//System.out.println("CASE 4b,6c");
							if (mainWindow.getCharTyped() > 0)
							{
								((RegionInfo)
									(regionMap.get((Integer)allRegions[i]))).endPos =
								((RegionInfo)
								(regionMap.get((Integer)allRegions[i]))).begPos +
								mainWindow.getCharTyped() - 1;
								finalEndPosition = ((RegionInfo)
									(regionMap.get((Integer)allRegions[i]))).endPos;
								updateRegions = true;
							}
							else
							{
								((RegionInfo)(regionMap.get((Integer)allRegions[i]))).
									arrayListOfConcerns.clear();
								finalBegPosition = 0;
								finalEndPosition = 0;
								updateRegions = true;
							}
						}
						else if (initialEndPosition + 1 == initialPosition2)
						{
							//System.out.println("CASE3d,4d,5d,6b");
							if (mainWindow.getCharTyped() > 0)
							{
								((RegionInfo)
									(regionMap.get((Integer)allRegions[i]))).endPos =
							   ((RegionInfo)
							   (regionMap.get((Integer)allRegions[i]))).begPos +
							   mainWindow.getCharTyped() - 1;
								finalEndPosition =
									((RegionInfo)
									(regionMap.get((Integer)allRegions[i]))).endPos;
								updateRegions = true;
							}
							else
							{
								((RegionInfo)(regionMap.get((Integer)allRegions[i]))).
									arrayListOfConcerns.clear();
								finalBegPosition = 0;
								finalEndPosition = 0;
								updateRegions = true;
							}
						}
						else if (initialEndPosition + 1 > initialPosition2)
						{
							//System.out.println("CASE3b,5b");
							if (mainWindow.getCharTyped() > 0)
								((RegionInfo)
									(regionMap.get((Integer)allRegions[i]))).endPos +=
									initialBegPosition - initialPosition2 +
									mainWindow.getCharTyped();
							else
								((RegionInfo)
									(regionMap.get((Integer)allRegions[i]))).endPos +=
									initialBegPosition - initialPosition2;
							finalEndPosition =
								((RegionInfo)
								(regionMap.get((Integer)allRegions[i]))).endPos;
							updateRegions = true;
						}
					}
					else if (initialEndPosition + 1 == initialPosition2)
					{
						if (initialBegPosition < initialPosition)
						{
							//System.out.println("CASE4c,5c");
							if (mainWindow.getCharTyped() > 0)
								((RegionInfo)
									(regionMap.get((Integer)allRegions[i]))).endPos =
									initialPosition + mainWindow.getCharTyped() - 1;
							else
								((RegionInfo)
									(regionMap.get((Integer)allRegions[i]))).endPos =
									initialPosition - 1;
							finalEndPosition =
								((RegionInfo)
								(regionMap.get((Integer)allRegions[i]))).endPos;
							updateRegions = true;
						}
						else if (initialBegPosition > initialPosition)
						{
							//System.out.println("CASE3c,6d");
							((RegionInfo)(regionMap.get((Integer)allRegions[i]))).
								arrayListOfConcerns.clear();
							finalBegPosition = 0;
							finalEndPosition = 0;
							updateRegions = true;
						}
					}
					int initialBegPosition2 = finalBegPosition;
					int initialEndPosition2 = finalEndPosition;
					if (mainWindow.getCharTyped() > 0 &&
						initialBegPosition != initialPosition &&
						initialEndPosition + 1 != initialPosition2)
					{
						if (initialBegPosition2 >= initialPosition)
						{
							((RegionInfo)(regionMap.get((Integer)allRegions[i]))).
								begPos += mainWindow.getCharTyped();
							finalBegPosition =
								((RegionInfo)(regionMap.get((Integer)allRegions[i]))).
								begPos;
							updateRegions = true;
						}
						if ((initialEndPosition2 + 1) >= initialPosition)
						{
							((RegionInfo)(regionMap.get((Integer)allRegions[i]))).
								endPos += mainWindow.getCharTyped();
							finalEndPosition = ((RegionInfo)
								(regionMap.get((Integer)allRegions[i]))).endPos;
							updateRegions = true;
						}
					}
				}
				if (updateRegions)
				{
					double[] lowerLimit = new double[2];
					double[] upperLimit = new double[2];
					lowerLimit[0] = initialBegPosition; lowerLimit[1] = 0;
					upperLimit[0] = initialEndPosition; upperLimit[1] = 0;
					IShape tempr = new Region(lowerLimit, upperLimit);
					regionTree.deleteDatafromTree(tempr, i);
					regionTree.addRegionToTree
						(finalBegPosition, finalEndPosition, i);
				}
				i++;
			}
		}
		mainWindow.setInteger("overRidePosition", 0);
		mainWindow.setInteger("overRidePosition2", 0);
	}

	void clearMaps()
	{
		regionMap.clear();
		Object[] concernList = concernMap.keySet().toArray();
		for (int i = 0; i < concernMap.size(); i++)
			((ConcernInfo)concernMap.get
				((String)concernList[i])).arrayListOfRegions.clear();
		regionTree.initRTree();
		mainWindow.updateRTree(regionTree.getRTree());
	}

	/* Remove duplicate elements from a list */
	List removeDuplicates(List inputList)
	{
		int i = 0;
		int inputListSize = inputList.size();
		while (i < inputListSize)
		{
			int j;
			int tempIndex;
			int tempPosition = (Integer)(inputList.get(i));
			int inputListFrequency =
				java.util.Collections.frequency(inputList, tempPosition);
			if (inputListFrequency > 1)
			{
				j = 0;
				while (j < inputListFrequency - 1)
				{
					tempIndex = inputList.indexOf(tempPosition);
					inputListSize--;
					inputList.remove(tempIndex);
					j++;
				}
			}
			i++;
		}
		return inputList;
	}

	/* Finds out whether the cursor position in unwoven concerns is a joinpoint location or not */
	boolean cursorAtJoinpoint(int position)
	{
		mainWindow.removeCaretListener("unWovenConcerns");
		mainWindow.setCaretPosition("unWovenConcerns", position);
		//Find out beginning and end of the concern in which user has clicked
		AttributeSet currentAttributes =
			mainWindow.getCharacterAttributes("unWovenConcerns");
		Enumeration attributeNames = currentAttributes.getAttributeNames();
		Color tempColor = null;
		while (attributeNames.hasMoreElements())
		{
			Object nextAttribute = attributeNames.nextElement();
			String attributeString = nextAttribute.toString();
			if (attributeString.equals("foreground"))
			{
				tempColor =
					(Color)(currentAttributes.getAttribute(nextAttribute));
				break;
			}
		}
		String allUnWovenText = mainWindow.getText("unWovenConcerns", 0,
			mainWindow.getLength("unWovenConcernsAbstractDoc"));
		String find = "concern ";
		int offset = 0;
		int tempIndex = 0;
		while (true)
		{
			tempIndex = allUnWovenText.indexOf(find, offset);
			if (tempIndex < 0)
				break;
			offset = tempIndex + 1;
			mainWindow.setCaretPosition("unWovenConcerns", tempIndex);
			currentAttributes = mainWindow.getCharacterAttributes("unWovenConcerns");
			attributeNames = currentAttributes.getAttributeNames();
			Color foregroundColor = null;
			while (attributeNames.hasMoreElements())
			{
				Object nextAttribute = attributeNames.nextElement();
				String attributeString = nextAttribute.toString();
				if (attributeString.equals("foreground"))
				{
					foregroundColor = (Color)
						(currentAttributes.getAttribute(nextAttribute));
					break;
				}
			}
			if (foregroundColor.equals(tempColor))
				break;
		}
		int tempOffset = position - tempIndex;
		String analyzeText =
			mainWindow.getText("unWovenConcerns", tempIndex, tempOffset);
		//Analysis of Concern text
		int noOfCloseArrows = 0;
		int noOfOpenArrows = 0;
		int noOfAts = 0;
		offset = 0;
		while (true)
		{
			int reqIndex =
				analyzeText.indexOf(globalVariable.CLOSEARROW, offset);
			if (reqIndex < 0)
				break;
			else
				offset = reqIndex + 1;
			noOfCloseArrows++;
		}
		offset = 0;
		while (true)
		{
			int reqIndex = analyzeText.indexOf(globalVariable.OPENARROW, offset);
			if (reqIndex < 0)
				break;
			else
				offset = reqIndex + 1;
			noOfOpenArrows++;
		}
		offset = 0;
		while (true)
		{
			int reqIndex = analyzeText.indexOf("@", offset);
			if (reqIndex < 0)
				break;
			else
				offset = reqIndex + 1;
			noOfAts++;
		}
		if (noOfCloseArrows != noOfAts && noOfCloseArrows == noOfOpenArrows)
		//[no. of @'s] = [no of >>}'s] + 1    => we r looking at a joinpoint
		{
			mainWindow.addCaretListener("unWovenConcerns");
			return true;
		}
		else
		{
			mainWindow.addCaretListener("unWovenConcerns");
			return false;
		}
	}

	/* Checks whether concern names entered by user are in compliance with certain rules */
	boolean checkConcernName(String concernName, String initialName)
	{
		if (concernName.equals(new String("")))
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				   "Cannot have a Blank Name for a Concern", "IVCON",
				   JOptionPane.WARNING_MESSAGE);
			return false;
		}
		if (concernName.contains("}") || concernName.contains("{") ||
			concernName.contains("@") || concernName.contains(" "))
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"Concern names cannot contain \"{\",\"}\",\"@\" or spaces",
				"IVCON", JOptionPane.WARNING_MESSAGE);
			concernName = "";
			return false;
		}
		Object[] allConcerns = concernMap.keySet().toArray();
		List concernNames = new ArrayList();
		for (int i = 0; i < concernMap.size(); i++)
		{
			if (!(((String)allConcerns[i]).equals(initialName)))
				concernNames.add(allConcerns[i]);
		}
		if (concernNames.contains(concernName))
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				   "Concern \"" + concernName + "\" exists already.",
				   "IVCON", JOptionPane.WARNING_MESSAGE);
			return false;
		}
		return true;
	}

	/* Ensures that same colors are not used for different concerns */
	boolean checkConcernColor(Color newColor, Color initialColor)
	{
		List colors = new ArrayList();
		Object[] concernNames = concernMap.keySet().toArray();
		for (int i = 0; i < concernMap.size(); i++)
		{
			Color tempColor =
				((ConcernInfo)concernMap.get((String)concernNames[i])).clr;
			if (!tempColor.equals(initialColor))
				colors.add(tempColor);
		}
		if (colors.contains(newColor))
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				   "This Color is already assigned to a Concern ",
				   "Choose a Different Color...",
				   JOptionPane.WARNING_MESSAGE);
			return false;
		}
		return true;
	}

	/* Checks whether join point names entered by user are in compliance with certain rules */
	boolean checkJoinPointName(String joinPointName, String initialName)
	{
		if (joinPointName.equals(new String("")))
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				   "Cannot have a Blank Name for a Code region", "IVCON",
				   JOptionPane.WARNING_MESSAGE);
			return false;
		}
		if (joinPointName.contains("}") || joinPointName.contains("{") ||
			joinPointName.contains("@") || joinPointName.contains(" "))
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"Code region names cannot contain \"{\",\"}\",\"@\" or spaces",
				"IVCON", JOptionPane.WARNING_MESSAGE);
			joinPointName = "";
			return false;
		}
		List joinPointNames = new ArrayList();
		Object[] allRegions = regionMap.keySet().toArray();
		for (int i = 0; i < regionMap.size(); i++)
		{
			String tempName =
				((RegionInfo)(regionMap.get((Integer)allRegions[i]))).regionName;
			if (!tempName.equals(initialName))
				joinPointNames.add(tempName);
		}
		if (joinPointNames.contains(joinPointName))
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"Code region Name\"" + joinPointName + "\" exists already.",
				   "IVCON", JOptionPane.WARNING_MESSAGE);
			return false;
		}
		return true;
	}

	Color getForeGroundColor(String window)
	{
		AttributeSet currentAttributes =
			mainWindow.getCharacterAttributes(window);
		Enumeration attributeNames =
			currentAttributes.getAttributeNames();
		Color foregroundColor;
		while (attributeNames.hasMoreElements())
		{
			Object nextAttribute = attributeNames.nextElement();
			String attributeString = nextAttribute.toString();
			if (attributeString.equals("foreground"))
			{
				foregroundColor = (Color)
					(currentAttributes.getAttribute(nextAttribute));
				return foregroundColor;
			}
		}
		return null;
	}

	Color getBackGroundColor(String window)
	{
		AttributeSet currentAttributes =
			mainWindow.getCharacterAttributes(window);
		Enumeration attributeNames =
			currentAttributes.getAttributeNames();
		Color backgroundColor;
		while (attributeNames.hasMoreElements())
		{
			Object nextAttribute = attributeNames.nextElement();
			String attributeString = nextAttribute.toString();
			if (attributeString.equals("background"))
			{
				backgroundColor = (Color)
					(currentAttributes.getAttribute(nextAttribute));
				return backgroundColor;
			}
		}
		return null;
	}

	Color getForeGroundColor(String window, int point)
	{
		int startPosition = mainWindow.getSelectionStart(window);
		int endPosition = mainWindow.getSelectionEnd(window);
		String windowDoc = window + "AbstractDoc";
		if (point > mainWindow.getLength(windowDoc))
			return null;
		int intialPosition = mainWindow.getCaretPosition(window);
		mainWindow.removeCaretListener(window);
		mainWindow.setCaretPosition(window, point);
		AttributeSet currentAttributes =
			mainWindow.getCharacterAttributes(window);
		Enumeration attributeNames =
			currentAttributes.getAttributeNames();
		Color foregroundColor;
		while (attributeNames.hasMoreElements())
		{
			Object nextAttribute = attributeNames.nextElement();
			String attributeString = nextAttribute.toString();
			if (attributeString.equals("foreground"))
			{
				foregroundColor = (Color)
					(currentAttributes.getAttribute(nextAttribute));
				if (startPosition == endPosition)
					mainWindow.setCaretPosition(window, intialPosition);
				else
					mainWindow.select(window, startPosition, endPosition);
				mainWindow.addCaretListener(window);
				return foregroundColor;
			}
		}
		if (startPosition == endPosition)
			mainWindow.setCaretPosition(window, intialPosition);
		else
			mainWindow.select(window, startPosition, endPosition);
		mainWindow.addCaretListener(window);
		return null;
	}

	Color getBackGroundColor(String window, int point)
	{
		String windowDoc = window + "AbstractDoc";
		if (point > mainWindow.getLength(windowDoc))
			return null;
		int intialPosition = mainWindow.getCaretPosition(window);
		mainWindow.removeCaretListener(window);
		mainWindow.setCaretPosition(window, point);
		AttributeSet currentAttributes =
			mainWindow.getCharacterAttributes(window);
		Enumeration attributeNames =
			currentAttributes.getAttributeNames();
		Color backgroundColor;
		while (attributeNames.hasMoreElements())
		{
			Object nextAttribute = attributeNames.nextElement();
			String attributeString = nextAttribute.toString();
			if (attributeString.equals("background"))
			{
				backgroundColor = (Color)
					(currentAttributes.getAttribute(nextAttribute));
				mainWindow.setCaretPosition(window, intialPosition);
				mainWindow.addCaretListener(window);
				return backgroundColor;
			}
		}
		mainWindow.setCaretPosition(window, intialPosition);
		mainWindow.addCaretListener(window);
		return null;
	}
}