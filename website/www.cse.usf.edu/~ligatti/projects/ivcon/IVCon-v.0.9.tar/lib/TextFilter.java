/* Text Filter to use on UnWovenBody: Makes all input text by user appear 
 * in BLACK. This ensures that user does not enter any colored text in the 
 * unwoven concerns, which eliminates the possibility of assigning concern 
 * to text in the unwoven view. Also does not let user remove any holes. */
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.Color;

public class TextFilter extends DocumentFilter
{
	GlobalVariables globalVariable;
	Windows mainWindow;
	public void remove(DocumentFilter.FilterBypass filterBypass, int offset,
		int length) throws BadLocationException
	{
		Document doc = filterBypass.getDocument();
		String checkText = doc.getText(offset, length);
		if (checkText.contains(globalVariable.HOLE))
		{
			JOptionPane.showMessageDialog
				(mainWindow.frame, "Cannot remove holes.",
				"Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		filterBypass.remove(offset, length);
	}
	public void insertString(DocumentFilter.FilterBypass filterBypass, int offset,
		String text, AttributeSet attributes) throws BadLocationException
	{
		MutableAttributeSet mutableAttributes = (MutableAttributeSet)attributes;
		StyleConstants.setForeground(mutableAttributes, Color.BLACK);
		StyleConstants.setBackground(mutableAttributes, Color.WHITE);
		filterBypass.insertString(offset, text, mutableAttributes);
	}

	public void replace(DocumentFilter.FilterBypass filterBypass, int offset,
		int length, String text, AttributeSet attributes) 
		throws BadLocationException
	{
		Document doc = filterBypass.getDocument();
		String checkText = doc.getText(offset, length);
		if (text.contains(globalVariable.HOLE))
			/* Do nothing if user tries to enter a HOLE */
			return;
		if (checkText.contains(globalVariable.HOLE))
		{
			JOptionPane.showMessageDialog
				(mainWindow.frame, "Cannot write over holes.",
				"Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		MutableAttributeSet mutableAttributes = (MutableAttributeSet)attributes;
		StyleConstants.setForeground(mutableAttributes, Color.BLACK);
		StyleConstants.setBackground(mutableAttributes, Color.WHITE);
		filterBypass.replace(offset, length, text, mutableAttributes);
	}
}