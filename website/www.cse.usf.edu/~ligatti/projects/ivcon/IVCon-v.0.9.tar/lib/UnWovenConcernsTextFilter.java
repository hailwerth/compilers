/* Text Filter to use on UnWovenConcern: Makes all input text by user appear 
 * in a WHITE background. This ensures that the text typed by the user does 
 * not take the background of any of the flags (in case the text typed by the
 * user is adjacent to any of the flags) */
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.Color;

public class UnWovenConcernsTextFilter extends DocumentFilter
{
	GlobalVariables globalVariable;
	Windows mainWindow;
	public void remove(DocumentFilter.FilterBypass filterBypass, int offset,
		int length) throws BadLocationException
	{
		Document doc = filterBypass.getDocument();
		String checkText = doc.getText(offset, length);
		if (checkText.contains(globalVariable.HOLE))
		{
			JOptionPane.showMessageDialog
				(mainWindow.frame, "Cannot remove holes.",
				"Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		filterBypass.remove(offset, length);
	}
	public void insertString(DocumentFilter.FilterBypass filterBypass, int offset,
		String text, AttributeSet attributes) throws BadLocationException
	{
		MutableAttributeSet mutableAttributes = (MutableAttributeSet)attributes;
		StyleConstants.setBackground(mutableAttributes, Color.WHITE);
		filterBypass.insertString(offset, text, mutableAttributes);
	}

	public void replace(DocumentFilter.FilterBypass filterBypass, int offset,
		int length, String text, AttributeSet attributes) 
		throws BadLocationException
	{
		Document doc = filterBypass.getDocument();
		String checkText = doc.getText(offset, length);
		if (text.contains(globalVariable.HOLE))
			/* Do nothing if user tries to enter a HOLE */
			return;
		MutableAttributeSet mutableAttributes = (MutableAttributeSet)attributes;
		StyleConstants.setBackground(mutableAttributes, Color.WHITE);
		filterBypass.replace(offset, length, text, mutableAttributes);
	}


}