/* FileUtilities.java: Is the center for all file operations for IVCON */

import datastructures.*;
import java.io.*;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import java.util.HashMap;
import java.util.Scanner;

import lexer.*;

import spatialindex.rtree.*;
import spatialindex.spatialindex.*;
import spatialindex.storagemanager.*;

class FileUtilities
{
	/* Variable for communication with other classes */
	ConcernManipulation concMan;
	Windows mainWindow;
	RTreeInterface regionTree;
	void newFile()
	{
		if (mainWindow.getCharTyped() != 0)
		{
			concMan.updateRegions(false);
			mainWindow.setCharTyped(0);
		}
		mainWindow.createContentPane("Untitled");
		// Update the backend
		concMan.setNoOfConcerns(0);
		concMan.setNoOfRegions(0);
		concMan.setMap("concernMap", new HashMap());
		concMan.setMap("regionMap", new HashMap());
		regionTree.initRTree();
		concMan.setMCB(Color.GRAY);
		mainWindow.setInteger("sessionon", 0);
		mainWindow.createPopupMenu();
		ActiveFileInfo currentFile = new ActiveFileInfo(concMan.getMap("concernMap"), concMan.getMap("regionMap"),
										concMan.getNoOfConcerns(), concMan.getNoOfRegions(), 0, regionTree.getRTree(), false,
										concMan.getMCB(), mainWindow.getScrPan(), mainWindow.getSplitUnwoven(), mainWindow.getSplitPreview(),
										mainWindow.getWovenCode(), mainWindow.getLegend(),
										mainWindow.getCurrentConcerns(), mainWindow.getUnwovenBody(),
										mainWindow.getUnwovenConcerns(), mainWindow.getAbstractDocument("wovenCode"),
										mainWindow.getAbstractDocument("concernLegend"),
										mainWindow.getAbstractDocument("currentConcerns"),
										mainWindow.getAbstractDocument("unWovenBody"),
										mainWindow.getAbstractDocument("unWovenConcerns"), null);
		mainWindow.addToActiveFileList((mainWindow.getTotalTabs() - 1), currentFile);
		mainWindow.switchToTab(mainWindow.getTotalTabs() - 1);
	}

	/* Used for opening ordinary files i.e. non .IVC files */
	void openJavaFile(File file)
	{
		char[] theChars = null;
		StyleConstants.setBold(mainWindow.attrs[4], false);
		StyleConstants.setForeground(mainWindow.attrs[4], Color.BLACK);
		StyleConstants.setBackground(mainWindow.attrs[4], Color.WHITE);
		BufferedReader buffReader = null;
		FileReader fileReader = null;
		mainWindow.createContentPane(file.getName());
		try
		{
			fileReader = new FileReader(file);
			int size = (int)file.length();
			theChars = new char[size];

			int count, index = 0;
			while ((count = fileReader.read(theChars, index, size)) > 0)
			{
				size -= count;
				index += count;
			}
			fileReader.close();
			mainWindow.insertText("wovenCodeAbstractDoc",
						new String(theChars) + "\n", -1, 4);
		}
		catch (IOException e) { e.printStackTrace(); }
		concMan.setNoOfConcerns(0);
		concMan.setNoOfRegions(0);
		concMan.setMap("concernMap", new HashMap());
		concMan.setMap("regionMap", new HashMap());
		regionTree.initRTree();
		concMan.setMCB(Color.GRAY);
		mainWindow.createPopupMenu();
		ActiveFileInfo currentFile = new ActiveFileInfo(concMan.getMap("concernMap"), concMan.getMap("regionMap"),
										concMan.getNoOfConcerns(), concMan.getNoOfRegions(), 1, regionTree.getRTree(), false,
										concMan.getMCB(), mainWindow.getScrPan(), mainWindow.getSplitUnwoven(), mainWindow.getSplitPreview(),
										mainWindow.getWovenCode(), mainWindow.getLegend(),
										mainWindow.getCurrentConcerns(), mainWindow.getUnwovenBody(),
										mainWindow.getUnwovenConcerns(), mainWindow.getAbstractDocument("wovenCode"),
										mainWindow.getAbstractDocument("concernLegend"),
										mainWindow.getAbstractDocument("currentConcerns"),
										mainWindow.getAbstractDocument("unWovenBody"),
										mainWindow.getAbstractDocument("unWovenConcerns"), file);
		mainWindow.addToActiveFileList((mainWindow.getTotalTabs() - 1), currentFile);
		mainWindow.switchToTab(mainWindow.getTotalTabs() - 1);
	}

	void openSolution(File proj)
	{
		String fileName = proj.toString();
		FileInputStream fileInputStream = null;
		ArrayList allFiles = new ArrayList();
		ObjectInputStream objectInputStream = null;
		try
		{
			fileInputStream = new FileInputStream(fileName);
			objectInputStream = new ObjectInputStream(fileInputStream);
			allFiles = (ArrayList)objectInputStream.readObject();
			objectInputStream.close();
		}
		catch (FileNotFoundException flne)
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"File \"" + (proj.getName()) + "\" does not exist.",
				"File Not Found", JOptionPane.ERROR_MESSAGE);
			return;
		}
		catch (ClassNotFoundException ex)
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"Not a Valid .prj file!", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		catch (IOException e)
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				e.getMessage(), "I/O Exception", JOptionPane.ERROR_MESSAGE);
			return;
		}
		boolean allExist = true;
		ArrayList notExist = new ArrayList();
		for (int i = 0; i < allFiles.size(); i++)
		{
			File cFile = (File)allFiles.get(i); //cFile = currentFile w.r.t. iteration
			if (!cFile.exists())
			{
				allExist = false;
				notExist.add(cFile);
			}
			//System.out.println(allFiles.get(i));
		}
		if (!allExist)
		{
			String message = "The following file(s) were not found:";
			for (int j = 0; j < notExist.size(); j++)
				message = message.concat("\n" + notExist.get(j));
			message = message.concat("\n\nDo you want to open the file(s) that were found?\n\n");
			int openOrNot = JOptionPane.showConfirmDialog(mainWindow.frame, message , "Attention", JOptionPane.YES_NO_OPTION);
			if (openOrNot != 0)
				return;
		}
		for (int i = 0; i < allFiles.size(); i++)
		{
			File cFile = (File)allFiles.get(i); //cFile = currentFile w.r.t. iteration
			if (cFile.exists())
			{
				fileName = cFile.toString();
				if (fileName.length() < 4 || !fileName.substring(
				fileName.length() - 4).toLowerCase().equals(".ivc"))
					openJavaFile(cFile);
				else
					openIvcFile(cFile);
			}
		}
	}
	void saveJavaFile(String file)
	{
		try
		{
			String temp = mainWindow.getText("wovenCode", 0, mainWindow.
				getLength("wovenCodeAbstractDoc"));
			BufferedWriter out = new BufferedWriter(new FileWriter(file));
			out.write(temp);
			out.close();
		}
		catch (IOException e2)
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				e2.getMessage(), "I/O Exception", JOptionPane.ERROR_MESSAGE);
			return;
		}
	}
	void saveSolution(File file)
	{
		HashMap allFiles = mainWindow.getActiveFileInfo();
		Object[] openFiles = allFiles.keySet().toArray();
		ArrayList fileList = new ArrayList();
		for (int i = 0; i < openFiles.length; i++)
		{
			ActiveFileInfo temp = (ActiveFileInfo)allFiles.get(openFiles[i]);
			File tempFile = temp.file;
			if (tempFile == null)
				continue;
			else
				fileList.add(tempFile);
		}
		FileOutputStream fileOPStream = null;
		ObjectOutputStream ObjOPStream = null;
		String fileName = file.getAbsolutePath();
		if (fileName.length() < 4)
			fileName = fileName + ".prj";
		else if (!fileName.substring(
			fileName.length() - 4).toLowerCase().equals(".prj"))
			fileName = fileName + ".prj";
		try
		{
			fileOPStream = new FileOutputStream(fileName);
			ObjOPStream = new ObjectOutputStream(fileOPStream);
			//Serialize the FileStruct object
			ObjOPStream.writeObject(fileList);
			ObjOPStream.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	/* Used for opening .IVC files */
	void openIvcFile(File file)
	{
		FileStruct openFileStruct;
		String fileName = file.getAbsolutePath();
		if (fileName.substring(fileName.length() - 4).toLowerCase().equals(".prj"))
		{
			openSolution(file);
			return;
		}
		FileInputStream fileInputStream = null;
		ObjectInputStream objectInputStream = null;
		try
		{
			fileInputStream = new FileInputStream(fileName);
			objectInputStream = new ObjectInputStream(fileInputStream);
			openFileStruct = (FileStruct)objectInputStream.readObject();
			objectInputStream.close();
		}
		catch (FileNotFoundException flne)
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"File \"" + (file.getName()) + "\" does not exist.",
				"File Not Found", JOptionPane.ERROR_MESSAGE);
			return;
		}
		catch (ClassNotFoundException ex)
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				"Not a Valid .ivc file!", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		catch (IOException e)
		{
			JOptionPane.showMessageDialog(mainWindow.frame,
				e.getMessage(), "I/O Exception", JOptionPane.ERROR_MESSAGE);
			return;
		}

		mainWindow.createContentPane(file.getName());
		// Insert text and apply display and color settings
		mainWindow.insertText("wovenCodeAbstractDoc",
			openFileStruct.fileText, -1, 0);
		mainWindow.setStyledDocument("wovenCode",
			openFileStruct.wovenCodeAbstractDoc);
		// Update the backend
		concMan.setNoOfConcerns(openFileStruct.noOfConcerns);
		concMan.setNoOfRegions(openFileStruct.totalRegions);
		concMan.setMap("concernMap", openFileStruct.concMap);
		concMan.setMap("regionMap", openFileStruct.regionMap);
		regionTree.setRTree(openFileStruct.regionTree);
		concMan.setMCB(openFileStruct.MCB);
		concMan.setUniqueId();
		//Displays all concerns in the Concern Legend
		concMan.refreshConcernLegend();
		mainWindow.setInteger("sessionon", 1);
		mainWindow.createPopupMenu();
		ActiveFileInfo currentFile = new ActiveFileInfo(concMan.getMap("concernMap"), concMan.getMap("regionMap"),
										concMan.getNoOfConcerns(), concMan.getNoOfRegions(), 1, regionTree.getRTree(), false,
										concMan.getMCB(), mainWindow.getScrPan(), mainWindow.getSplitUnwoven(), mainWindow.getSplitPreview(),
										mainWindow.getWovenCode(), mainWindow.getLegend(),
										mainWindow.getCurrentConcerns(), mainWindow.getUnwovenBody(),
										mainWindow.getUnwovenConcerns(), mainWindow.getAbstractDocument("wovenCode"),
										mainWindow.getAbstractDocument("concernLegend"),
										mainWindow.getAbstractDocument("currentConcerns"),
										mainWindow.getAbstractDocument("unWovenBody"),
										mainWindow.getAbstractDocument("unWovenConcerns"), file);
		mainWindow.addToActiveFileList((mainWindow.getTotalTabs() - 1), currentFile);
		mainWindow.switchToTab(mainWindow.getTotalTabs() - 1);
	}

	/* Used for closing a file or creating a new file.*/
	void close()
	{
		// Start a new window.
		if (mainWindow.getTotalTabs() == 1)
		{
			int response = JOptionPane.showOptionDialog(mainWindow.frame, "This will exit IVCon.",
				"Warning", JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE,
					null, null, null);
			if (response == JOptionPane.CANCEL_OPTION)
				return;
			else
				System.exit(0);
		}
		mainWindow.removeActiveFileInfo(mainWindow.getCurrentTabID());
		mainWindow.cleanActiveFileMap();
		mainWindow.closeCurrentTab();
		/* mainWindow.selectAll("concernLegend");
				mainWindow.setEditable("concernLegend", true);
				mainWindow.replaceSelection("concernLegend", "");
				mainWindow.setEditable("concernLegend", false);
				mainWindow.frame.setTitle("IVCON");
				mainWindow.selectAll("wovenCode");
				mainWindow.replaceSelection("wovenCode", "");
				StyleConstants.setForeground(mainWindow.attrs[4], Color.BLACK);
				StyleConstants.setBackground(mainWindow.attrs[4], Color.WHITE);
				mainWindow.insertText("wovenCodeAbstractDoc", " ", 0, 4);
				mainWindow.selectAll("wovenCode");
				mainWindow.replaceSelection("wovenCode", "");
				mainWindow.selectAll("currentConcerns");
				mainWindow.setEditable("currentConcerns", true);
				mainWindow.replaceSelection("currentConcerns", "");
				mainWindow.setEditable("currentConcerns", false); 
				// Clear the backend
				regionTree.initRTree();
				concMan.clear("concernMap");
				concMan.clear("regionMap");
				concMan.setNoOfConcerns(0);
				concMan.setNoOfRegions(0);
				mainWindow.setInteger("sessionon", 0);
				if (!concMan.getWoven())
				{
					mainWindow.removeTextFilter();
					mainWindow.selectAll("unWovenConcerns");
					mainWindow.replaceSelection("unWovenConcerns", "");
					mainWindow.selectAll("unWovenBody");
					mainWindow.replaceSelection("unWovenBody", "");
					mainWindow.setTextFilter();
					concMan.viewWoven();
					concMan.setWoven(true);
				}*/
	}

	/* For saving new files or saving the current file under a new name */
	String saveAs(String saveDir)
	{
		String returnString = new String(saveDir);
		if (mainWindow.getInteger("typeCount") != 0)
		{
			concMan.updateRegions(false);
			mainWindow.setInteger("typeCount", 0);
		}
		concMan.cleanUpMapsAndTree();
		JFileChooser fileChooser = new JFileChooser(saveDir);
		int returnVal = fileChooser.showSaveDialog(mainWindow.frame);
		boolean revert = false;
		if (returnVal == JFileChooser.APPROVE_OPTION)
		{
			if (concMan.getViewFlags())
			{
				revert = true;
				mainWindow.setViewFlagState(false);
				concMan.viewFlags();
			}
			FileOutputStream fileOPStream = null;
			ObjectOutputStream ObjOPStream = null;
			File file = fileChooser.getSelectedFile();
			String fileName = file.getAbsolutePath();
			if (fileName.length() < 4)
				fileName = fileName + ".ivc";
			else if (!fileName.substring(
				fileName.length() - 4).toLowerCase().equals(".ivc"))
				fileName = fileName + ".ivc";
			try
			{
				int tempPos = mainWindow.getCaretPosition("wovenCode");
				String allText = mainWindow.getText("wovenCode",
					0, mainWindow.getLength("wovenCodeAbstractDoc"));
				fileOPStream = new FileOutputStream(fileName);
				ObjOPStream = new ObjectOutputStream(fileOPStream);
				//Create a FileStruct object from the all the file information you have.
				FileStruct tempfile = new FileStruct(allText,
					concMan.getMap("concernMap"), concMan.getMap("regionMap"),
					concMan.getNoOfConcerns(), concMan.getNoOfRegions(),
					regionTree.getRTree(), mainWindow.getStyledDocument(
					"wovenCodeStyledDoc"), concMan.getMCB());
				//Serialize the FileStruct object
				ObjOPStream.writeObject(tempfile);
				ObjOPStream.close();
				mainWindow.setCaretPosition("wovenCode", tempPos);
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
			if (revert)
			{
				mainWindow.setViewFlagState(true);
				concMan.viewFlags();
			}
			mainWindow.setInteger("sessionon", 1);
			concMan.setOpenFile(file);
			mainWindow.renameCurrentTab(fileChooser.getName(file));
			returnString = file.toString();
		}
		return returnString;
	}

	/* Saves a file the user is working on currently. Invokes saveAs()
	 * if user is working on a file that has not been saved earlier*/
	String save(String saveDir)
	{
		String returnString = saveDir;
		boolean revert = false;
		if (mainWindow.getInteger("typeCount") != 0)
		{
			concMan.updateRegions(false);
			mainWindow.setInteger("typeCount", 0);
		}
		if (mainWindow.getInteger("sessionon") == 1)	//i.e. if current file has already been saved earlier
		{
			if (concMan.getViewFlags())
			{
				revert = true;
				mainWindow.setViewFlagState(false);
				concMan.viewFlags();
			}
			concMan.cleanUpMapsAndTree();
			File file = concMan.getOpenFile();
			FileOutputStream fileOPStream = null;
			ObjectOutputStream objOPStream = null;
			String filename = file.getAbsolutePath();
			try
			{
				int tempPos = mainWindow.getCaretPosition("wovenCode");
				mainWindow.selectAll("wovenCode");
				String allText = mainWindow.getSelectedText("wovenCode");
				fileOPStream = new FileOutputStream(filename);
				objOPStream = new ObjectOutputStream(fileOPStream);
				//Create a FileStruct object from the all the file information you have.
				FileStruct tempfile = new FileStruct(allText,
					concMan.getMap("concernMap"), concMan.getMap("regionMap"),
					concMan.getMap("concernMap").size(), concMan.getMap("regionMap").size(),
					regionTree.getRTree(), mainWindow.getStyledDocument(
					"wovenCodeStyledDoc"), concMan.getMCB());
				//Serialize the FileStruct object
				objOPStream.writeObject(tempfile);
				objOPStream.close();
				mainWindow.setCaretPosition("wovenCode", tempPos);
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
			if (revert)
			{
				mainWindow.setViewFlagState(true);
				concMan.viewFlags();
			}
			mainWindow.setInteger("sessionon", 1);
		}
		//if current file hasn't been saved earlier then prompt user to provide a name through Save as...
		else
			returnString = saveAs(saveDir);
		return returnString;
	}
}

