/* Windows.java: Takes care of all the Window Operations */

import texttransfer.*;
import datastructures.*;
import java.io.*;

import java.awt.*;
import java.awt.Point;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.basic.BasicToolTipUI;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import java.util.HashMap;
import lexer.*;

import spatialindex.rtree.*;
import spatialindex.spatialindex.*;
import spatialindex.storagemanager.*;

class Windows implements ActionListener, KeyListener, FocusListener, CaretListener, ChangeListener, MouseMotionListener
{
	final static int NOOFATTRIBUTES = 8;
	final static Border BORDER = BorderFactory.createEtchedBorder();
	final static TextFilter UNWOVENBODYFILTER = new TextFilter();
	final static UnWovenConcernsTextFilter UNWOVENCONCERNSFILTER =
		new UnWovenConcernsTextFilter();
	static String CLASSPATH = "";
	static String MAINCLASS = "";
	static String OUTPUTDIR = "";
	static String SAVEDIR = "";
	static String OPENDIR = "";
	static String findText = new String("");
	static int previewLength = 5;

	private boolean isUwcEditable = true;	//uwc=UnWovenConcerns
	private boolean isWindowEditable = true;    //wc=WovenCode
	private boolean isHoleInSelection = false;
	private ArrayList cacp = new ArrayList(); //cacp = concerns at current position

	/* Popuplistener and Popup menu */
	JPopupMenu popup = new JPopupMenu();
	MouseListener popupListener = new PopupListener(popup);

	/* Variables for keyboard listener */
	int lastCaretPosition = 0;
	private boolean isBkspace = false;
	private int overRidePosition = 0, overRidePosition2 = 0;
	private int typeCount = 0;
	private RegionUpdater regionUpdater = new RegionUpdater();
	TextTransfer textTransfer = new TextTransfer();

	/* Temporary Map for Managing Multiple Files */
	private HashMap ActiveFileInfo = new HashMap();

	/* Variables changing with user operations */
	private int row, col;
	private int sema = 0;
	private int sessionon = 0;			// 0 if current file has not been saved earlier; 1 otherwise
	private int currentNoOfRegions = 0;	//No. of regions associated at the cursor location

	/* Dynamically (in terms of enabled/disabled) changing menuItems */
	private JMenuItem assignToConcernMenuItem, wovenFormMenuItem, save, saveAs;
	private JMenuItem unWovenFormMenuItem, addAConcernMenuItem, editConcern;
	private JMenuItem renameJoinPointMenuItem, export, jumpToConcern, compile;
	private JMenuItem weaveAllMenuItem, unweaveAllMenuItem;
	private JMenu submenuRemove;
	private JCheckBoxMenuItem viewFlags;

	/* Public variables */
	JFrame frame;
	SimpleAttributeSet[] attrs;

	/* Windows and their components */
	private JTextPane concernLegend, currentConcerns, unWovenBody;
	private JTextPane unWovenConcerns, wovenCode;
	private AbstractDocument wovenCodeAbstractDoc, concernLegendAbstractDoc;
	private AbstractDocument currentConcernsAbstractDoc, unWovenBodyAbstractDoc;
	private AbstractDocument unWovenConcernsAbstractDoc;
	private JScrollPane scrollPane, scrollPane2, scrollPane3, scrollUWBody;
	private JScrollPane scrollUWConcerns, scrPan;
	private JSplitPane splitPane, splitfirst, splitUnwoven, splitPreview;
	private StyledDocument concernLegendStyledDoc, currentConcernsStyledDoc;
	private StyledDocument unWovenBodyStyledDoc, unWovenConcernsStyledDoc;
	private StyledDocument wovenCodeStyledDoc;
	private JLabel statusBar;
	private JTabbedPane tabbedPane = new JTabbedPane();

	/* Variable for communication with other classes */
	ConcernManipulation concMan;
	FileUtilities fileMan;
	RTreeInterface regionTree;
	GlobalVariables globalVariable;


	/* Returns text for the preview window when renaming regions.
	 * Also tells whether an exception occured or not */
	public String[] getPreviewText(int startPosition, int endPosition)
	{
		String tempText = "<Error in Preview>";
		String exception = "false";
		try
		{
			tempText = wovenCode.getText(startPosition - previewLength,
				endPosition + previewLength - (startPosition - previewLength));
		}
		catch (BadLocationException ble)
		{
			exception = "true";
			try
			{
				tempText = wovenCode.getText(startPosition,
					(endPosition - startPosition));
			}
			catch (BadLocationException ble1)
			{
				// This exception is expected in some cases so we don't report it.
			}
		}
		String[] result ={ tempText, exception };
		return result;
	}

	void clearWindow(JTextPane window, AbstractDocument windowDoc)
	{
		window.selectAll();
		window.replaceSelection("");
		StyleConstants.setForeground(attrs[4], Color.BLACK);
		StyleConstants.setBackground(attrs[4], Color.WHITE);
		try
		{
			windowDoc.insertString(0, " ", attrs[4]);
		}
		catch (BadLocationException ble) { ble.printStackTrace(); }

		window.selectAll();
		window.replaceSelection("");
	}

	/* Gives focus to the window specified by the calling object */
	public void requestFocus(String window, boolean state)
	{
		if (window == "unWovenBody") unWovenBody.requestFocus(state);
	}
	public int viewToModel(String window, java.awt.Point position)
	{
		if (window == "unWovenConcerns")
			return unWovenConcerns.viewToModel(position);
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get position in window." +
				window + ": NOT DEFINED.");
			return -1;
		}
	}

	/* Returns coordinates of the given position for the window specified 
	 * by the calling object */
	public Rectangle modelToView(String window, int position)
	{
		try
		{
			if (window == "unWovenConcerns")
				return unWovenConcerns.modelToView(position);
			else
			{
				System.out.println("INTERNAL ERROR: Cannot get position in window." +
					window + ": NOT DEFINED.");
				return null;
			}
		}
		catch (BadLocationException ble)
		{
			ble.printStackTrace();
		}
		return null;
	}

	/* Returns state of the boolean variable specified by the calling object */
	public boolean getState(String varName)
	{
		if (varName == "isBkspace")
			return isBkspace;
		else if (varName == "isUwcEditable")
			return isUwcEditable;
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get variable." +
				varName + ": NOT DEFINED.");
			return false;
		}
	}

	/* Sets divider location for the split pane specified by the calling object */
	public void setDividerLocation(String splitPaneName, double value)
	{
		if (splitPaneName == "splitPreview")
			splitPreview.setDividerLocation(value);
	}

	/* Enables/Disables the component specified by the calling object */
	public void setEnabled(String component, boolean state)
	{
		if (component == "assignToConcernMenuItem")
			assignToConcernMenuItem.setEnabled(state);
		else if (component == "editConcern")
			editConcern.setEnabled(state);
		else if (component == "wovenFormMenuItem")
			wovenFormMenuItem.setEnabled(state);
		else if (component == "unWovenFormMenuItem")
			unWovenFormMenuItem.setEnabled(state);
		else if (component == "addAConcernMenuItem")
			addAConcernMenuItem.setEnabled(state);
		else if (component == "renameJoinPointMenuItem")
			renameJoinPointMenuItem.setEnabled(state);
		else if (component == "export")
			export.setEnabled(state);
		else if (component == "submenuRemove")
			submenuRemove.setEnabled(state);
		else if (component == "save")
			save.setEnabled(state);
		else if (component == "saveAs")
			saveAs.setEnabled(state);
		else if (component == "jumpToConcern")
			jumpToConcern.setEnabled(state);
		else if (component == "compile")
			compile.setEnabled(state);
		else
		{
			System.out.println("INTERNAL ERROR: Cannot set enabled to component." +
				component + ": NOT DEFINED.");
		}
	}

	/* Sets the value of the integer specified by the calling object */
	public void setInteger(String intName, int value)
	{
		if (intName == "overRidePosition")
			overRidePosition = value;
		else if (intName == "overRidePosition2")
			overRidePosition2 = value;
		else if (intName == "sessionon")
			sessionon = value;
		else if (intName == "currentNoOfRegions")
			currentNoOfRegions = value;
		else if (intName == "typeCount")
			typeCount = value;
		else
		{
			System.out.println("INTERNAL ERROR: Cannot set value of interger." +
				intName + ":NOT DEFINED.");
		}
	}

	/* Returns value of the integer specified by the calling object */
	public int getInteger(String intName)
	{
		if (intName == "overRidePosition")
			return overRidePosition;
		else if (intName == "overRidePosition2")
			return overRidePosition2;
		else if (intName == "typeCount")
			return typeCount;
		else if (intName == "sessionon")
			return sessionon;
		else if (intName == "currentNoOfRegions")
			return currentNoOfRegions;
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get value of integer." +
				intName + ":NOT DEFINED.");
			return -1;
		}
	}

	/* Inserts text in the window specified by the calling object
	 * at the position given. A negative position value implies
	 * that text is to inserted at the end of the TextPane*/
	public void insertText(String window, String text, int position, int attribId)
	{
		try
		{
			if (window == "wovenCodeAbstractDoc")
			{
				if (position < 0)
					wovenCodeAbstractDoc.insertString(
						wovenCodeAbstractDoc.getLength(), text, attrs[attribId]);
				else
					wovenCodeAbstractDoc.insertString(position, text,
						attrs[attribId]);
			}
			else if (window == "concernLegendAbstractDoc")
			{
				if (position < 0)
					concernLegendAbstractDoc.insertString(
						concernLegendAbstractDoc.getLength(), text, attrs[attribId]);
				else
					concernLegendAbstractDoc.insertString(position,
						text, attrs[attribId]);
			}
			else if (window == "currentConcernsAbstractDoc")
			{
				if (position < 0)
					currentConcernsAbstractDoc.insertString(
						currentConcernsAbstractDoc.getLength(), text, attrs[attribId]);
				else
					currentConcernsAbstractDoc.insertString(position,
						text, attrs[attribId]);
			}
			else if (window == "unWovenBodyAbstractDoc")
			{
				if (position < 0)
					unWovenBodyAbstractDoc.insertString(
						unWovenBodyAbstractDoc.getLength(), text, attrs[attribId]);
				else
					unWovenBodyAbstractDoc.insertString(position,
						text, attrs[attribId]);
			}
			else if (window == "unWovenConcernsAbstractDoc")
			{
				if (position < 0)
					unWovenConcernsAbstractDoc.insertString(
						unWovenConcernsAbstractDoc.getLength(), text, attrs[attribId]);
				else
					unWovenConcernsAbstractDoc.insertString(position,
						text, attrs[attribId]);
			}
			else
				System.out.println("INTERNAL ERROR: Cannot append to Window." +
					window + ":NOT DEFINED.");
		}
		catch (BadLocationException ble)
		{
			ble.printStackTrace();
		}
	}

	/* Selects all the text in the window specified by the calling object */
	public void selectAll(String window)
	{
		if (window == "wovenCode")
			wovenCode.selectAll();
		else if (window == "concernLegend")
			concernLegend.selectAll();
		else if (window == "unWovenBody")
			unWovenBody.selectAll();
		else if (window == "currentConcerns")
			currentConcerns.selectAll();
		else if (window == "unWovenConcerns")
			unWovenConcerns.selectAll();
		else
			System.out.println("INTERNAL ERROR: Cannot select all in to Window." +
				window + ": NOT DEFINED.");
	}

	/* Sets window specified by the calling object as editable or uneditable*/
	public void setEditable(String window, boolean state)
	{
		if (window == "wovenCode")
			wovenCode.setEditable(state);
		else if (window == "concernLegend")
			concernLegend.setEditable(state);
		else if (window == "currentConcerns")
			currentConcerns.setEditable(state);
		else if (window == "unWovenConcerns")
			unWovenConcerns.setEditable(state);
		else
			System.out.println("INTERNAL ERROR: Cannot set editable to Window." +
				window + ": NOT DEFINED.");
	}

	/* Adds the caret listener to the window specified by the calling object */
	public void addCaretListener(String window)
	{
		if (window == "wovenCode")
			wovenCode.addCaretListener(this);
		else if (window == "unWovenConcerns")
			unWovenConcerns.addCaretListener(this);
		else if (window == "unWovenBody")
			unWovenBody.addCaretListener(this);
		else
			System.out.println("INTERNAL ERROR: Cannot add Caret Listener to " +
				"Window." + window + ": NOT DEFINED.");
	}

	/* Removes caret listener from the window specified by the calling object */
	public void removeCaretListener(String window)
	{
		if (window == "wovenCode")
			wovenCode.removeCaretListener(this);
		else if (window == "unWovenConcerns")
			unWovenConcerns.removeCaretListener(this);
		else if (window == "unWovenBody")
			unWovenBody.removeCaretListener(this);
		else
			System.out.println("INTERNAL ERROR: Cannot remove Caret Listener " +
				"from Window." + window + ": NOT DEFINED.");
	}

	/* Adds the key listener to the window specified by the calling object */
	public void addKeyListener(String window)
	{
		if (window == "wovenCode")
			wovenCode.addKeyListener(this);
		else if (window == "unWovenConcerns")
			unWovenConcerns.addKeyListener(this);
		else if (window == "unWovenBody")
			unWovenBody.addKeyListener(this);
		else
			System.out.println("INTERNAL ERROR: Cannot add Key Listener to " +
				"Window." + window + ": NOT DEFINED.");
	}

	/* Removes the key listener to the window specified by the calling object */
	public void removeKeyListener(String window)
	{
		if (window == "wovenCode")
			wovenCode.removeKeyListener(this);
		else if (window == "unWovenConcerns")
			unWovenConcerns.removeKeyListener(this);
		else if (window == "unWovenBody")
			unWovenBody.removeKeyListener(this);
		else
			System.out.println("INTERNAL ERROR: Cannot remove Key Listener " +
				"from Window." + window + ": NOT DEFINED.");
	}

	/* Gets length of the window specified by the calling object */
	public int getLength(String window)
	{
		if (window.equals("wovenCodeAbstractDoc"))
			return wovenCodeAbstractDoc.getLength();
		else if (window.equals("concernLegendAbstractDoc"))
			return concernLegendAbstractDoc.getLength();
		else if (window.equals("currentConcernsAbstractDoc"))
			return currentConcernsAbstractDoc.getLength();
		else if (window.equals("unWovenBodyAbstractDoc"))
			return unWovenBodyAbstractDoc.getLength();
		else if (window.equals("unWovenConcernsAbstractDoc"))
			return unWovenConcernsAbstractDoc.getLength();
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get length of Window. " +
				window + ":NOT DEFINED.");
			return -1;
		}
	}

	/* Gets text from the mentioned positions in the window specified 
	 * by the calling object */
	public String getText(String window, int sPos, int ePos)
	{
		String result = "";
		try
		{
			if (window == "wovenCode")
				result = wovenCode.getText(sPos, ePos);
			else if (window == "unWovenBody")
				result = unWovenBody.getText(sPos, ePos);
			else if (window == "unWovenConcerns")
				result = unWovenConcerns.getText(sPos, ePos);
			else if (window == "concernLegend")
				result = concernLegend.getText(sPos, ePos);
			else
			{
				System.out.println("INTERNAL ERROR: Cannot get text from Window." +
					window + ":NOT DEFINED.");
				result = null;
			}
		}
		catch (BadLocationException ble)
		{
			ble.printStackTrace();
		}
		return result;
	}

	/* Sets the text given in the window specified by the calling object */
	public void setText(String window, String text)
	{
		if (window == "wovenCode")
			wovenCode.setText(text);
		else if (window == "unWovenBody")
			unWovenBody.setText(text);
		else if (window == "unWovenConcerns")
			unWovenConcerns.setText(text);
		else if (window == "statusBar")
			statusBar.setText(text);
		else
			System.out.println("INTERNAL ERROR: Cannot set text in Window." +
				window + ":NOT DEFINED.");
	}

	/* Selects text in range given from the window specified by the calling object */
	public void select(String window, int sPos, int ePos)
	{
		if (window == "wovenCode")
			wovenCode.select(sPos, ePos);
		else if (window == "unWovenBody")
			unWovenBody.select(sPos, ePos);
		else if (window == "unWovenConcerns")
			unWovenConcerns.select(sPos, ePos);
		else
			System.out.println("INTERNAL ERROR: Cannot select text in Window." +
				window + ":NOT DEFINED.");
	}

	/* Replaces selection in the specified by the calling object */
	public void replaceSelection(String window, String text)
	{
		if (window == "wovenCode")
			wovenCode.replaceSelection(text);
		else if (window == "concernLegend")
			concernLegend.replaceSelection(text);
		else if (window == "currentConcerns")
			currentConcerns.replaceSelection(text);
		else if (window == "unWovenBody")
			unWovenBody.replaceSelection(text);
		else if (window == "unWovenConcerns")
			unWovenConcerns.replaceSelection(text);
	}

	/* Sets the caret position in the window specified by the calling object */
	public void setCaretPosition(String window, int position)
	{
		if (window == "wovenCode")
			wovenCode.setCaretPosition(position);
		else if (window == "unWovenConcerns")
			unWovenConcerns.setCaretPosition(position);
		else if (window == "unWovenBody")
			unWovenBody.setCaretPosition(position);
		else
			System.out.println("INTERNAL ERROR: Cannot set Caret Positon in " +
				"Window." + window + ": NOT DEFINED.");
	}

	/* Gets the caret position from the window specified by the calling object */
	public int getCaretPosition(String window)
	{
		if (window == "wovenCode")
			return wovenCode.getCaretPosition();
		else if (window == "unWovenConcerns")
			return unWovenConcerns.getCaretPosition();
		else if (window == "unWovenBody")
			return unWovenBody.getCaretPosition();
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get Caret Positon " +
				"in Window." + window + ": NOT DEFINED.");
			return -1;
		}
	}

	/*Gets the start of selection from the window specified by the calling object */
	public int getSelectionStart(String window)
	{
		if (window == "wovenCode")
			return wovenCode.getSelectionStart();
		else if (window == "unWovenBody")
			return unWovenBody.getSelectionStart();
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get Selection Start " +
				"from Window." + window + ": NOT DEFINED.");
			return -1;
		}
	}

	/*Gets the end of selction from the window specified by the calling object */
	public int getSelectionEnd(String window)
	{
		if (window == "wovenCode")
			return wovenCode.getSelectionEnd();
		else if (window == "unWovenBody")
			return unWovenBody.getSelectionEnd();
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get Selection End " +
				"from Window." + window + ": NOT DEFINED.");
			return -1;
		}
	}

	/*Gets the selected text from the window specified by the calling object */
	public String getSelectedText(String window)
	{
		if (window == "wovenCode")
			return wovenCode.getSelectedText();
		else if (window == "unWovenConcerns")
			return unWovenConcerns.getSelectedText();
		else if (window == "unWovenBody")
			return unWovenBody.getSelectedText();
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get Selected " +
				"Text from Window." + window + ": NOT DEFINED.");
			return null;
		}
	}

	public AttributeSet getParagraphAttributes(String window)
	{
		return unWovenConcerns.getParagraphAttributes();
	}
	/*Gets the text attributes at the current character position from the window 
	 * specified by the calling object */
	public AttributeSet getCharacterAttributes(String window)
	{
		if (window == "wovenCode")
			return wovenCode.getCharacterAttributes();
		else if (window == "unWovenConcerns")
			return unWovenConcerns.getCharacterAttributes();
		else if (window == "unWovenBody")
			return unWovenBody.getCharacterAttributes();
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get Character " +
				"Attributes from Window." + window + ": NOT DEFINED.");
			return null;
		}
	}

	/* Sets the given styleddocument to the window specified by the calling object */
	public void setStyledDocument(String window, StyledDocument style)
	{
		if (window == "wovenCode")
		{
			wovenCodeStyledDoc = style;
			wovenCode.setStyledDocument(wovenCodeStyledDoc);
			if (wovenCodeStyledDoc instanceof AbstractDocument)
				wovenCodeAbstractDoc = (AbstractDocument)wovenCodeStyledDoc;
			else
			{
				System.err.println("Text pane's document isn't an AbstractDocument!");
				System.exit(-1);
			}
		}
		else
			System.out.println("INTERNAL ERROR: Cannot set style to Window." +
				window + ": NOT DEFINED.");
	}

	/* Gets the styleddocument of the window specified by the calling object */
	public StyledDocument getStyledDocument(String document)
	{
		if (document == "wovenCodeStyledDoc")
			return wovenCodeStyledDoc;
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get Styled Document." +
				document + ": NOT DEFINED.");
			return null;
		}
	}

	/* Returns the AbstractDocument of the specified window */
	public AbstractDocument getAbstractDocument(String document)
	{
		if (document == "wovenCode")
			return wovenCodeAbstractDoc;
		else if (document == "concernLegend")
			return concernLegendAbstractDoc;
		else if (document == "currentConcerns")
			return currentConcernsAbstractDoc;
		else if (document == "unWovenBody")
			return unWovenBodyAbstractDoc;
		else if (document == "unWovenConcerns")
			return unWovenConcernsAbstractDoc;
		else
		{
			System.out.println("INTERNAL ERROR: Cannot get Styled Document." +
				document + ": NOT DEFINED.");
			return null;
		}
	}

	/* Makes the window specified by the calling object visible or not visible */
	public void setVisible(String componentName, boolean state)
	{
		if (componentName == "scrPan")
			scrPan.setVisible(state);
		else if (componentName == "splitUnwoven")
			splitUnwoven.setVisible(state);
		else
			System.out.println("INTERNAL ERROR: Cannot set Visible component." +
				componentName + ": NOT DEFINED.");
	}

	void setTabSize()
	{
		// Create one of each type of tab stop
		java.util.List list = new ArrayList();

		//Create Tab Stops at a distance of 20 pixels from each other.
		for (int i = 0; i < 750; i++)
		{
			float pos = 20 * (i + 1);
			int align = TabStop.ALIGN_LEFT;
			int leader = TabStop.LEAD_NONE;
			TabStop tstop = new TabStop(pos, align, leader);
			list.add(tstop);
		}
		// Create a tab set from the tab stops
		TabStop[] tstops = (TabStop[])list.toArray(new TabStop[0]);
		TabSet tabs = new TabSet(tstops);

		// Add the tab set to the logical style;
		// the logical style is inherited by all paragraphs
		Style style = wovenCode.getLogicalStyle();
		Style style2 = unWovenBody.getLogicalStyle();
		Style style3 = unWovenConcerns.getLogicalStyle();
		StyleConstants.setTabSet(style, tabs);
		StyleConstants.setTabSet(style2, tabs);
		StyleConstants.setTabSet(style3, tabs);
		wovenCode.setLogicalStyle(style);
		unWovenBody.setLogicalStyle(style2);
		unWovenConcerns.setLogicalStyle(style3);
	}

	/* Sets a left margin in the text in specified regions in unwoven concerns */
	void setMargin(int startPos, int endPos)
	{
		StyleContext sc = new StyleContext();
		final int MARGINSIZE = 40;
		// Create and add the main document style
		Style defaultStyle = sc.getStyle(StyleContext.DEFAULT_STYLE);
		final Style mainStyle = sc.addStyle("MainStyle", defaultStyle);
		StyleConstants.setLeftIndent(mainStyle, MARGINSIZE);
		StyleConstants.setRightIndent(mainStyle, MARGINSIZE);
		StyleConstants.setFirstLineIndent(mainStyle, 0);
		StyleConstants.setFontFamily(mainStyle, "sans serif");
		StyleConstants.setFontSize(mainStyle, 12);

		// Create and add the heading style
		final Style heading2Style = sc.addStyle("Heading2", null);
		StyleConstants.setFontSize(heading2Style, 12);
		StyleConstants.setFontFamily(heading2Style, "sans serif");
		StyleConstants.setLeftIndent(heading2Style, 8);
		StyleConstants.setFirstLineIndent(heading2Style, 0);
		unWovenConcernsStyledDoc.setLogicalStyle(startPos, mainStyle);
		try
		{
			String indentString =
				unWovenConcernsStyledDoc.getText(startPos, endPos - startPos);
			int removedChar = 0;
			while (indentString.contains(globalVariable.NEWLINE))
			{
				int indexNewLine = indentString.indexOf(globalVariable.NEWLINE);
				removedChar += indexNewLine + 1;
				if (indexNewLine == endPos)
					break;
				indentString = indentString.substring(indexNewLine + 1);
				unWovenConcernsStyledDoc.setLogicalStyle
					(startPos + removedChar, mainStyle);
			}
		}
		catch (BadLocationException ble)
		{
			ble.printStackTrace();
		}
	}

	/* Gets the value of the startPosition in regionUpdater */
	int getStartPosition()
	{ return regionUpdater.startPosition; }

	/* Gets the value of charTyped in regionUpdater */
	int getCharTyped()
	{ return regionUpdater.charTyped; }

	/* Sets the value of charTyped in regionUpdater */
	void setCharTyped(int typedChars)
	{ regionUpdater.charTyped = typedChars; }

	/* Sets the text filter on unwoven body window */
	public void setTextFilter()
	{ unWovenBodyAbstractDoc.setDocumentFilter(UNWOVENBODYFILTER); }

	/* Removes the text filter from unwoven body window */
	public void removeTextFilter()
	{ unWovenBodyAbstractDoc.setDocumentFilter(null); }

	/* Sets a text filter on unwoven concerns window */
	public void setTextFilter2()
	{ unWovenConcernsAbstractDoc.setDocumentFilter(UNWOVENCONCERNSFILTER); }

	/* Removes the text filter from unwoven concerns window*/
	public void removeTextFilter2()
	{ unWovenConcernsAbstractDoc.setDocumentFilter(null); }

	/* Returns the woven code panel */
	public JTextPane getWovenCode()
	{ return wovenCode; }

	/* Returns the concerns legend panel*/
	public JTextPane getLegend()
	{ return concernLegend; }

	/* Returns the concerns-at-current-position panel */
	public JTextPane getCurrentConcerns()
	{ return currentConcerns; }

	/* Returns the unwoven body panel */
	public JTextPane getUnwovenBody()
	{ return unWovenBody; }

	/* Returns the unwoven concerns panel */
	public JTextPane getUnwovenConcerns()
	{ return unWovenConcerns; }

	/* Returns the splitUnwoven panel */
	public JSplitPane getSplitUnwoven()
	{ return splitUnwoven; }

	/* Returns the splitPreview panel */
	public JSplitPane getSplitPreview()
	{ return splitPreview; }

	/* Returns the scrPan panel */
	public JScrollPane getScrPan()
	{ return scrPan; }

	/* Get state of the view flags menu item */
	boolean getViewFlagState()
	{ return viewFlags.getState(); }

	void setViewFlagState(boolean state)
	{ viewFlags.setState(state); }

	/* Add to the ActiveFileInfo HashMap */
	void addToActiveFileList(int id, ActiveFileInfo fileInfo)
	{ ActiveFileInfo.put(id, fileInfo); }

	/* Updates the RTree of the current Active File */
	void updateRTree(RTree rTree)
	{
		int i = tabbedPane.getSelectedIndex();
		ActiveFileInfo tempInfo = (ActiveFileInfo)(ActiveFileInfo.get(i));
		tempInfo.updateRTree(rTree);
		ActiveFileInfo.remove(i);
		ActiveFileInfo.put(i, tempInfo);
	}

	/* Updates the ViewFlag state of the current Active File */
	void updateViewFlagState(boolean state)
	{
		int i = tabbedPane.getSelectedIndex();
		ActiveFileInfo tempInfo = (ActiveFileInfo)(ActiveFileInfo.get(i));
		tempInfo.updateViewFlagState(state);
		ActiveFileInfo.remove(i);
		ActiveFileInfo.put(i, tempInfo);
	}

	/* Updates the Tool-tip Text */
	void setToolTipText(String text)
	{ wovenCode.setToolTipText(text); }

	/* Closes the current Tab*/
	void closeCurrentTab()
	{ tabbedPane.removeTabAt(tabbedPane.getSelectedIndex()); }

	/* Closes the specified Tab */
	void closeTab(int index)
	{ tabbedPane.removeTabAt(index); }

	/* Return the total number of tabs */
	int getTotalTabs()
	{ return tabbedPane.getTabCount(); }

	/* Return the tab ID of the current Panel*/
	int getCurrentTabID()
	{ return tabbedPane.getSelectedIndex(); }

	/* Switches to the specified Tab */
	void switchToTab(int tabNum)
	{ tabbedPane.setSelectedIndex(tabNum); }

	/*Renames the currently open tab */
	void renameCurrentTab(String newName)
	{ tabbedPane.setTitleAt(tabbedPane.getSelectedIndex(), newName); }

	/* Removes the specified entry from the ActiveFileInfo map */
	void removeActiveFileInfo(int index)
	{ ActiveFileInfo.remove(index); }

	/* Rearranges the keys of the ActiveFileInfo Map */
	void cleanActiveFileMap()
	{
		Object[] fileIndices = ActiveFileInfo.keySet().toArray();
		ArrayList tempFileInfos = new ArrayList();
		int numberOfTabs = ActiveFileInfo.size();
		for (int i = 0; i < numberOfTabs; i++)
		{
			tempFileInfos.add(ActiveFileInfo.get((Integer)(fileIndices[i])));
		}
		ActiveFileInfo.clear();
		for (int i = 0; i < numberOfTabs; i++)
		{
			ActiveFileInfo.put(i, (ActiveFileInfo)tempFileInfos.get(i));
		}
	}

	/*Clears the cacp arraylist */
	public void clearCacp()
	{ cacp.clear(); }

	/*Adds an element to the cacp arraylist */
	public void addToCacp(String concernName)
	{ cacp.add(concernName); }

	/* Returns the ActiveFileInfo Hashmap */
	public HashMap getActiveFileInfo()
	{  return ActiveFileInfo; }

	/* Create the menu bar */
	public JMenuBar createMenuBar()
	{
		JMenuBar menuBar;
		JMenu menu, submenu;
		JMenuItem menuItem;
		menuBar = new JMenuBar();
		// File MENU
		menu = new JMenu("File");
		menu.setMnemonic(KeyEvent.VK_F);

		KeyStroke F3 = KeyStroke.getKeyStroke(114, 0);
		menuItem = new JMenuItem("New", KeyEvent.VK_N);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);

		submenu = new JMenu("Open");
		submenu.setMnemonic(KeyEvent.VK_O);
		submenu.addActionListener(this);
		// Open SUBMENU 

		menuItem = new JMenuItem("Solution...", KeyEvent.VK_S);
		menuItem.addActionListener(this);
		submenu.add(menuItem);

		menuItem = new JMenuItem(".ivc file...", KeyEvent.VK_I);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		submenu.add(menuItem);

		menuItem = new JMenuItem(".java file...", KeyEvent.VK_J);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		submenu.add(menuItem);
		menu.add(submenu);

		menuBar.add(menu);

		menuItem = new JMenuItem("Close", KeyEvent.VK_C);
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menu.addSeparator();

		menuItem = new JMenuItem("Save Solution...", KeyEvent.VK_L);
		menuItem.addActionListener(this);
		menu.add(menuItem);

		save = new JMenuItem("Save", KeyEvent.VK_S);
		save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
			ActionEvent.CTRL_MASK));
		save.addActionListener(this);
		menu.add(save);

		saveAs = new JMenuItem("Save as...", KeyEvent.VK_A);
		saveAs.addActionListener(this);
		menu.add(saveAs);

		menu.addSeparator();

		export = new JMenuItem("Export to a Java file...", KeyEvent.VK_P);
		export.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I,
			ActionEvent.CTRL_MASK));
		export.addActionListener(this);
		menu.add(export);

		compile = new JMenuItem("Compile and Execute...", KeyEvent.VK_M);
		compile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,
			ActionEvent.CTRL_MASK));
		compile.addActionListener(this);
		menu.add(compile);

		menu.addSeparator();

		menuItem = new JMenuItem("Exit", KeyEvent.VK_X);
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menuBar.add(menu);
		// Edit MENU
		menu = new JMenu("Edit");
		menu.setMnemonic(KeyEvent.VK_E);

		menuItem = new JMenuItem("Cut", KeyEvent.VK_T);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menuItem = new JMenuItem("Copy", KeyEvent.VK_C);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menuItem = new JMenuItem("Paste", KeyEvent.VK_P);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menu.addSeparator();

		menuItem = new JMenuItem("Find", KeyEvent.VK_F);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menuItem = new JMenuItem("Find Next...", KeyEvent.VK_X);
		menuItem.setAccelerator(F3);
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menuItem = new JMenuItem("Goto Line Number...", KeyEvent.VK_L);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menuItem = new JMenuItem("Select All", KeyEvent.VK_L);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menuBar.add(menu);
		//View MENU
		menu = new JMenu("View");
		menu.setMnemonic(KeyEvent.VK_V);

		wovenFormMenuItem = new JMenuItem("Weave", KeyEvent.VK_W);
		wovenFormMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,
			ActionEvent.CTRL_MASK));
		wovenFormMenuItem.addActionListener(this);
		menu.add(wovenFormMenuItem);
		wovenFormMenuItem.setEnabled(false);

		unWovenFormMenuItem = new JMenuItem("Unweave", KeyEvent.VK_U);
		unWovenFormMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U,
			ActionEvent.CTRL_MASK));
		unWovenFormMenuItem.addActionListener(this);
		menu.add(unWovenFormMenuItem);

		viewFlags = new JCheckBoxMenuItem("View Flags");
		viewFlags.setMnemonic(KeyEvent.VK_F);
		viewFlags.addActionListener(this);
		menu.add(viewFlags);

		menuBar.add(menu);
		//Concerns MENU 
		menu = new JMenu("Concerns");
		menu.setMnemonic(KeyEvent.VK_C);

		addAConcernMenuItem = new JMenuItem("Add a Concern...", KeyEvent.VK_D);
		addAConcernMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D,
			ActionEvent.CTRL_MASK));
		addAConcernMenuItem.addActionListener(this);
		menu.add(addAConcernMenuItem);

		assignToConcernMenuItem =
			new JMenuItem("Assign to Concern...", KeyEvent.VK_G);
		assignToConcernMenuItem.setAccelerator
			(KeyStroke.getKeyStroke(KeyEvent.VK_K,
			ActionEvent.CTRL_MASK));
		assignToConcernMenuItem.addActionListener(this);
		menu.add(assignToConcernMenuItem);

		jumpToConcern = new JMenuItem("Jump to Concern...", KeyEvent.VK_C);
		jumpToConcern.setAccelerator
			(KeyStroke.getKeyStroke(KeyEvent.VK_B,
			ActionEvent.CTRL_MASK));
		jumpToConcern.addActionListener(this);
		menu.add(jumpToConcern);
		jumpToConcern.setEnabled(false);

		editConcern = new JMenuItem("Edit a Concern...", KeyEvent.VK_E);
		editConcern.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,
			ActionEvent.CTRL_MASK));
		editConcern.addActionListener(this);
		menu.add(editConcern);

		submenuRemove = new JMenu("Remove");
		submenuRemove.setMnemonic(KeyEvent.VK_R);
		submenuRemove.addActionListener(this);
		// Remove SUBMENU 
		menuItem = new JMenuItem("Completely Remove a Concern", KeyEvent.VK_R);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		submenuRemove.add(menuItem);

		menuItem = new JMenuItem("Deassign Concern from Current Text...",
			KeyEvent.VK_D);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		submenuRemove.add(menuItem);
		menu.add(submenuRemove);

		renameJoinPointMenuItem = new JMenuItem("Rename Code Regions...",
			KeyEvent.VK_N);
		renameJoinPointMenuItem.setAccelerator(KeyStroke.getKeyStroke(
			KeyEvent.VK_P, ActionEvent.CTRL_MASK));
		renameJoinPointMenuItem.addActionListener(this);
		menu.add(renameJoinPointMenuItem);

		menuItem = new JMenuItem("Change Multi-concern Background...",
			KeyEvent.VK_M);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);
		menuBar.add(menu);
		//Help MENU 
		menu = new JMenu("Help");
		menu.setMnemonic(KeyEvent.VK_H);

		menuItem = new JMenuItem("About IVCON", KeyEvent.VK_A);
		menuItem.addActionListener(this);
		menu.add(menuItem);

		/*menuItem = new JMenuItem("Debug", KeyEvent.VK_U);
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,
			ActionEvent.CTRL_MASK));
		menuItem.addActionListener(this);
		menu.add(menuItem);*/

		menuBar.add(menu);

		return menuBar;
	}

	/* Initializes RTree and sets up display window */
	public Container createContentPane(String fileName)
	{
		UNWOVENBODYFILTER.mainWindow = this;
		// Initialize R-Tree 
		regionTree.initRTree();
		// Initialize attributes
		attrs = initAttributes(NOOFATTRIBUTES);
		// Create sub-panels within the main panel
		wovenCode = new JTextPane();
		wovenCode.addKeyListener(this);
		wovenCode.addFocusListener(this);
		wovenCode.addMouseMotionListener(this);
		wovenCode.setName("wovenCode");
		concernLegend = new JTextPane();
		currentConcerns = new JTextPane();
		unWovenBody = new JTextPane();
		unWovenBody.addFocusListener(this);
		unWovenBody.setName("unWovenBody");
		unWovenConcerns = new JTextPane();
		unWovenConcerns.addKeyListener(this);
		unWovenConcerns.addFocusListener(this);
		unWovenConcerns.setName("unWovenConcerns");
		wovenCodeStyledDoc = wovenCode.getStyledDocument();
		concernLegendStyledDoc = concernLegend.getStyledDocument();
		currentConcernsStyledDoc = currentConcerns.getStyledDocument();
		unWovenBodyStyledDoc = unWovenBody.getStyledDocument();
		unWovenConcernsStyledDoc = unWovenConcerns.getStyledDocument();
		if (wovenCodeStyledDoc instanceof AbstractDocument)
			wovenCodeAbstractDoc = (AbstractDocument)wovenCodeStyledDoc;
		else
		{
			System.err.println("Woven Body's document isn't an AbstractDocument!");
			System.exit(-1);
		}
		if (unWovenBodyStyledDoc instanceof AbstractDocument)
			unWovenBodyAbstractDoc = (AbstractDocument)unWovenBodyStyledDoc;
		else
		{
			System.err.println("Unwoven Body's document isn't an AbstractDocument!");
			System.exit(-1);
		}
		if (unWovenConcernsStyledDoc instanceof AbstractDocument)
			unWovenConcernsAbstractDoc = (AbstractDocument)unWovenConcernsStyledDoc;
		else
		{
			System.err.println("Unwoven Concerns' document isn't an AbstractDocument!");
			System.exit(-1);
		}
		if (concernLegendStyledDoc instanceof AbstractDocument)
			concernLegendAbstractDoc = (AbstractDocument)concernLegendStyledDoc;
		else
		{
			System.err.println("Concern Legend's document isn't an AbstractDocument!");
			System.exit(-1);
		}
		if (currentConcernsStyledDoc instanceof AbstractDocument)
			currentConcernsAbstractDoc = (AbstractDocument)currentConcernsStyledDoc;
		else
		{
			System.err.println("Current Concerns' document isn't an AbstractDocument!");
			System.exit(-1);
		}
		//Some key actions are restricted
		unWovenBody.getInputMap().put(KeyStroke.getKeyStroke("control BACK_SPACE"), "none");
		unWovenBody.getInputMap().put(KeyStroke.getKeyStroke("DELETE"), "none");
		unWovenBody.getInputMap().put(KeyStroke.getKeyStroke("BACK_SPACE"), "none");
		unWovenBody.getInputMap().put(KeyStroke.getKeyStroke("control DELETE"), "none");
		unWovenBody.getInputMap().put(KeyStroke.getKeyStroke("shift DELETE"), "none");
		unWovenBody.getInputMap().put(KeyStroke.getKeyStroke("shift INSERT"), "none");
		unWovenBody.getInputMap().put(KeyStroke.getKeyStroke("control H"), "none");
		unWovenBody.getInputMap().put(KeyStroke.getKeyStroke("control shift O"), "none");

		wovenCode.getInputMap().put(KeyStroke.getKeyStroke("control BACK_SPACE"), "none");
		wovenCode.getInputMap().put(KeyStroke.getKeyStroke("control DELETE"), "none");
		wovenCode.getInputMap().put(KeyStroke.getKeyStroke("shift DELETE"), "none");
		wovenCode.getInputMap().put(KeyStroke.getKeyStroke("shift INSERT"), "none");
		wovenCode.getInputMap().put(KeyStroke.getKeyStroke("control H"), "none");
		wovenCode.getInputMap().put(KeyStroke.getKeyStroke("control shift O"), "none");

		unWovenConcerns.getInputMap().put(KeyStroke.getKeyStroke("control BACK_SPACE"), "none");
		unWovenConcerns.getInputMap().put(KeyStroke.getKeyStroke("DELETE"), "none");
		unWovenConcerns.getInputMap().put(KeyStroke.getKeyStroke("BACK_SPACE"), "none");
		unWovenConcerns.getInputMap().put(KeyStroke.getKeyStroke("control DELETE"), "none");
		unWovenConcerns.getInputMap().put(KeyStroke.getKeyStroke("shift DELETE"), "none");
		unWovenConcerns.getInputMap().put(KeyStroke.getKeyStroke("shift INSERT"), "none");
		unWovenConcerns.getInputMap().put(KeyStroke.getKeyStroke("control H"), "none");
		unWovenConcerns.getInputMap().put(KeyStroke.getKeyStroke("control shift O"), "none");

		this.setTabSize();	//Reduce tab sizes from default sizes to a smaller size

		//Create the main panel

		JPanel contentPane = new JPanel(new BorderLayout());
		contentPane.setOpaque(true);
		currentConcerns.setEditable(false);
		concernLegend.setEditable(false);
		scrollPane = new JScrollPane(concernLegend);
		scrollUWBody = new JScrollPane(unWovenBody);
		scrollPane.setBorder(BorderFactory.createTitledBorder(BORDER,
			"Concern Legend", TitledBorder.CENTER, 1));
		scrPan = new JScrollPane(wovenCode);
		scrPan.setBorder(BorderFactory.createTitledBorder(BORDER,
			"Woven Body", TitledBorder.CENTER, 1));
		scrollUWBody.setBorder(BorderFactory.createTitledBorder(BORDER,
			"Unwoven Body", TitledBorder.CENTER, 1));
		scrollUWConcerns = new JScrollPane(unWovenConcerns);
		scrollUWConcerns.setBorder(BorderFactory.createTitledBorder(BORDER,
			"Unwoven Concerns", TitledBorder.CENTER, 1));
		splitUnwoven = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
			scrollUWBody, scrollUWConcerns);
		splitUnwoven.setResizeWeight(.5);
		splitPreview = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
			scrPan, splitUnwoven);
		splitPreview.setResizeWeight(.85);
		splitPreview.setDividerSize(0);
		splitPreview.setOneTouchExpandable(true);
		splitUnwoven.setVisible(false);
		splitfirst = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
			scrollPane, splitPreview);
		splitfirst.setResizeWeight(.18);
		splitfirst.setOneTouchExpandable(true);
		scrollPane2 = new JScrollPane(currentConcerns);
		scrollPane2.setBorder(BorderFactory.createTitledBorder(
			BORDER, "Concerns at Current Position", TitledBorder.CENTER, 1));
		splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
			splitfirst, scrollPane2);
		splitPane.setResizeWeight(.83);
		splitPane.setOneTouchExpandable(true);
		statusBar = new JLabel("IVCon - Inline Visualization of Concerns");
		contentPane.add(splitPane, BorderLayout.CENTER);
		contentPane.add(statusBar, BorderLayout.SOUTH);
		wovenCode.addCaretListener(this);
		frame.setIconImage(new ImageIcon("IV.jpg").getImage());
		tabbedPane.addTab(fileName, null, contentPane, null);
		tabbedPane.removeChangeListener(this);
		tabbedPane.addChangeListener(this);
		return tabbedPane;
	}

	/* Create the popup menu */
	public void createPopupMenu()
	{
		JMenu submenu;
		JMenuItem menuItem;
		popup = new JPopupMenu();
		if (concMan.getWoven())		//Display popup menu only in woven view
		{
			submenu = new JMenu("Assign to Concern");
			submenu.setMnemonic(KeyEvent.VK_C);
			// "Assign to Concern" SUBMENU
			menuItem = new JMenuItem("New Concern...", KeyEvent.VK_N);
			menuItem.addActionListener(this);
			submenu.add(menuItem);
			if (concMan.getNoOfConcerns() == 0)	// if no concerns have been defined yet
			{
				menuItem = new JMenuItem("Other Concerns");
				menuItem.setEnabled(false);
				submenu.add(menuItem);
			}
			else  // if concerns have been defined then add the conerns to the submenu
			{
				int i = 0;
				Object[] allConcerns = (concMan.getMap("concernMap")).keySet().toArray();
				while (i < allConcerns.length)
				{
					menuItem = new JMenuItem((String)allConcerns[i]);
					menuItem.addActionListener(this);
					submenu.add(menuItem);
					i++;
				}
			}

			popup.add(submenu);

			menuItem = new JMenuItem("DeAssign Concern from Current Text...");
			menuItem.addActionListener(this);
			if (concMan.getNoOfConcerns() == 0)
			{//If no concerns have been defined yet, disable this option
				menuItem.setEnabled(false);
			}
			else
			{
				menuItem.setEnabled(true);
			}

			popup.add(menuItem);
		}
		wovenCode.removeMouseListener(popupListener);
		unWovenBody.removeMouseListener(popupListener);
		popupListener = new PopupListener(popup);
		wovenCode.addMouseListener(popupListener);
		unWovenBody.addMouseListener(popupListener);
	}

	/* All actions from the main menu and pop up menu get directed to this function */
	public void actionPerformed(ActionEvent e)
	{
		JMenuItem source = (JMenuItem)(e.getSource());
		String selectedCommand = source.getText();
		if (selectedCommand == "New")
			fileMan.newFile();
		else if (selectedCommand == "Solution...")
		{
			FileStruct openFileStruct;
			File proj;
			JFileChooser fileChooser = new JFileChooser(OPENDIR);
			int returnVal = fileChooser.showOpenDialog(this.frame);
			if (returnVal == JFileChooser.APPROVE_OPTION)
			{
				proj = fileChooser.getSelectedFile();
				OPENDIR = proj.toString();
			}
			else
				return;
			fileMan.openSolution(proj);
		}
		else if (selectedCommand == ".ivc file...")
		{
			FileStruct openFileStruct;
			File file;
			JFileChooser fileChooser = new JFileChooser(OPENDIR);
			int returnVal = fileChooser.showOpenDialog(this.frame);
			if (returnVal == JFileChooser.APPROVE_OPTION)
			{
				file = fileChooser.getSelectedFile();
				OPENDIR = file.toString();
				concMan.setOpenFile(file);
			}
			else
				return;
			if (this.getCharTyped() != 0)
			{
				concMan.updateRegions(false);
				this.setCharTyped(0);
			}
			fileMan.openIvcFile(file);
		}
		else if (selectedCommand == ".java file...")
		{
			JFileChooser fileChooser = new JFileChooser(OPENDIR);
			File file;
			int returnVal = fileChooser.showOpenDialog(this.frame);
			if (returnVal == JFileChooser.APPROVE_OPTION)
			{
				file = fileChooser.getSelectedFile();
				OPENDIR = file.toString();
				concMan.setOpenFile(file);
			}
			else
				return;
			if (this.getCharTyped() != 0)
			{
				concMan.updateRegions(false);
				this.setCharTyped(0);
			}
			fileMan.openJavaFile(file);
		}
		else if (selectedCommand == "Close")
			fileMan.close();
		else if (selectedCommand == "Save Solution...")
		{
			JFileChooser fileChooser = new JFileChooser(SAVEDIR);
			int returnVal = fileChooser.showSaveDialog(this.frame);
			if (returnVal == JFileChooser.APPROVE_OPTION)
				fileMan.saveSolution(fileChooser.getSelectedFile());
		}
		else if (selectedCommand == "Save")
			SAVEDIR = fileMan.save(SAVEDIR);
		else if (selectedCommand == "Save as...")
			SAVEDIR = fileMan.saveAs(SAVEDIR);
		else if (selectedCommand == "Export to a Java file...")
		{
			JFileChooser fileChooser = new JFileChooser(SAVEDIR);
			int returnVal = fileChooser.showDialog(frame, "Export");
			if (returnVal == JFileChooser.APPROVE_OPTION)
			{
				File file = fileChooser.getSelectedFile();
				SAVEDIR = file.toString();
				fileMan.saveJavaFile(file.getAbsolutePath());
			}
			else
				return;
		}
		else if (selectedCommand == "Compile and Execute...")
			this.compile();
		else if (selectedCommand == "Exit")
			System.exit(0);
		else if (selectedCommand == "Cut")
		{
			kbdAction("C");		// Important for the Keyboard Listener
			wovenCode.cut();
		}
		else if (selectedCommand == "Copy")
			wovenCode.copy();
		else if (selectedCommand == "Paste")
		{
			wovenCode.paste();
			kbdAction("P");		// Important for the Keyboard Listener
		}
		else if (selectedCommand == "Find")
			this.findText(true);
		else if (selectedCommand == "Find Next...")
			this.findText(false);
		else if (selectedCommand == "Goto Line Number...")
			this.gotoLine();
		else if (selectedCommand == "Select All")
			wovenCode.selectAll();
		else if (selectedCommand == "Weave")
		{
			concMan.viewWoven();
			if (concMan.getWoven())
				viewFlags.setEnabled(true);
		}
		else if (selectedCommand == "Unweave")
		{
			concMan.viewUnwoven();
			if (!concMan.getWoven())
				viewFlags.setEnabled(false);
		}
		else if (selectedCommand == "View Flags")
		{
			concMan.viewFlags();
			boolean viewFlags = concMan.getViewFlags();
			boolean wovenState = concMan.getWoven();
			concMan.setViewFlags(!viewFlags);
			updateViewFlagState(!viewFlags);
			export.setEnabled(wovenState && viewFlags);
			assignToConcernMenuItem.setEnabled(wovenState && viewFlags);
			submenuRemove.setEnabled(wovenState && viewFlags);
			editConcern.setEnabled(wovenState && viewFlags);
		}
		else if (selectedCommand == "Add a Concern...")
			concMan.addConcern();
		else if (selectedCommand == "New Concern...")
			concMan.newConcern();
		else if (selectedCommand == "Assign to Concern...")
		{
			if (wovenCode.getSelectedText() == null)
			{// if user hasnt selected any text
				JOptionPane.showMessageDialog(frame,
					"Select Code Text to Assign to a Concern.",
					"IVCON", JOptionPane.WARNING_MESSAGE);
				return;
			}
			//Set up options for the Option Pane and display it
			Object[] possibilities = new Object[concMan.getNoOfConcerns()+1];
			int i = 1;
			possibilities[0] = "New Concern...";
			Object[] allConcerns = (concMan.getMap("concernMap")).keySet().toArray();
			while (i <= concMan.getNoOfConcerns())
			{
				possibilities[i] = allConcerns[i - 1];
				i++;
			}
			String selectedOption = (String)JOptionPane.showInputDialog(frame,
									"Select the concern to assign code to\n\n",
									"Assign to Concern",
									JOptionPane.PLAIN_MESSAGE, null, possibilities, "");
			if (selectedOption != null)
			{
				//if user selects new concern... we define a new concern
				if (selectedOption == "New Concern...")
					concMan.newConcern();
				else
					//else we add the text to the prexisting concern selected by user
					concMan.findConcernAndAdd(selectedOption);
			}
		}
		else if (selectedCommand == "Jump to Concern...")
		{
			//Set up options for the Option Pane and display it
			Object[] possibilities = new Object[concMan.getNoOfConcerns()];
			int i = 0;
			Object[] allConcerns = (concMan.getMap("concernMap")).keySet().toArray();
			while (i < concMan.getNoOfConcerns())
			{
				possibilities[i] = allConcerns[i];
				i++;
			}
			String selectedOption = (String)JOptionPane.showInputDialog(frame,
									"Select the concern to jump to to\n\n",
									"Jump to Concern",
									JOptionPane.PLAIN_MESSAGE, null, possibilities, "");
			if (selectedOption != null)
				jumpToConcern(selectedOption);
		}
		else if (selectedCommand == "Edit a Concern...")
			concMan.editConcern();
		else if (selectedCommand == "Completely Remove a Concern")
			concMan.removeConcern();
		else if (selectedCommand == "Deassign Concern from Current Text...")
			concMan.deAssignConcern();
		else if (selectedCommand == "Rename Code Regions...")
			concMan.renameJoinPoints();
		else if (selectedCommand == "Change Multi-concern Background...")
			concMan.changeMultiColor();
		else if (selectedCommand == "About IVCON")
		{
			JOptionPane.showMessageDialog(frame, "<html><p align=center>"
				  + "IVCON - Inline Visualization of Concerns<br>Version  0.9<br>"
				  + "By Nalin Saigal and Jay Ligatti<br><br>"
				  + "<font size=2>(C) 2009 - University of South Florida<BR>",
				  "About IVCON", JOptionPane.INFORMATION_MESSAGE);
		}
		else
			//no other command means that user selected a concern 
			//from the pop up menu to assign to code
			concMan.findConcernAndAdd(selectedCommand);
	}

	/* Finds text specificed by the user in user's code */
	void findText(boolean ask)
	{
		try
		{
			String text;
			if (ask)
				text = (String)JOptionPane.showInputDialog(frame,
										"Enter text to find:\n\n",
										"Find Text",
										JOptionPane.PLAIN_MESSAGE, null, null, findText);
			else
				text = new String(findText);
			if (text == null)
				return;
			text = text.toLowerCase();
			findText = new String(text);
			int startSearchFrom = wovenCode.getSelectionEnd();
			String code = wovenCode.getText(startSearchFrom, wovenCodeAbstractDoc.getLength() - startSearchFrom);
			code = code.toLowerCase();
			wovenCode.setCaretPosition(startSearchFrom);
			int index = code.indexOf(text);
			if (index < 0)
			{
				JOptionPane.showMessageDialog(frame,
										"Text not found",
										"IVCon",
										JOptionPane.WARNING_MESSAGE);
				return;
			}
			String substr = code.substring(0, index);
			index += startSearchFrom;
			wovenCode.select(index, index + text.length());
		}
		catch (BadLocationException ble)
		{ ble.printStackTrace(); }
	}

	/* Jumps to a Line Number specified by the user */
	void gotoLine()
	{
		int lineNo = 0;
		try
		{
			String line = (String)JOptionPane.showInputDialog(frame,
									"Enter line number to go to:\n\n",
									"Goto",
									JOptionPane.PLAIN_MESSAGE, null, null, findText);
			if (line == null)
				return;
			lineNo = Integer.parseInt(line);
		}
		catch (NumberFormatException nfe)
		{
			JOptionPane.showMessageDialog(frame,
										"Please enter a numeric value for line number.",
										"IVCon",
										JOptionPane.ERROR_MESSAGE);
			gotoLine();
			return;
		}
		String code = wovenCode.getText();
		int counter = 1;
		int offset = 0;
		while (counter < lineNo)
		{
			int nindex = code.indexOf('\n');
			if (nindex < 0)
				break;
			offset += nindex;
			code = code.substring(nindex + 1);
			counter++;
		}
		wovenCode.setCaretPosition(offset);
	}

	void jumpToConcern(String concernName)
	{
		String findText = "concern " + concernName;
		int replacedLen = 0;
		int findIndex = 0;
		try
		{
			String allText = unWovenConcerns.getText(0, unWovenConcernsAbstractDoc.getLength());
			Color color = concMan.getConcernColor(concernName);
			while (true)
			{
				findIndex = allText.indexOf(findText);
				if (getForegroundColor(findIndex + replacedLen).equals(color))
					break;
				else
				{
					allText = allText.substring(findIndex + 1);
					replacedLen += findIndex + 1;
				}
			}
			unWovenConcerns.setCaretPosition(findIndex + replacedLen);
		}
		catch (BadLocationException ble)
		{ ble.printStackTrace(); }
	}

	public void compile()
	{
		String cmd = "";
		JLabel cp = new JLabel("Enter the classpath of your project (Optional):");
		JTextField classPath = new JTextField(CLASSPATH);
		JLabel od = new JLabel("Enter the output directory of your project:");
		JTextField outputDir = new JTextField(OUTPUTDIR);
		JLabel mc = new JLabel("Enter the main class of your project (Optional):");
		JTextField mainClass = new JTextField(MAINCLASS);
		JPanel labelPane = new JPanel(new GridLayout(0, 1));
		labelPane.add(cp);
		labelPane.add(classPath);
		labelPane.add(od);
		labelPane.add(outputDir);
		labelPane.add(mc);
		labelPane.add(mainClass);
		Runtime runTime = java.lang.Runtime.getRuntime();
		while (true)
		{
			int selectedOption = JOptionPane.showOptionDialog(this.frame,
					labelPane, "Compile Code", JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.PLAIN_MESSAGE, null, null, null);
			CLASSPATH = classPath.getText();
			MAINCLASS = mainClass.getText();
			OUTPUTDIR = outputDir.getText();
			if (selectedOption == 2 || selectedOption == -1)
				return;
			if (OUTPUTDIR.equals(new String("")))
			{
				JOptionPane.showMessageDialog(frame,
					"Please specify an output directory.",
					"IVCON", JOptionPane.ERROR_MESSAGE);
				continue;
			}
			if (!(new File(OUTPUTDIR)).exists())
			{
				JOptionPane.showMessageDialog(frame,
				   "Output directory does not exist.",
				   "IVCON", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if (OUTPUTDIR.substring(OUTPUTDIR.length() - 1).equals("\\"))
				OUTPUTDIR = OUTPUTDIR.substring(0, OUTPUTDIR.length() - 1);
			if (MAINCLASS.equals(new String("")))
			{
				if (concMan.getOpenFile() == null)
				{
					JOptionPane.showMessageDialog(frame,
									"Please save the current file before compiling code.",
									"IVCON", JOptionPane.ERROR_MESSAGE);
					return;
				}
				String openFile = concMan.getOpenFile().getName();
				int dotIndex = openFile.lastIndexOf('.');
				String output = "";
				if (dotIndex < 0)
					output = openFile + ".java";
				else
					output = openFile.substring(0, dotIndex) + ".java";
				fileMan.saveJavaFile(OUTPUTDIR + "\\" + output);
				if (CLASSPATH.equals(new String("")))
					cmd = "javac " + OUTPUTDIR + "\\" + output;
				else if (!CLASSPATH.equals(new String("")))
					cmd = "javac " + "-classpath " + CLASSPATH + " " + OUTPUTDIR + "\\" + output;
			}
			else if (!MAINCLASS.equals(new String("")))
			{
				MAINCLASS = MAINCLASS + ".java";
				if (concMan.getOpenFile() == null)
				{
					JOptionPane.showMessageDialog(frame,
									"Please save the current file before compiling code.",
									"IVCON", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if (!(new File(OUTPUTDIR + "\\" + MAINCLASS)).exists())
				{
					JOptionPane.showMessageDialog(frame,
					   "File " + OUTPUTDIR + "\\" + MAINCLASS +
					   " does not exist.", "IVCON", JOptionPane.ERROR_MESSAGE);
					return;
				}
				String openFile = concMan.getOpenFile().getName();
				int dotIndex = openFile.lastIndexOf('.');
				String output = "";
				if (dotIndex < 0)
					output = openFile + ".java";
				else
					output = openFile.substring(0, dotIndex) + ".java";
				fileMan.saveJavaFile(OUTPUTDIR + "\\" + output);
				if (CLASSPATH.equals(new String("")))
					cmd = "javac " + OUTPUTDIR + "\\" + MAINCLASS;
				else if (!CLASSPATH.equals(new String("")))
					cmd = "javac " + "-classpath " + CLASSPATH + " " + OUTPUTDIR + "\\" + MAINCLASS;
			}
			try
			{
				Process p = runTime.exec(cmd);
				BufferedReader stdError = new BufferedReader(new
					 InputStreamReader(p.getErrorStream()));
				String s = null;
				String fullError = "";
				while ((s = stdError.readLine()) != null)
				{ fullError = fullError.concat(s + "\n"); }
				if (fullError != "" && !fullError.substring(0,4).toLowerCase().equals("note"))
				{
					JTextArea errorMessage = new JTextArea(20, 50);
					errorMessage.setText(fullError);
					errorMessage.setMaximumSize(new Dimension(100, 100));
					errorMessage.setEditable(false);
					JScrollPane errorScroll = new JScrollPane(errorMessage);
					errorScroll.setMaximumSize(new Dimension(100, 100));
					Object[] options ={ "OK", "Details..." };
					int so = JOptionPane.showOptionDialog(this.frame,
					"Error(s) occured. Click on Details to view errors.", "Compile Code", JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
					if (so == 1)
						JOptionPane.showMessageDialog(this.frame,
						errorScroll, "Errors", -1);
				}
				else
				{
					Object[] options ={ "OK", "Execute" };
					int so =
					JOptionPane.showOptionDialog(frame,
						"Succesfully Compiled!", "IVCon", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
					if (so == 1)
					{
						if (!MAINCLASS.equals(new String("")))
							MAINCLASS = MAINCLASS.substring(0, MAINCLASS.length() - 5);
						if (CLASSPATH.equals(new String("")))
						{
							if (MAINCLASS.equals(new String("")))
							{
								String openFile = concMan.getOpenFile().getName();
								int dotIndex = openFile.lastIndexOf('.');
								String output = "";
								if (dotIndex < 0)
									output = openFile;
								else
									output = openFile.substring(0, dotIndex);
								cmd = "java " + output;
							}
							else
							{
								cmd = "java " + MAINCLASS;
							}
						}
						else
						{
							if (MAINCLASS.equals(new String("")))
							{
								String openFile = concMan.getOpenFile().getName();
								int dotIndex = openFile.lastIndexOf('.');
								String output = "";
								if (dotIndex < 0)
									output = openFile;
								else
									output = openFile.substring(0, dotIndex);
								cmd = "java -classpath " + CLASSPATH + " " + output;
							}
							else
							{
								cmd = "java -classpath " + CLASSPATH + " " + MAINCLASS;
							}
						}
						p = runTime.exec(cmd, null, new File(OUTPUTDIR));
						BufferedReader stdInput = new BufferedReader(new
							 InputStreamReader(p.getInputStream()));
						while ((s = stdInput.readLine()) != null)
						{ System.out.println(s); }
					}
				}
			}
			catch (IOException e)
			{
				JOptionPane.showMessageDialog(frame,
				e.getMessage(),
				"IVCON", JOptionPane.ERROR_MESSAGE);
			}
			break;
		}
	}

	/* Define some attributes */
	protected SimpleAttributeSet[] initAttributes(int length)
	{
		SimpleAttributeSet[] attrs = new SimpleAttributeSet[length];

		attrs[0] = new SimpleAttributeSet();
		StyleConstants.setFontFamily(attrs[0], "SansSerif");
		StyleConstants.setFontSize(attrs[0], 12);
		StyleConstants.setBold(attrs[0], false);

		attrs[1] = new SimpleAttributeSet(attrs[0]);
		StyleConstants.setFontFamily(attrs[1], "SansSerif");
		StyleConstants.setFontSize(attrs[1], 12);
		StyleConstants.setBold(attrs[1], false);

		attrs[2] = new SimpleAttributeSet(attrs[0]);
		StyleConstants.setFontFamily(attrs[2], "SansSerif");
		StyleConstants.setFontSize(attrs[2], 12);
		StyleConstants.setBold(attrs[2], true);

		attrs[3] = new SimpleAttributeSet(attrs[0]);
		StyleConstants.setFontFamily(attrs[3], "SansSerif");
		StyleConstants.setFontSize(attrs[3], 12);
		StyleConstants.setBold(attrs[3], false);

		attrs[4] = new SimpleAttributeSet(attrs[0]);
		StyleConstants.setFontFamily(attrs[4], "SansSerif");
		StyleConstants.setFontSize(attrs[4], 12);
		StyleConstants.setBold(attrs[4], false);

		attrs[5] = new SimpleAttributeSet(attrs[0]);
		StyleConstants.setFontFamily(attrs[5], "SansSerif");
		StyleConstants.setFontSize(attrs[5], 12);
		StyleConstants.setBold(attrs[5], false);

		attrs[6] = new SimpleAttributeSet(attrs[0]);
		StyleConstants.setFontFamily(attrs[6], "SansSerif");
		StyleConstants.setFontSize(attrs[6], 12);
		StyleConstants.setBold(attrs[6], false);
		StyleConstants.setSuperscript(attrs[6], true);

		attrs[7] = new SimpleAttributeSet(attrs[0]);
		StyleConstants.setFontFamily(attrs[7], "SansSerif");
		StyleConstants.setFontSize(attrs[7], 0);
		StyleConstants.setBackground(attrs[7], Color.BLACK);

		return attrs;
	}

	public void itemStateChanged(ItemEvent e)
	{ /* Empty Implementation of Superclass's Abstract Function */ }

	public void stateChanged(ChangeEvent e)
	{
		if (this.getCharTyped() != 0)
		{
			concMan.updateRegions(false);
			regionUpdater.charTyped = 0;
		}
		int index = ((JTabbedPane)e.getSource()).getSelectedIndex();
		if (index < 0)
			return;
		ActiveFileInfo tempFileInfo = (ActiveFileInfo)ActiveFileInfo.get(index);
		sessionon = tempFileInfo.saved;
		wovenCode = tempFileInfo.wovenCode;
		wovenCodeStyledDoc = wovenCode.getStyledDocument();
		concernLegend = tempFileInfo.concernLegend;
		currentConcerns = tempFileInfo.currentConcerns;
		unWovenConcerns = tempFileInfo.unwovenConcerns;
		unWovenBody = tempFileInfo.unwovenBody;
		unWovenBodyAbstractDoc = tempFileInfo.body;
		unWovenConcernsAbstractDoc = tempFileInfo.concerns;
		wovenCodeAbstractDoc = tempFileInfo.woven;
		concernLegendAbstractDoc = tempFileInfo.legend;
		currentConcernsAbstractDoc = tempFileInfo.current;
		splitUnwoven = tempFileInfo.splUnwoven;
		splitPreview = tempFileInfo.splPreview;
		scrPan = tempFileInfo.scrollPane;
		unWovenConcernsStyledDoc = unWovenConcerns.getStyledDocument();
		concMan.setMCB(tempFileInfo.MCB);
		concMan.setMap("concernMap", tempFileInfo.concMap);
		concMan.setMap("regionMap", tempFileInfo.regionMap);
		concMan.setNoOfConcerns(concMan.size("concernMap"));
		concMan.setNoOfRegions(concMan.size("concernMap"));
		concMan.setOpenFile(tempFileInfo.file);
		regionTree.setRTree(tempFileInfo.regionTree);
		boolean viewFlag = tempFileInfo.viewFlags;
		boolean wovenState = wovenCode.isShowing();
		concMan.setViewFlags(viewFlag);
		viewFlags.setState(viewFlag);
		compile.setEnabled(wovenState && !viewFlag);
		jumpToConcern.setEnabled(!wovenState);
		wovenFormMenuItem.setEnabled(!wovenState);
		unWovenFormMenuItem.setEnabled(wovenState);
		export.setEnabled(wovenState && !viewFlag);
		renameJoinPointMenuItem.setEnabled(wovenState);
		assignToConcernMenuItem.setEnabled(wovenState && !viewFlag);
		save.setEnabled(wovenState);
		saveAs.setEnabled(wovenState);
		submenuRemove.setEnabled(wovenState && !viewFlag);
		addAConcernMenuItem.setEnabled(wovenState);
		editConcern.setEnabled(wovenState && !viewFlag);
		concMan.setWoven(wovenState);
	}

	/* Mouse motion listener for implementing Tooltips */
	public void mouseMoved(MouseEvent e)
	{
		int xCoord = e.getX();
		int yCoord = e.getY();
		Point point = new Point(xCoord, yCoord);
		int textPosition = wovenCode.viewToModel(point);
		cacp.clear();
		regionTree.queryMethod(textPosition, textPosition, 3);
		if (regionTree.getVisited())
		{
			String allConcerns = new String("");
			for (int i = 0; i < cacp.size(); i++)
				allConcerns = allConcerns.concat((String)cacp.get(i) + ", ");
			wovenCode.setToolTipText(allConcerns.substring(0, allConcerns.length() - 2));
		}
		else
			wovenCode.setToolTipText("");
	}

	public void mouseDragged(MouseEvent e)
	{ /* Empty Implementation of Superclass's Abstract Function */ }

	/* Keyboard Listener Functions */

	/* Takes care of Ctrl+X and Ctrl+V */
	void kbdAction(String ctrlKey)
	{
		//Get the number of characters removed or added as
		//a result of cut and paste respectively
		String tempString = textTransfer.getClipboardContents();
		int strLength = tempString.length();
		if (ctrlKey.equals(new String("C")))
		{
			regionUpdater.charTyped -= strLength;
			overRidePosition = wovenCode.getCaretPosition();
			overRidePosition2 = overRidePosition + strLength;
		}
		else if (ctrlKey.equals(new String("P")))
		{
			if (!tempString.contains(globalVariable.HOLE))
				regionUpdater.charTyped += strLength;
		}
		if (!unWovenConcerns.isFocusOwner())
			concMan.updateRegions(false);
		regionUpdater.charTyped = 0;
	}

	/* Displays the list of concerns at current caret position
	 * Also, decides whether unwovenconcerns window is editable or not*/
	public void caretUpdate(CaretEvent e)
	{
		//concMan.paraAttr();
		JTextPane target;
		if (concMan.getWoven())
			target = wovenCode;
		else
			target = unWovenBody;
		isHoleInSelection = false;
		if (!concMan.getWoven() && unWovenBody.isFocusOwner() &&
			unWovenBody.getSelectedText() != null &&
			unWovenBody.getSelectedText().contains(globalVariable.HOLE))
		{
			isHoleInSelection = true;
			return;
		}
		unWovenConcerns.setEditable(true);
		// Based on cursor position, this block determines whether unWovenConcerns
		//is editable by the user or not. State is reflected in isUwcEditable.
		if (unWovenConcerns.isFocusOwner())
		{
			//checkPosition2 & checkPosition are for if user
			//has selected a particular region of text or just one point.
			int checkPosition = unWovenConcerns.getSelectionStart();
			int checkPosition2 = unWovenConcerns.getSelectionEnd();
			try
			{
				if (checkPosition == unWovenConcernsAbstractDoc.getLength() ||
					checkPosition == unWovenConcernsAbstractDoc.getLength() - 1)	//implies that cursor is at the end of the unwoven concerns
					isUwcEditable = false;
				else if (isSuperScript(checkPosition, unWovenConcerns).equals("true"))	//implies that cursor is on a concern name
					isUwcEditable = false;
				else if (unWovenConcerns.getText(checkPosition, 1).equals(" ") &&  //implies that cursor is on the start of a region 
			   isSuperScript(checkPosition - 1, unWovenConcerns).equals("true"))
					isUwcEditable = false;
				else if (unWovenConcerns.getText(checkPosition, 1).equals(" ") && //implies that cursor is on the end of a region
			   isSuperScript(checkPosition + 1, unWovenConcerns).equals("true"))
					isUwcEditable = false;
				else if (checkPosition != 0 &&					//implies that cursor is on the >> symbol
					unWovenConcerns.getText(checkPosition - 1, 2).
					equals(globalVariable.OPENARROW))
					isUwcEditable = false;
				else if (checkPosition > 1 &&	//implies that cursor is at the start of a subconcern block
			   unWovenConcerns.getText(checkPosition - 2, 3).
			   equals(globalVariable.OPENARROW + globalVariable.NEWLINE))
					isUwcEditable = false;
				else if (checkPosition != 0 &&	//implies that cursor is at the end of a subconcern block
					unWovenConcerns.getText(checkPosition - 1, 4).
					equals(globalVariable.NEWLINE + "\t" + globalVariable.CLOSEARROW))
					isUwcEditable = false;
				else if (checkPosition != 0 &&	//implies that cursor is at the end of a subconcern block
					unWovenConcerns.getText(checkPosition, 2).
					equals(globalVariable.CLOSEARROW))
					isUwcEditable = false;
				else
				{
					String concernText = unWovenConcerns.getText(checkPosition,
						unWovenConcernsAbstractDoc.getLength() - checkPosition);
					int index1 = concernText.indexOf(globalVariable.OPENARROW);
					int index2 = concernText.indexOf(globalVariable.CLOSEARROW);
					if (index1 < 0 && index2 < 0)
						isUwcEditable = false;
					else if (index1 < 0 && index2 >= 0)
						isUwcEditable = true;
					else if (index1 >= 0 && index2 >= 0)
					{
						if (index1 > index2)
							isUwcEditable = true;
						else if (index1 < index2)
							isUwcEditable = false;
					}
				}
				// in the case that a region of text is selected, unwoven concerns window
				// will be editable only if the selected text is code text
				if (checkPosition2 != checkPosition)
				{
					if (isUwcEditable)
					{
						if (checkPosition2 == unWovenConcernsAbstractDoc.getLength() ||	//implies that cursor is at the end of the unwoven concerns
					   checkPosition2 == unWovenConcernsAbstractDoc.getLength() - 1)
							isUwcEditable = false;
						else if (isSuperScript(checkPosition2, unWovenConcerns).equals("true"))	//implies that cursor is on a concern name
							isUwcEditable = false;
						else if (unWovenConcerns.getText(checkPosition2, 1).equals(" ") &&	//implies that cursor is on the start of a region 
					   isSuperScript(checkPosition2 - 1, unWovenConcerns).equals("true"))
							isUwcEditable = false;
						else if (unWovenConcerns.getText(checkPosition2, 1).equals(" ") && //implies that cursor is on the end of a region
					   isSuperScript(checkPosition2 + 1, unWovenConcerns).equals("true"))
							isUwcEditable = false;
						else if (checkPosition2 != 0 &&		//implies that cursor is on the >> symbol
						unWovenConcerns.getText(checkPosition2 - 1, 2).
							equals(globalVariable.OPENARROW))
							isUwcEditable = false;
						else if (checkPosition2 > 1 &&	//implies that cursor is at the start of a subconcern block
			   unWovenConcerns.getText(checkPosition2 - 2, 3).
			   equals(globalVariable.OPENARROW + globalVariable.NEWLINE))
							isUwcEditable = false;
						else if (checkPosition2 != 0 &&	//implies that cursor is at the end of a subconcern bloc
			   unWovenConcerns.getText(checkPosition2 - 1, 4).
			   equals(globalVariable.NEWLINE + "\t" + globalVariable.CLOSEARROW))
							isUwcEditable = false;
						else if (unWovenConcerns.getText(checkPosition2, 2).	//implies that cursor is at the end of a subconcern bloc
					   equals(globalVariable.CLOSEARROW))
							isUwcEditable = false;

						else
						{
							String concernText =
								unWovenConcerns.getText(checkPosition2,
								unWovenConcernsAbstractDoc.getLength()
								- checkPosition2);
							int index1 =
								concernText.indexOf(globalVariable.OPENHOLE);
							int index2 =
								concernText.indexOf(globalVariable.CLOSEARROW);
							if (index1 < 0 && index2 < 0)
								isUwcEditable = false;
							else if (index1 < 0 && index2 >= 0)
								isUwcEditable = true;
							else if (index1 >= 0 && index2 >= 0)
							{
								if (index1 > index2)
									isUwcEditable = true;
								else if (index1 < index2)
									isUwcEditable = false;
							}
						}
					}
					if (isUwcEditable)
					{
						String checkString = unWovenConcerns.getText(checkPosition,
							checkPosition2 - checkPosition);
						if (checkString.contains(globalVariable.OPENHOLE) ||
							checkString.contains(globalVariable.CLOSEHOLE))
							isUwcEditable = false;
					}
				}
				//System.out.println(isUwcEditable);
				//if unwoven concerns is not editable, user could have selected a join point
				//in which case we show the user where the joinpoint is in the unwoven body.
				if (!isUwcEditable)
				{
					if (checkPosition2 == checkPosition)
					{
						boolean go = true;
						if (((unWovenConcerns.getText(checkPosition2, 1)).trim()).
							equals("") ||
							((unWovenConcerns.getText(checkPosition2, 1)).trim()).
							equals(((Object)((char)167)).toString()) ||
							((unWovenConcerns.getText(checkPosition2, 1)).trim()).
							equals(globalVariable.OPENHOLE) ||
							((unWovenConcerns.getText(checkPosition2, 2)).trim()).
							equals(globalVariable.OPENARROW) ||
							((unWovenConcerns.getText(checkPosition2, 2)).trim()).
							equals(globalVariable.CLOSEARROW))
							go = false;
						if (isSuperScript(checkPosition2, unWovenConcerns).equals("true"))
							go = false;
						if (checkPosition2 == checkPosition && go)
						{
							unWovenConcerns.removeCaretListener(this);
							int bodyPosition = getBodyPosition(checkPosition2);
							//System.out.println(bodyPosition);
							if (bodyPosition >= 0)
							{
								unWovenBody.removeCaretListener(this);
								unWovenBody.setCaretPosition(bodyPosition);
								unWovenBody.addCaretListener(this);
							}
							unWovenConcerns.removeCaretListener(this);
							unWovenConcerns.setCaretPosition(checkPosition2);
							unWovenConcerns.addCaretListener(this);
						}
					}
					unWovenConcerns.setEditable(false);
				}
			}
			catch (BadLocationException ble1)
			{
				ble1.printStackTrace();
			}
		}
		// Display list of concerns if focus is on unwoven body or woven code.
		else if (!unWovenConcerns.isFocusOwner())
		{
			isWindowEditable = true;
			target.setEditable(true);
			if (target.isFocusOwner() && concMan.getViewFlags())
			{
				//checkPosition2 & checkPosition are for if user
				//has selected a particular region of text or just one point.
				int checkPosition = target.getSelectionStart();
				int checkPosition2 = target.getSelectionEnd();
				try
				{
					if (isSuperScript(checkPosition, target).equals("true"))	//implies that cursor is on a concern name
						isWindowEditable = false;
					else if (checkPosition != 0 &&					//implies that cursor is on the >> symbol
						target.getText(checkPosition - 1, 1).
						equals(globalVariable.OPENHOLE) &&
				   target.getText(checkPosition, 1).
				   equals(" "))
						isWindowEditable = false;
					else if (checkPosition != 0 && target.getText(checkPosition - 1, 1).equals(globalVariable.CLOSEHOLE))
						isWindowEditable = false;
					else if (isSuperScript(checkPosition - 1, target).equals("true"))
						isWindowEditable = false;
					else if (target.getText(checkPosition, 1).equals(globalVariable.OPENHOLE))
						isWindowEditable = false;
					// in the case that a region of text is selected, unwoven concerns window
					// will be editable only if the selected text is code text
					if (checkPosition2 != checkPosition)
					{
						if (isWindowEditable)
						{
							if (isSuperScript(checkPosition2, target).equals("true"))	//implies that cursor is on a concern name
								isWindowEditable = false;
							else if (checkPosition2 != 0 &&					//implies that cursor is on the >> symbol
								target.getText(checkPosition2 - 1, 1).
								equals(globalVariable.OPENHOLE) &&
						   target.getText(checkPosition2, 1).
						   equals(" "))
								isWindowEditable = false;
							else if (checkPosition2 != 0 && target.getText(checkPosition2 - 1, 1).equals(globalVariable.CLOSEHOLE))
								isWindowEditable = false;
							else if (isSuperScript(checkPosition2 - 1, target).equals("true"))
								isWindowEditable = false;
							else if (target.getText(checkPosition2, 1).equals(globalVariable.OPENHOLE))
								isWindowEditable = false;
						}
						if (isWindowEditable)
						{
							String checkString = target.getText(checkPosition,
								checkPosition2 - checkPosition);
							if (checkString.contains(globalVariable.OPENHOLE) ||
								checkString.contains(globalVariable.CLOSEHOLE))
							{ isWindowEditable = false; }
						}
					}
					//if unwoven concerns is not editable, user could have selected a join point
					//in which case we show the user where the joinpoint is in the unwoven body.
					target.setEditable(isWindowEditable);
				}
				catch (BadLocationException ble1)
				{
					ble1.printStackTrace();
				}
			}
			if (regionUpdater.charTyped == 0)
			{
				int inquiryPosition = e.getDot();
				currentConcerns.selectAll();
				currentConcerns.setEditable(true);
				currentConcerns.replaceSelection("");
				currentConcerns.setEditable(false);
				currentNoOfRegions = 0;
				concMan.clear("listOfConcerns");
				//display the list of concerns
				regionTree.queryMethod(inquiryPosition, inquiryPosition, 1);
				if (currentNoOfRegions > 1)
					target.setCaretColor(Color.WHITE);
				else
					target.setCaretColor(Color.BLACK);
			}
		}
	}

	/* Returns caret position (in unwoven body) of the joinpoint 
	 * which user has clicked (in unwoven concerns) */
	int getBodyPosition(int concernPosition)
	{
		//Find out beginning and end of the concern in which user has clicked
		AttributeSet currentAttributes = unWovenConcerns.getCharacterAttributes();
		Enumeration attributeNames = currentAttributes.getAttributeNames();
		Color tempColor = null;
		try
		{
			while (attributeNames.hasMoreElements())
			{
				Object nextAttribute = attributeNames.nextElement();
				String attributeString = nextAttribute.toString();
				if (attributeString.equals("foreground"))
				{
					tempColor = (Color)(currentAttributes.getAttribute(nextAttribute));
					break;
				}
			}
			String allUnWovenText = unWovenConcerns.getText(0,
				unWovenConcernsAbstractDoc.getLength());
			String find = "concern ";
			int offset = 0;
			int tempIndex = 0;
			while (true)
			{
				tempIndex = allUnWovenText.indexOf(find, offset);
				if (tempIndex < 0)
					break;
				offset = tempIndex + 1;
				unWovenConcerns.setCaretPosition(tempIndex);
				currentAttributes = unWovenConcerns.getCharacterAttributes();
				attributeNames = currentAttributes.getAttributeNames();
				Color foregroundColor = null;
				while (attributeNames.hasMoreElements())
				{
					Object nextAttribute = attributeNames.nextElement();
					String attributeString = nextAttribute.toString();
					if (attributeString.equals("foreground"))
					{
						foregroundColor = (Color)
							(currentAttributes.getAttribute(nextAttribute));
						break;
					}
				}
				if (foregroundColor.equals(tempColor))
					break;
			}

			int tempOffset = concernPosition - tempIndex;
			String analyzeText = unWovenConcerns.getText(tempIndex, tempOffset);
			//Analysis of Concern text
			int noOfCloseArrows = 0;
			String tempText = new String(analyzeText);
			if (analyzeText.indexOf(globalVariable.CLOSEARROW) >= 0)
			{
				tempText = new String("");
				while (true)
				{
					int index = analyzeText.indexOf(globalVariable.OPENARROW);
					int index2 = analyzeText.indexOf(globalVariable.CLOSEARROW);
					if (index < 0)
					{
						break;
					}
					tempText = tempText + analyzeText.substring(0, index + 2);
					tempText = tempText + analyzeText.substring(index2, index2 + 2);
					analyzeText = analyzeText.substring(index2 + 2);
					noOfCloseArrows++;
				}
				tempText = tempText + analyzeText;
			}
			int noOfAts = 0;
			while (true)
			{
				int index = tempText.indexOf("@");
				if (index < 0)
				{
					break;
				}
				offset = index + 1;
				tempText = tempText.substring(offset);
				noOfAts++;
			}
			if (noOfCloseArrows != noOfAts)
			{//means [no. of @'s] = [no of >>}'s] + 1    => we r looking at a joinpoint
				int startRegion = concernPosition - 1;
				while (!(unWovenConcerns.getText(startRegion, 1).trim().equals("")))
					startRegion--;
				int endRegion = concernPosition + 1;
				while (!(unWovenConcerns.getText(endRegion, 1).trim().equals("")))
					endRegion++;
				String nameOfRegion = unWovenConcerns.getText(startRegion,
					endRegion - startRegion);
				int i = 0;
				HashMap allRegions = concMan.getMap("regionMap");
				Object[] allIds = allRegions.keySet().toArray();
				for (i = 0; i < concMan.size("regionMap"); i++)
				{
					if ((((RegionInfo)(concMan.get("regionMap",
						(Integer)allIds[i]))).regionName).
						equals(nameOfRegion.trim()))
						break;
				}
				return ((RegionInfo)(concMan.get("regionMap",
					(Integer)allIds[i]))).begPos;
			}
		}
		catch (BadLocationException ble)
		{
			System.out.println(ble); ble.printStackTrace();
		}
		return -1;
	}

	Color getForegroundColor(int position)
	{
		unWovenConcerns.removeCaretListener(this);
		unWovenConcerns.setCaretPosition(position);
		unWovenConcerns.addCaretListener(this);
		AttributeSet currentAttributes = unWovenConcerns.getCharacterAttributes();
		Enumeration attributeNames = currentAttributes.getAttributeNames();
		Color tempColor = null;
		while (attributeNames.hasMoreElements())
		{
			Object nextAttribute = attributeNames.nextElement();
			String attributeString = nextAttribute.toString();
			if (attributeString.equals("foreground"))
			{
				tempColor = (Color)(currentAttributes.getAttribute(nextAttribute));
				break;
			}
		}
		return tempColor;
	}

	public String isSuperScript(int position, JTextPane target)
	{
		int selectionStart = target.getSelectionStart();
		int selectionEnd = target.getSelectionEnd();
		target.removeCaretListener(this);
		target.setCaretPosition(position);
		AttributeSet currentAttributes = target.getCharacterAttributes();
		Enumeration attributeNames = currentAttributes.getAttributeNames();
		Color tempColor = null;
		while (attributeNames.hasMoreElements())
		{
			Object nextAttribute = attributeNames.nextElement();
			String attributeString = nextAttribute.toString();
			if (attributeString.equals("superscript"))
			{
				target.select(selectionStart, selectionEnd);
				target.addCaretListener(this);
				return currentAttributes.getAttribute(nextAttribute).toString();
			}
		}
		target.select(selectionStart, selectionEnd);
		target.addCaretListener(this);
		return "false";
	}

	public void keyTyped(KeyEvent e)
	{ /* Empty Implementation of Superclass's Abstract Function */ }

	/* Updates value of the typeCount variable and invokes updateRegions
	 * Also prevents user from deleting holes in unwoven body */
	public void keyPressed(KeyEvent e)
	{
		if (!isWindowEditable)
			return;
		if (isHoleInSelection)
			return;
		JTextPane target;
		AbstractDocument targetDoc;
		if (concMan.getWoven())
		{
			target = wovenCode;
			targetDoc = wovenCodeAbstractDoc;
		}
		else
		{
			target = unWovenBody;
			targetDoc = unWovenBodyAbstractDoc;
		}
		if (regionUpdater.charTyped == 0 && !unWovenConcerns.isFocusOwner())
			regionUpdater.startPosition = target.getCaretPosition();
		int modifier = e.getModifiersEx();
		String firstCheck = KeyEvent.getModifiersExText(modifier);
		//ignore actions ctrl+del and ctrl+bkspace
		if (firstCheck.equals(new String("Ctrl")) && (e.getKeyCode() == 8 ||
			e.getKeyCode() == 127))
			return;
		//also ignore shift+del and shift+insert
		if (firstCheck.equals(new String("Shift")) && (e.getKeyCode() == 155 ||
			e.getKeyCode() == 127))
			return;

		// For when user did not press delete, backspace or an action key
		if (e.getKeyCode() != 8 && e.getKeyCode() != 127 && !e.isActionKey() &&
			!unWovenConcerns.isFocusOwner())
		{
			if (target.getSelectedText() != null)
			{
				overRidePosition = target.getSelectionStart();
				overRidePosition2 = target.getSelectionEnd();
			}
			int modifiersEx = e.getModifiersEx();
			String tempString = KeyEvent.getModifiersExText(modifiersEx);
			if (tempString.length() == 0 || tempString.equals("Shift"))
			{
				if (e.getKeyCode() != 16)
					regionUpdater.charTyped++;
			}
			else if (tempString.equals(new String("Ctrl")) &&
				e.getKeyCode() == 65)	//Ctrl-A
			{
				if (!unWovenConcerns.isFocusOwner())
					concMan.updateRegions(false);
				regionUpdater.charTyped = 0;
			}
			else if (tempString.equals(new String("Ctrl")) &&
				e.getKeyCode() == 86)	//Ctrl-V
			{/* do nothing here but call kbdAction("P") in keyreleased.
				//function kbdAction accesses clipboard and updates typeCount
				//kbdAction("P");*/
			}
		}
		//when user presses backspace
		else if (e.getKeyCode() == 8)
		{
			String deletedText = target.getSelectedText();
			int initialPosition = target.getSelectionStart();
			if (unWovenConcerns.isFocusOwner())
			{
				deletedText = unWovenConcerns.getSelectedText();
				initialPosition = unWovenConcerns.getSelectionStart();
			}
			if (deletedText != null &&
				target.getSelectionStart() == 0 &&
				target.getSelectionEnd() == targetDoc.getLength())
			{
				concMan.clearMaps();
				clearWindow(target, targetDoc);
				return;
			}
			int deletedCharacters = 1;
			isBkspace = true;
			if (target.getCaretPosition() == 0 && !unWovenConcerns.isFocusOwner())
			{
				deletedCharacters = 0;
				isBkspace = false;
			}
			if (deletedText != null)
			{
				if (!concMan.getWoven() && unWovenConcerns.isFocusOwner())
				{
					deletedCharacters = 0;
					if (deletedText.contains(globalVariable.OPENHOLE) ||
						deletedText.contains(globalVariable.CLOSEHOLE))
					{
						unWovenConcerns.requestFocus();
						return;
					}
					else
						unWovenConcerns.replaceSelection("");
				}
				if (!concMan.getWoven() && unWovenBody.isFocusOwner())
				{
					if (deletedText.contains(globalVariable.HOLE))
					{
						JOptionPane.showMessageDialog(frame, "Cannot delete holes.",
							"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					else
						target.replaceSelection("");
					deletedCharacters = deletedText.length();
				}
			}
			else
			{
				if (!concMan.getWoven() && unWovenBody.isFocusOwner())
				{
					try
					{
						String testString = target.getText(initialPosition - 1, 1);
						if (testString.equals(globalVariable.HOLE))
						{
							JOptionPane.showMessageDialog(frame, "Cannot delete holes.",
								"Error", JOptionPane.ERROR_MESSAGE);
							return;
						}
						else
						{
							target.select(initialPosition - 1, initialPosition);
							target.replaceSelection("");
						}
					}
					catch (BadLocationException ble)
					{
						System.out.println(ble);
					}
				}
				else if (!concMan.getWoven() && unWovenConcerns.isFocusOwner())
				{
					if (!isUwcEditable)
					{ /*do nothing */}
					else
					{
						unWovenConcerns.setCaretPosition(initialPosition - 1);
						try
						{
							String testString = unWovenConcerns.getText(
								initialPosition - 1, 1);
							if (!isUwcEditable ||
								testString.equals(globalVariable.OPENHOLE)
								|| testString.equals(globalVariable.CLOSEHOLE))
							{
								unWovenConcerns.requestFocus();
								return;
							}
							else
							{
								unWovenConcerns.removeCaretListener(this);
								unWovenConcerns.select
									(initialPosition - 1, initialPosition);
								unWovenConcerns.replaceSelection("");
								unWovenConcerns.addCaretListener(this);
								unWovenConcerns.setCaretPosition
									(initialPosition - 1);
							}
							deletedCharacters = 0;
						}
						catch (BadLocationException ble)
						{
							System.out.println(ble);
						}
					}
				}
			}
			if (!unWovenConcerns.isFocusOwner())
			{
				regionUpdater.charTyped -= deletedCharacters;
				concMan.updateRegions(false);
			}
			isBkspace = false;
			regionUpdater.charTyped = 0;
		}
		//when user presses delete
		else if (e.getKeyCode() == 127)
		{
			String deletedText = target.getSelectedText();
			int initialPosition = target.getSelectionStart();
			if (unWovenConcerns.isFocusOwner())
			{
				deletedText = unWovenConcerns.getSelectedText();
				initialPosition = unWovenConcerns.getSelectionStart();
			}
			if (deletedText != null &&
				target.getSelectionStart() == 0 &&
				target.getSelectionEnd() == targetDoc.getLength())
			{
				concMan.clearMaps();
				clearWindow(target, targetDoc);
				return;
			}
			int deletedCharacters = 1;
			if (deletedText != null)
			{
				if (!concMan.getWoven() && unWovenConcerns.isFocusOwner())
				{
					deletedCharacters = 0;
					if (deletedText.equals(globalVariable.OPENHOLE) ||
						deletedText.equals(globalVariable.CLOSEHOLE))
					{
						unWovenConcerns.requestFocus();
						return;
					}
					else
					{
						unWovenConcerns.removeCaretListener(this);
						unWovenConcerns.replaceSelection("");
						unWovenConcerns.addCaretListener(this);
					}
				}
				if (!concMan.getWoven() && unWovenBody.isFocusOwner())
				{
					if (deletedText.contains(globalVariable.HOLE))
					{
						JOptionPane.showMessageDialog(frame,
							"Cannot delete holes.",
							"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
					else
						target.replaceSelection("");
					deletedCharacters = deletedText.length();
				}
			}
			else
			{
				if (!concMan.getWoven() && unWovenConcerns.isFocusOwner())
				{
					deletedCharacters = 0;
					try
					{
						String testString = unWovenConcerns.getText(
							initialPosition, 1);
						if (testString.equals(globalVariable.OPENHOLE) ||
							testString.equals(globalVariable.CLOSEHOLE))
						{
							unWovenConcerns.requestFocus();
							return;
						}
						else if (unWovenConcerns.getText(initialPosition, 4).equals
							(globalVariable.NEWLINE + "\t" +
							globalVariable.CLOSEARROW))
						{
							unWovenConcerns.requestFocus();
							return;
						}
						else
						{
							unWovenConcerns.removeCaretListener(this);
							unWovenConcerns.select(initialPosition,
								initialPosition + 1);
							unWovenConcerns.replaceSelection("");
							unWovenConcerns.setCaretPosition(initialPosition);
							unWovenConcerns.addCaretListener(this);
						}
					}
					catch (BadLocationException ble)
					{
						System.out.println(ble);
					}
				}
				if (!concMan.getWoven() && unWovenBody.isFocusOwner())
				{
					try
					{
						String testString = target.getText(initialPosition, 1);
						if (testString.equals(globalVariable.HOLE))
						{
							JOptionPane.showMessageDialog(frame,
								"Cannot delete holes.", "Error",
								JOptionPane.ERROR_MESSAGE);
							return;
						}
						else
						{
							target.select(initialPosition, initialPosition + 1);
							target.replaceSelection("");
						}
					}
					catch (BadLocationException ble)
					{
						System.out.println(ble);
					}
				}
			}
			if (!unWovenConcerns.isFocusOwner())
			{
				concMan.updateRegions(false);
				regionUpdater.charTyped -= deletedCharacters;
				concMan.updateRegions(true);
			}
			regionUpdater.charTyped = 0;
		}
		//when user presses an action key, we update regions and reset typeCount
		if (e.isActionKey())
		{
			if (!unWovenConcerns.isFocusOwner())
			{
				concMan.updateRegions(false);
				regionUpdater.charTyped = 0;
			}
			else
			{
				if (isUwcEditable)
				{
					HashMap equalHoles = concMan.returnEqualHoles();
					if (equalHoles.size() > 0)
					{
						unWovenConcerns.removeCaretListener(this);
						unWovenConcerns.removeKeyListener(this);
						concMan.updateEqualHoles(equalHoles);
						unWovenConcerns.addCaretListener(this);
						unWovenConcerns.addKeyListener(this);
					}
				}

			}
		}
		//}
	}

	/* Takes care of the case when user "cuts" text */
	public void keyReleased(KeyEvent e)
	{
		if (!isWindowEditable)
			return;
		if (e.getKeyCode() != 8 && e.getKeyCode() != 127 && !e.isActionKey())
		{
			int modifiersEx = e.getModifiersEx();
			String tempString = KeyEvent.getModifiersExText(modifiersEx);
			if (tempString.equals(new String("Ctrl")) && e.getKeyCode() == 88)
				//Ctrl-X
				kbdAction("C");
			if (tempString.equals(new String("Ctrl")) && e.getKeyCode() == 86)
				//Ctrl-V
				kbdAction("P");
		}
	}

	/* Class to invoke the pop up menu in woven code */
	class PopupListener extends MouseAdapter
	{
		Windows mainWindow;
		JPopupMenu popup;

		PopupListener(JPopupMenu popupMenu)
		{ popup = popupMenu; }

		public void mousePressed(MouseEvent e)
		{
			concMan.updateRegions(false);
			regionUpdater.charTyped = 0;
			if (concMan.getWoven())
				maybeShowPopup(e);
		}

		public void mouseReleased(MouseEvent e)
		{
			if (concMan.getWoven())
				maybeShowPopup(e);
		}

		private void maybeShowPopup(MouseEvent e)
		{
			if (e.isPopupTrigger())
			{
				createPopupMenu();
				popup.show(e.getComponent(),
					e.getX(), e.getY());
			}
		}
	}

	public void focusGained(FocusEvent e)
	{ /* Empty Implementation of Superclass's Abstract Function */ }

	/* Takes care of a visual bug. */
	public void focusLost(FocusEvent e)
	{
		if (e.getComponent().getName().equals("unWovenConcerns"))
			unWovenConcerns.setEditable(true);
	}
}