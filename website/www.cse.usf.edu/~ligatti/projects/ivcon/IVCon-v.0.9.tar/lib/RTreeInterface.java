/* RTreeInterface.java: Interface between IVCON and the RTree*/

import datastructures.*;
import java.io.*;
import java.awt.*;
import javax.swing.text.*;

import spatialindex.rtree.*;
import spatialindex.spatialindex.*;
import spatialindex.storagemanager.*;

class RTreeInterface
{
	private int caller = 1;
	private RTree rtree;
	private boolean visited;

	ConcernManipulation concMan;
	Windows mainWindow;
	GlobalVariables globalVariable;

	/* Initialize RTree */
	public void initRTree()
	{
		PropertySet properties = new PropertySet();
		properties.setProperty("Dimension", 2);
		properties.setProperty("IndexCapacity", 4);
		properties.setProperty("LeafCapacity", 4);
		PropertySet ps = new PropertySet();

		Boolean overWrite = new Boolean(true);
		ps.setProperty("Overwrite", overWrite);
		Integer pageSize = new Integer(4096);
		ps.setProperty("PageSize", pageSize);

		IStorageManager storageManager = new MemoryStorageManager();
		IBuffer file = new RandomEvictionsBuffer(storageManager, 10, false);

		rtree = new RTree(properties, file);
		double[] lowerLimit = new double[2];
		double[] upperLimit = new double[2];
		lowerLimit[0] = 0; lowerLimit[1] = 0;
		upperLimit[0] = 0; upperLimit[1] = 0;

		IShape region = new Region(lowerLimit, upperLimit);
		rtree.insertData(null, region, -1);
	}

	/* Returns the value of the visited variable*/
	public boolean getVisited()
	{ return visited; }

	/* Sets RTree to the RTree specified by the calling object */
	public void setRTree(RTree tempRTree)
	{ rtree = tempRTree; }

	/* Returns the RTree */
	public RTree getRTree()
	{ return rtree; }

	/* Deletes an interval from the RTree specified by the calling object */
	void deleteDatafromTree(IShape delRegion, int delId)
	{ rtree.deleteData(delRegion, delId); }

	/* Adds an interval to the RTree specified by the calling object */
	void addRegionToTree(int startPoint, int endPoint, int id)
	{
		double[] lowerLimit = new double[2];
		double[] upperLimit = new double[2];
		lowerLimit[0] = 0; lowerLimit[1] = 0;
		upperLimit[0] = 0; upperLimit[1] = 0;
		IShape tempRegion = new Region(lowerLimit, upperLimit);
		if (id == 0)
			rtree.deleteData(tempRegion, -1);

		lowerLimit[0] = startPoint; lowerLimit[1] = 0;
		upperLimit[0] = endPoint; upperLimit[1] = 0;
		IShape addRegion = new Region(lowerLimit, upperLimit);
		rtree.insertData(null, addRegion, id);
	}

	/* Based on given start and end positions, this  method adds 
	 * information to various arraylists. the parameter "call" 
	 * specifies the arraylist to which information is to be added */
	void queryMethod(int startPosition, int endPosition, int call)
	{
		visited = false;
		caller = call;
		MyVisitor visitor = new MyVisitor();
		double[] f1 = new double[2];
		double[] f2 = new double[2];
		f1[0] = startPosition; f1[1] = 0;
		f2[0] = endPosition; f2[1] = 0;
		Region region = new Region(f1, f2);
		mainWindow.setInteger("currentNoOfRegions", 0);
		rtree.intersectionQuery(region, visitor);
		caller = 1;
	}

	/* Implementation of the MyVisitor class provided by RTree. The caller 
	 * variable controls what it does after getting interval id's */
	class MyVisitor implements IVisitor
	{
		public void visitNode(final INode n) { /* Empty Implementation of Superclass's Abstract Function */	}
		public void visitData(final IData d)
		{
			int regionID = d.getIdentifier();
			if (regionID != -1)
			{
				if (caller == 2) // if call came from changecolor or editcolor module
				{
					if (!((RegionInfo)(concMan.get("regionMap", regionID))).
						arrayListOfConcerns.isEmpty())
					{
						concMan.add("listOfRegions", ((RegionInfo)(concMan.get("regionMap", regionID))).begPos);
						concMan.add("listOfRegions", ((RegionInfo)(concMan.get("regionMap", regionID))).endPos + 1);
					}
				}
				else if (caller == 0)	//call came from minimize regions
				{
					if (!((RegionInfo)(concMan.get("regionMap", regionID))).
						arrayListOfConcerns.isEmpty())
						concMan.add("listOfRegionIds", regionID);
				}
				else if (caller == 1)	//call came from caretupdate
				{
					if (concMan.getNoOfRegions() != 0)
					{
						int j = 0;
						RegionInfo tempRegion = (RegionInfo)(concMan.get("regionMap", regionID));
						while (j < tempRegion.arrayListOfConcerns.size())
						{
							String tempConcern = (String)tempRegion.arrayListOfConcerns.get(j);
							Color tempColor = ((ConcernInfo)((concMan.getMap("concernMap")).get(tempConcern))).clr;
							StyleConstants.setForeground(mainWindow.attrs[1],
								tempColor);
							mainWindow.insertText("currentConcernsAbstractDoc",
								tempConcern + globalVariable.NEWLINE, -1, 1);
							concMan.add("listOfConcerns", tempConcern);
							j++;
							mainWindow.setInteger("currentNoOfRegions",
								(mainWindow.getInteger("currentNoOfRegions") + 1));
						}
					}
				}
				else if (caller == 3)	//call came from mouse motion listener
				{
					if (concMan.getNoOfRegions() != 0)
					{
						visited = true;
						int j = 0;
						RegionInfo tempRegion = (RegionInfo)(concMan.get("regionMap", regionID));
						while (j < tempRegion.arrayListOfConcerns.size())
						{
							String tempConcern = (String)tempRegion.arrayListOfConcerns.get(j);
							Color tempColor = ((ConcernInfo)((concMan.getMap("concernMap")).get(tempConcern))).clr;
							StyleConstants.setForeground(mainWindow.attrs[1],
								tempColor);
							mainWindow.addToCacp(tempConcern);
							j++;
						}
					}
				}
			}
		}
	}
}