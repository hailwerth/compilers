/* All static global variables that have been used */
import java.awt.Color;

public class GlobalVariables
{
	final static String NEWLINE = "\n";
	final static String HOLE = "\1";
	final static String OPENARROW =
		((Object)((char)167)).toString() + ((Object)((char)187)).toString();
	final static String OPENHOLE = ((Object)((char)187)).toString();
	final static String CLOSEARROW =
		((Object)((char)171)).toString() + ((Object)((char)167)).toString();
	final static String CLOSEHOLE = ((Object)((char)171)).toString();
	final static Color GREENCOLOR = new Color(14, 200, 4);
}