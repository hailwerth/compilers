import datastructures.*;

public class PositionConcernMap implements Comparable
{
	public int position;
	public String concern;
	PositionConcernMap(int a, String b)
	{
		position = a;
		concern = b;
	}
	public String toString()
	{
		return (position + "---->" + concern);
	}
	public int compareTo(Object o)
	{
		return ((Integer)position).compareTo(
			(Integer)(((PositionConcernMap)o).position));
	}
	public boolean equals(PositionConcernMap equateMap)
	{
		if (position == equateMap.position &&
			concern.equals(equateMap.concern))
			return true;
		else
			return false;
	}
}